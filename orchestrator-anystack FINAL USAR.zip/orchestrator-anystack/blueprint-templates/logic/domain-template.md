# logic/domain.md — domain template

> Defines business concepts, entities, relationships, vocabulary and invariants. Does not describe UI or endpoints.

## Index

| ID | Type | Name | Screens | Status |
|---|---|---|---|---|
| DOM-001 | entity | `<ENTITY>` | [SCR-001] | draft |
| DOM-002 | invariant | `<INVARIANT>` | [SCR-001] | draft |

## DOM-001 — `<ENTITY_OR_CONCEPT_NAME>`

```logic
id: DOM-001
type: entity
status: draft
summary: "<WHAT_IT_REPRESENTS_IN_THE_BUSINESS>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: []
severity: must
terms:
  singular: "<term>"
  plural: "<terms>"
  forbidden_aliases: ["<ambiguous_alias>"]
data_refs: [DATA-001]
permission_refs: [PERM-001]
verification:
  observable_by: [db, ui, test]
  evidence: [db_snapshot, screen_assertion]
```

**Definition:** `<DEFINE_THE_ENTITY_AS_THE_BUSINESS_UNDERSTANDS_IT>`

**Business attributes:**

| Attribute | Meaning | Required | Valid example |
|---|---|---:|---|
| `<attribute>` | `<meaning>` | yes/no | `<example>` |

**Relationships:**

- `<ENTITY_A>` belongs to `<ENTITY_B>` when `<CONDITION>`.

**Valid examples:**

- `<EXAMPLE>`

**Counter-examples:**

- `<INVALID_EXAMPLE>`

## DOM-002 — `<INVARIANT_NAME>`

```logic
id: DOM-002
type: invariant
status: draft
summary: "<BUSINESS_INVARIANT>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001]
severity: must
verification:
  observable_by: [test, db]
  evidence: [test_output, db_constraint]
```

**Invariant:** `<SOMETHING_THAT_MUST_NEVER_BE_FALSE>`

**Must hold when:**

- `<CONDITION>`

**Must not be allowed:**

- `<PROHIBITED_CASE>`

**Expected technical implication:** `<VALIDATION_CONSTRAINT_OR_SERVICE_RULE_WITHOUT_IMPLEMENTING_IT_HERE>`

## Checklist

- [ ] Each concept has a unique name.
- [ ] Ambiguous aliases are prohibited.
- [ ] Each invariant has a counter-example.
- [ ] Entities cite `DATA-*` if they must be persisted.
- [ ] Entities cite `PERM-*` if they have ownership or restricted access.
