# logic/application.md — application template

> Defines application behavior: commands, queries, services, transactions, input validations and effects. Does not define visual design.

## Index

| ID | Type | Name | Actor | Screens | Status |
|---|---|---|---|---|---|
| APP-001 | command | `<ACTION>` | `<ROLE>` | [SCR-001] | draft |
| APP-002 | query | `<QUERY>` | `<ROLE>` | [SCR-001] | draft |

## APP-001 — `<COMMAND_OR_ACTION_NAME>`

```logic
id: APP-001
type: command
status: draft
summary: "<ACTION_THAT_CHANGES_STATE>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, DATA-001, PERM-001, ERR-001]
severity: must
actor: "<ACTOR_OR_ROLE>"
trigger: "<EVENT_THAT_TRIGGERS_THE_ACTION>"
engine_ref: ENG-001          # if this command delegates a decision/derivation to an engine (logic/engine.md); omit if none
transactional: true
idempotent: false
verification:
  observable_by: [test, db, log, ui]
  evidence: [test_output, db_snapshot, backend_log]
```

**Goal:** `<WHAT_THE_ACTION_MUST_ACHIEVE>`

**Input:**

| Field | Logical type | Required | Validation | Source |
|---|---|---:|---|---|
| `<field>` | `<type>` | yes/no | `<rule>` | `<ui/api/system>` |

**Preconditions:**

- `<PRECONDITION>`

**Main flow:**

1. Validate `<INPUT>`.
2. Check `<PERMISSION>`.
3. Execute `<STATE_CHANGE>`.
4. Persist `<DATA>`.
5. Emit `<EVENT_OR_RESPONSE>`.

**Expected effects:**

- Data: `<CHANGES_IN_DATA-*>`
- Events/logs: `<EVENTS_OR_LOGS>`
- UI: `<VISIBLE_FEEDBACK>`

**Handled errors:**

| Condition | Error | Recovery |
|---|---|---|
| `<CONDITION>` | ERR-001 | `<HOW_TO_RECOVER>` |

## APP-002 — `<QUERY_OR_READ_NAME>`

```logic
id: APP-002
type: query
status: draft
summary: "<READ_THAT_DOES_NOT_CHANGE_STATE>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DATA-001, PERM-001]
severity: must
actor: "<ACTOR_OR_ROLE>"
cache_policy: "<none|short|session|server>"
verification:
  observable_by: [test, db, ui]
  evidence: [test_output, db_query, screenshot]
```

**Expected result:** `<WHAT_DATA_IS_RETURNED_AND_IN_WHAT_ORDER>`

**Filters and sorting:**

- `<FILTER>`
- `<ORDER>`

**Visibility rules:**

- `<WHAT_RECORDS_THE_ACTOR_CAN_SEE>`

## Checklist

- [ ] Each command states whether it is transactional and idempotent.
- [ ] Each query defines filters, order and visibility.
- [ ] Validations cite `DOM-*`, `PERM-*`, `DATA-*` or `ERR-*`.
- [ ] Effects are observable in DB, logs, API or UI.
- [ ] No business logic is hidden exclusively in the UI.
- [ ] A command that decides, derives, scores or aggregates cites its `engine_ref: ENG-*` instead of embedding the rule — the engine is the contracted module, the command is its caller.
