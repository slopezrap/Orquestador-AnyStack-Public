# logic/shell.md — shared shell / cross-screen contract template

> Defines everything screens must share so that screens built one at a time still fit together: global shell/layout, navigation map, reusable component inventory, route naming convention, design tokens binding and shared internal API contracts. IDs here use the `UI-SHELL-*` family (part of the `UI-*` prefix — no new prefix). This file is the source of truth `verify-coherence` and `pantalla-reviewer` check every screen against; `INT-*` stays reserved for EXTERNAL systems.

## Index

| ID | Area | Name | Screens | Status |
|---|---|---|---|---|
| UI-SHELL-001 | shell | `<GLOBAL_SHELL_NAME>` | [ALL] | draft |
| UI-SHELL-002 | navigation | `<NAV_MAP_NAME>` | [ALL] | draft |
| UI-SHELL-003 | components | `<COMPONENT_INVENTORY_NAME>` | [ALL] | draft |
| UI-SHELL-004 | routes | `<ROUTE_CONVENTION_NAME>` | [ALL] | draft |
| UI-SHELL-005 | api | `<SHARED_API_CONTRACT_NAME>` | [ALL] | draft |

> `related_screens: [ALL]` is a documented sentinel: the rule applies to every `kind: ui` screen, present and future. Use an explicit list only when a rule is genuinely scoped.

## UI-SHELL-001 — Global shell/layout

```logic
id: UI-SHELL-001
type: shell_rule
area: shell
status: draft
summary: "<HEADER_NAV_FOOTER_LAYOUT_THAT_EVERY_SCREEN_RENDERS_INSIDE>"
product_refs: [BR-001]
related_screens: [ALL]
depends_on: [PERM-001]
severity: must
platforms: [web, android, ios]
verification:
  observable_by: [screenshot, e2e]
  evidence: [screenshot, flow_recording]
```

**Rule:** every `kind: ui` screen renders inside the shared shell: `<DESCRIBE: header/top bar, primary navigation, footer/tab bar, auth state display>`. A screen never re-implements its own copy of the shell.

**Per-platform shell:**

| Platform | Shell form |
|---|---|
| web | `<LAYOUT_COMPONENT_AND_FILE>` |
| android | `<SCAFFOLD_WIDGET_AND_FILE>` |
| ios | `<SCAFFOLD_WIDGET_AND_FILE>` |

## UI-SHELL-002 — Navigation map

```logic
id: UI-SHELL-002
type: shell_rule
area: navigation
status: draft
summary: "<HOW_SCREENS_LINK_TO_EACH_OTHER>"
product_refs: []
related_screens: [ALL]
depends_on: [UI-SHELL-001]
severity: must
platforms: [web, android, ios]
verification:
  observable_by: [e2e, route_check]
  evidence: [flow_recording, network_log]
```

**Rule:** the navigation entries, their order and their visibility per role/permission. Every screen's "Entrada del usuario"/"Navegación siguiente" in `SCREENS.md` must be reachable through this map — a screen that no other screen links to (and is not an entry point) is a coherence gap.

| Nav entry | Target screen (SCR-*) | Visible for (PERM-*) | Order |
|---|---|---|---|
| `<LABEL>` | SCR-001 | PERM-001 | 1 |

## UI-SHELL-003 — Reusable component inventory

```logic
id: UI-SHELL-003
type: shell_rule
area: components
status: draft
summary: "<THE_SHARED_COMPONENTS_SCREENS_MUST_REUSE_INSTEAD_OF_DUPLICATING>"
product_refs: []
related_screens: [ALL]
depends_on: [UI-SHELL-001]
severity: must
platforms: [web, android, ios]
verification:
  observable_by: [code_review, screenshot]
  evidence: [code_citation, screenshot]
```

**Rule:** before a screen implements a visual pattern, it reuses the inventory. New shared components are added HERE first (via `/reslice` or RESEARCH auto_fill), then implemented once.

| Component | Purpose | Location (once built) | States it must support |
|---|---|---|---|
| `<AppButton>` | `<PRIMARY_ACTIONS>` | `<PATH>` | default/loading/disabled |
| `<AppEmptyState>` | `<EMPTY_LISTS>` | `<PATH>` | icon+message+CTA |
| `<AppErrorState>` | `<RECOVERABLE_ERRORS>` | `<PATH>` | message+retry |

## UI-SHELL-004 — Route and deep-link naming convention

```logic
id: UI-SHELL-004
type: shell_rule
area: routes
status: draft
summary: "<THE_ONE_NAMING_RULE_ALL_ROUTES_FOLLOW>"
product_refs: []
related_screens: [ALL]
depends_on: []
severity: must
platforms: [web, android, ios]
verification:
  observable_by: [route_check]
  evidence: [code_citation]
```

**Rule:** `<e.g. web: /kebab-case/<entity>/<id>; deep links: app://<same-path>. Plural for collections, singular for detail. No synonyms: pick one term per entity and keep it.>`

## UI-SHELL-005 — Shared internal API contract

```logic
id: UI-SHELL-005
type: shell_rule
area: api
status: draft
summary: "<CONVENTIONS_EVERY_INTERNAL_ENDPOINT_FOLLOWS>"
product_refs: []
related_screens: [ALL]
depends_on: [ERR-001, PERM-001]
severity: must
platforms: [all]
verification:
  observable_by: [api_check]
  evidence: [api_response]
```

**Rule:** `<e.g. base path /api/v1, envelope {data, error}, structured errors per ERR-*, auth header, pagination params — the conventions every screen's endpoints follow so clients can share one API layer>`. This is for the product's OWN API; external providers stay in `INT-*`.

## Design tokens binding

- Tokens file: `design/tokens.css` — screens use tokens, never hardcoded values, for color/typography/spacing/radius/elevation declared there.
- Shell design reference: `design/screens/<shell-reference-file>` when available.

## Checklist

- [ ] Every `UI-SHELL-*` rule is observable (screenshot, flow, route or API check).
- [ ] The navigation map covers every `SCR-*` UI screen in `SCREENS.md` (or marks it as an entry point).
- [ ] The component inventory names concrete states, not just component names.
- [ ] The route convention has zero exceptions, or lists them explicitly.
- [ ] `SCR-FOUNDATION-SHELL` in `SCREENS.md` cites these IDs in `applies[]`.
