# logic/core.md — core template

> Defines system-wide invariants that must hold across the entire product: identity, tenant, audit, time, idempotency, security, traceability and consistency.

## Index

| ID | Area | Name | Severity | Status |
|---|---|---|---|---|
| CORE-001 | identity | `<CORE_RULE>` | must | draft |

## CORE-001 — `<CORE_INVARIANT_NAME>`

```logic
id: CORE-001
type: core_invariant
area: identity
status: draft
summary: "<SYSTEM_WIDE_RULE>"
product_refs: [BR-001]
related_screens: [SCR-FOUNDATION-AUTH, SCR-001]
depends_on: [PERM-001, DATA-001]
severity: must
verification:
  observable_by: [test, log, db]
  evidence: [test_output, audit_log, db_snapshot]
```

**Rule:** `<SYSTEM_WIDE_INVARIANT>`

**Applies to:**

- `<MODULE_OR_LAYER>`

**Must protect against:**

- `<RISK>`

**How it is observed:**

- `<TEST_LOG_CONSTRAINT_OR_VISIBLE_BEHAVIOR>`

## Recommended areas

### Identity and ownership

- Every private piece of data must have an owner or an explicit visibility rule.
- No operation should trust a user identifier sent by the client when an authenticated session exists.

### Tenant or isolation

- Every tenant-scoped resource must be filtered by tenant on both read and write.

### Time

- Business dates must declare their time zone and source of truth.

### Idempotency

- Repeatable operations or external calls must declare an idempotency key.

### Audit

- Critical actions must leave an audit event containing actor, resource, action, result and timestamp.

### Observability

- Unrecoverable failures must be written to logs with enough correlation context to debug.

## Checklist

- [ ] Each core rule is system-wide, not specific to a single screen.
- [ ] Each core rule has verifiable evidence.
- [ ] Identity/tenant rules do not rely solely on the UI.
- [ ] Critical actions cite audit or logging.
