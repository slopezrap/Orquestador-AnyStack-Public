# logic/permission.md — permission template

> Defines authorization: who can do what, on which resource, under what condition, and how it is audited.

## Index

| ID | Actor/Role | Resource | Action | Status |
|---|---|---|---|---|
| PERM-001 | `<ROLE>` | `<RESOURCE>` | `<ACTION>` | draft |

## General permission matrix

| Role | Resource | Create | Read | Update | Delete | Condition |
|---|---|---:|---:|---:|---:|---|
| `<ROLE>` | `<RESOURCE>` | yes/no | yes/no | yes/no | yes/no | `<CONDITION>` |

## PERM-001 — `<PERMISSION_NAME>`

```logic
id: PERM-001
type: permission
status: draft
summary: "<WHO_CAN_DO_WHAT>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, DATA-001, CORE-001]
severity: must
actor: "<ROLE_OR_ACTOR>"
resource: "<RESOURCE>"
action: "<create|read|update|delete|execute>"
ownership_required: true
audit_required: true
verification:
  observable_by: [test, api, db, log, ui]
  evidence: [test_output, forbidden_response, audit_log]
```

**Rule:** `<THE_ACTOR_CAN_OR_CANNOT_EXECUTE_THE_ACTION_WHEN...>`

**Conditions to allow:**

- `<CONDITION_1>`
- `<CONDITION_2>`

**Conditions to deny:**

- `<DENY_CONDITION>`

**Response on denial:**

- UI: `<VISIBLE_MESSAGE_OR_STATE>`
- API: `<CODE_OR_LOGICAL_ERROR>`
- Log/audit: `<WHAT_IS_RECORDED>`

**Minimum test cases:**

| Case | User | Resource | Expected result |
|---|---|---|---|
| allowed | `<USER>` | `<OWN_RESOURCE>` | allow |
| denied | `<USER>` | `<OTHER_USER_RESOURCE>` | deny |

## Checklist

- [ ] Each permission defines actor, resource, action and condition.
- [ ] Denials have a clear UI/API behavior.
- [ ] Critical operations have an audit trail.
- [ ] Read and write are considered separately.
- [ ] Security is not delegated solely to the frontend.
