# DECISIONS.md — decision ledger template

> Every product decision taken AFTER the blueprint was first written. Append-only.
>
> This file exists because the *what* of a decision survives (it gets written into a `logic/*.md` layer) but the *why* does not: it stays in a chat that compaction erases. Three months later nobody can tell whether a rule is deliberate or drift.
>
> It is also what makes reconciliation falsifiable. Without it, "that part of the original was superseded" is a model's opinion. With it, superseding is a record with a signature: a `DEC-*` that names exactly what it replaces.

## Rules

- **Append-only.** A decision is never edited or deleted. It is reversed by a NEW decision that supersedes it — the old one stays as history.
- **The decision is not the truth, it is the record of the change.** The operative truth still lives in the layer (`logic/*.md`, `PRODUCT.md`, `SCREENS.md`). `written_to` says where it landed; if a decision has no `written_to`, it was not applied.
- **Written by `orchestrator-flow`, decided by the human.** The conductor may propose, never decide: `decided_by` is a person. A decision the human did not take is invented product intent.
- **One decision, one entry.** If a conversation produced three decisions, write three.

## Index

| ID | Date | Decision | Supersedes | Written to |
|---|---|---|---|---|
| DEC-001 | YYYY-MM-DD | `<ONE_LINE>` | `<DEC-0NN \| —>` | `<LAYER_IDs>` |

## DEC-001 — `<DECISION_NAME>`

```logic
id: DEC-001
type: decision
status: applied
date: YYYY-MM-DD
decided_by: "<PERSON>"
trigger: "<CLARIFY on a screen | conversation | build discovery | review gate finding>"
supersedes: []                        # earlier DEC-* this one reverses
written_to: [<LAYER_ID>, <LAYER_ID>]  # the real IDs whose files now carry this truth
affects_screens: [<SCR_ID>]
reopens: []
```

**Decision:** `<WHAT_WAS_DECIDED, in product language>`

**Why:** `<THE_REASONING — this is the part that is otherwise lost>`

**What it replaces:** `<WHAT_WAS_TRUE_BEFORE, or "nothing — new ground">`

**Consequence:** `<WHAT_HAD_TO_CHANGE: layers edited, screens to re-verify, /reslice needed>`

## Fields

| Field | Meaning |
|---|---|
| `status` | `applied` (already written to its layers) · `pending` (decided, not yet written — must not stay pending) · `reversed` (a later `DEC-*` supersedes it) |
| `trigger` | What forced the decision. Most come from a CLARIFY the build raised, from something the human said unprompted, or from a review gate finding a real-world constraint. |
| `supersedes` | Earlier `DEC-*` this decision reverses. What it replaces from the original goes in prose under **What it replaces** — the original is free text, so there is nothing to point an ID at. |
| `written_to` | The IDs whose files now carry this truth. Empty means the decision was never applied. |
| `reopens` | Units already `verified`/`accepted` whose contract this decision changes — they need `/reslice`, not a silent patch. |

## Checklist

- [ ] Every decision names a person in `decided_by`.
- [ ] Every decision explains **why**, not only what.
- [ ] Every `applied` decision has a non-empty `written_to`.
- [ ] A decision that contradicts an earlier one declares it in `supersedes`.
- [ ] A decision that changes an already-`accepted` contract lists it in `reopens` and routes through `/reslice`.
- [ ] No decision was taken by the model: the conductor proposes, the human decides.
