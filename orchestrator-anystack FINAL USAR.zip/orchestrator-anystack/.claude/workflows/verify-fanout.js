export const meta = {
  name: 'verify-fanout',
  description: 'Phase 3 VERIFY (static, against the documents) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out 10 specialized lens-agents in parallel (tests, conformance, design, frontend, engine, pipeline, logs, quality, coherence, blueprint-drift), and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow (advisory verdict + literal values lifted verbatim). The conductor consolidates result.json and decides; this never emits a lifecycle verdict.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk' },
    { title: 'Lenses', detail: 'the 10 verify-* agents in parallel (tests, conformance, design, frontend, engine, pipeline, logs, quality, coherence, blueprint-drift)' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (advisory static verdict, observed literals, expected_ui_values)' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (10 lenses verifying an empty feature
// return a complete lens set with nothing behind it, and the STATE GATE accepts it).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`verify-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// 10 static lenses; verify-engine returns db_value, verify-pipeline returns api_value + expected_ui_values,
// verify-coherence compares against the shell contract (UI-SHELL-*) and the sibling verified/accepted screens.
const LENSES = [
  'verify-tests', 'verify-conformance', 'verify-design', 'verify-frontend',
  'verify-engine', 'verify-pipeline', 'verify-logs', 'verify-quality',
  'verify-coherence', 'verify-blueprint-drift',
]

phase('Lenses')
const results = await parallel(LENSES.map(a => () =>
  agent(
    `VERIFY (static) lens ${a} for screen ${sid}. Repo root: ${root}. Verify against the documents per your spec — do NOT drive the live UI (that is VALIDATE).\n\nFeature: ${JSON.stringify(ctx.feature_excerpt)}`,
    { label: a, phase: 'Lenses', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))
const lenses = results.filter(r => r && r.result)
// A lens whose agent returned nothing must surface in unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['screen_id', 'static_verdict', 'verdict_by_lens', 'findings', 'observed_values', 'expected_ui_values', 'artifacts', 'source_refs', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    static_verdict: { type: 'string', enum: ['pass', 'fail', 'n/a'] },
    verdict_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    observed_values: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    artifacts: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the VERIFY phase of screen ${sid}. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you do NOT emit a lifecycle verdict — orchestrator-flow decides and writes.\nRules: static_verdict is MECHANICAL + ADVISORY only — fail if ANY lens is fail, n/a if all are n/a, else pass (the conductor may override). findings: merge all lens findings, sort blocker→nit, dedupe by (acceptance_ref, detail), keep each finding's lens. observed_values {db_value, api_value} and expected_ui_values[] must be lifted VERBATIM from the verify-engine / verify-pipeline lenses (they are load-bearing for VALIDATE derives-from and the validator's same_value recompute — never paraphrase or invent). artifacts: union of artifact paths. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Also list every lens named below as returning no result in unmerged[] with reason "no result returned". Keep each finding's acceptance_ref and doc_refs (the cited blueprint rule IDs); also build source_refs[] = the blueprint rule IDs + files cited across the findings, a navigable index so orchestrator-flow can re-open the source rule when repairing.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'verify-synthesizer' }
)

// The digest carries the observed literals VALIDATE derives from: returning `digest: undefined`
// would close VERIFY on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`verify-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${LENSES.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not persist expected_ui_values from an empty VERIFY.`)
}

// orchestrator-flow consumes `digest`, writes the consolidated result.json and decides; pantalla-reviewer
// remains the sole contractual REVIEW verdict; validate-state.py remains the only gate. `lenses` kept for traceability.
return { screen_id: sid, digest, lenses, failed_lenses }
