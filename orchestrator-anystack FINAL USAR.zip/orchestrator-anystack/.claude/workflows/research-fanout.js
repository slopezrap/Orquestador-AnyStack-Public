export const meta = {
  name: 'research-fanout',
  description: 'Phase 0 RESEARCH for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out one specialized lens-agent per blueprint file (17: 14 logic/*.md + PRODUCT + SCREENS + design) in parallel, and a read-only synthesis reducer collapses them into ONE digest (coverage, deduped gaps, flagged cross-file contradictions, CLARIFY questions) for orchestrator-flow. The conductor runs CLARIFY and writes the blueprint; the synthesizer adjudicates nothing and writes nothing.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk' },
    { title: 'Lenses', detail: 'one research-* agent per blueprint file, in parallel' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (coverage, gaps, contradictions flagged, clarify_questions)' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    design_ref: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title, design_ref (its declared design reference, else design/screens/<slug>.html) and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, source} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (17 lenses researching a screen that
// literally does not exist return a full-but-empty set the STATE GATE cannot tell from a real one).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`research-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// One lens-agent per blueprint file (the agent body holds the focus + return contract).
const LENSES = [
  'research-domain', 'research-application', 'research-core', 'research-journey',
  'research-permission', 'research-state', 'research-error', 'research-integration',
  'research-ui', 'research-shell', 'research-data', 'research-usecases',
  'research-engine', 'research-pipeline',
  'research-product', 'research-screens', 'research-design',
]

phase('Lenses')
const results = await parallel(LENSES.map(a => () =>
  agent(
    `RESEARCH lens for screen ${sid} (${ctx.title || ctx.slug || ''}). Repo root: ${root}. Read your blueprint file and assess whether it fully and unambiguously specifies THIS screen on your concern; return per your spec.\n\nFeature: ${JSON.stringify(ctx.feature_excerpt)}\ndesign_ref: ${ctx.design_ref || `design/screens/${ctx.slug || sid}.html`}`,
    { label: a, phase: 'Lenses', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))
const lenses = results.filter(r => r && r.result)
// A lens whose agent returned nothing must surface in unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['screen_id', 'coverage', 'coverage_by_lens', 'gaps', 'cross_file_contradictions', 'auto_fill', 'clarify_questions', 'source_refs', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    coverage: { type: 'string', enum: ['complete', 'partial', 'missing'] },
    coverage_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    gaps: { type: 'array', items: { type: 'object', additionalProperties: true } },
    cross_file_contradictions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    auto_fill: { type: 'array', items: { type: 'object', additionalProperties: true } },
    clarify_questions: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the RESEARCH phase of screen ${sid}. Consolidate the per-lens (per-blueprint-file) results below into ONE digest. You WRITE NOTHING and you ADJUDICATE NOTHING — orchestrator-flow runs CLARIFY with the human and writes the blueprint.\nRules: coverage = worst-of across lenses (missing < partial < complete; ignore n/a lenses). coverage_by_lens: one row per lens {lens, file, covered}. gaps: union of all lens gaps, each {problem, location, resolution: auto_fill|clarify, proposed_fill, source_lenses}; proposed_fill copied VERBATIM (never invent product intent). cross_file_contradictions: FLAG only (two files disagree, or a screen cites a missing ID) as {ids, detail, lenses} — do not resolve them. auto_fill: deduped union (proposed_fill verbatim). clarify_questions: deduped union (for one CLARIFY round). Any missing/unparseable lens → unmerged[]. Build source_refs[] = the blueprint files+IDs relevant to this screen, and keep each gap's file+refs, so orchestrator-flow can re-open the source while it builds.\n\nLenses that returned NO result (list each in unmerged[] with reason "no result returned"): ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'research-synthesizer' }
)

// The digest is the whole point of the phase: returning `digest: undefined` would let the conductor
// close RESEARCH on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`research-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${LENSES.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not write the blueprint from an empty RESEARCH.`)
}

// orchestrator-flow consumes `digest`: applies auto_fill, runs CLARIFY once, resolves contradictions, writes the blueprint.
return { screen_id: sid, digest, lenses, failed_lenses }
