export const meta = {
  name: 'compile-blueprint',
  description: 'INIT fan-out (phase 0 of /init-build): read EVERY blueprint file in parallel — one research-* lens per file in whole-blueprint COMPILE mode — then a read-only synthesis reducer collapses the 17 extractions into ONE compile digest (architecture, rules_index, unit_inventory with deps, data_engine drafts, flagged cross-file issues, CLARIFY) for orchestrator-flow. The conductor decides and writes spec.md + features.json; the synthesizer writes nothing.',
  phases: [
    { title: 'Read', detail: 'research-* lenses read all blueprint files in compile mode, in parallel' },
    { title: 'Synthesize', detail: 'read-only reducer → one compile digest (inventory, deps, data_engine drafts, gaps)' },
  ],
}

const ctx = args || {}
const root = ctx.root || '.'

// Same per-file specialists as RESEARCH, here in whole-blueprint COMPILE mode.
const LENSES = [
  'research-domain', 'research-application', 'research-core', 'research-journey',
  'research-permission', 'research-state', 'research-error', 'research-integration',
  'research-ui', 'research-shell', 'research-data', 'research-usecases',
  'research-engine', 'research-pipeline',
  'research-product', 'research-screens', 'research-design',
]

phase('Read')
const results = await parallel(LENSES.map(a => () =>
  agent(
    `INIT COMPILE mode (whole blueprint, NOT one screen). Repo root: ${root}. Read your blueprint file fully and extract everything it defines for state generation: every ID it owns, the screens/units it implies or owns (for research-screens/research-product), data_engine drafts (for research-data/application/usecases), dependencies between units, and any gaps/contradictions/CLARIFY. Do not scope to a single screen; cover the entire file. Return your structured extraction.`,
    { label: a, phase: 'Read', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))
const lenses = results.filter(r => r && r.result)
// A lens whose agent returned nothing must surface in unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['mode', 'detected_architecture', 'rules_index', 'unit_inventory', 'data_engine_drafts', 'cross_file', 'auto_fill', 'clarify_questions', 'coverage_by_lens', 'source_refs', 'unmerged'],
  properties: {
    mode: { type: 'string' },
    detected_architecture: { type: 'string' },
    rules_index: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unit_inventory: { type: 'array', items: { type: 'object', additionalProperties: true } },
    data_engine_drafts: { type: 'array', items: { type: 'object', additionalProperties: true } },
    cross_file: { type: 'object', additionalProperties: true },
    auto_fill: { type: 'array', items: { type: 'object', additionalProperties: true } },
    clarify_questions: { type: 'array', items: { type: 'string' } },
    coverage_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the /init-build COMPILE phase. Consolidate the 17 per-file COMPILE extractions below into ONE build digest. You WRITE NOTHING and you ADJUDICATE NOTHING — orchestrator-flow decides slicing/order/deps and writes spec.md + features.json.\nRules: detected_architecture from the data/integration evidence (relational|document|event_sourcing|stateful_langgraph|external_sor|ledger|file_store|mixed). rules_index: {id, kind, file, summary} for every ID owned. unit_inventory: {scr_id, slug, title, kind, platforms, order, after:[scr_id], source_refs:[id], applies:[id], data_bearing} per screen/unit implied by SCREENS/PRODUCT. data_engine_drafts: {scr_id, engine_refs, canonical_store_kind, write_path, read_path, single_value_contract:[{field,source,transport,client}]} per data-bearing unit. cross_file: {contradictions:[{ids,detail,files}], dangling_refs:[{id,cited_in}]} — FLAG only, do not resolve. auto_fill: structural/derivable proposals, proposed_fill VERBATIM. clarify_questions: deduped, the genuine product decisions. coverage_by_lens: {lens, covered}. Any missing/unparseable lens → unmerged[]. Build source_refs[] and keep file/source_files + IDs on every rule/unit/draft so orchestrator-flow can re-open the blueprint source. Never invent product intent.\n\nLenses that returned NO result (list each in unmerged[] with reason "no result returned"): ${JSON.stringify(failed_lenses)}\n\nPer-file extractions:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'compile-synthesizer' }
)


// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`compile-blueprint: the synthesis reducer returned no digest for the COMPILE phase. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest`: resolves CLARIFY, applies auto_fill, slices units, then writes spec.md + features.json.
return { digest, lenses, failed_lenses }
