---
name: init-build
description: Turn the human blueprint into executable orchestrator state. blueprint/ is the product source of truth; specialist agents feed context (architecture, gaps, data engine) and orchestrator-flow writes spec.md and features.json. Goal-driven, not a fixed recipe. Stops before product implementation.
argument-hint: [--reset-state]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /init-build

Run inline in the current main session. You are `orchestrator-flow`: the single writer of state. Specialist agents only read and feed you context. Do not use `context: fork` or `agent:`. Do not call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

`blueprint/` is the product source of truth (`PRODUCT.md`, `SCREENS.md`, `logic/*.md`). Your job is to compile it into executable state — never to invent product intent. This is goal-driven: the **contract** and **hard rules** below are fixed; the order of moves is your judgment.

## Contract — what must be true when this command stops

- `.orchestrator-state/features.json` is `initialized:true` and passes `python3 .orchestrator/scripts/validate-state.py`.
- `.orchestrator-state/spec.md` is the consolidated, grounded view of the blueprint.
- Every screen/unit traces to real blueprint source (`SCR-*`, `PRODUCT`/`BR-*`, `logic/*` IDs). No unit exists without source intent.
- The product **architecture is detected and recorded** (relational/document DB, event-sourcing, stateful/LangGraph, external system of record, mixed), and each data-bearing unit has a `data_engine` whose canonical store fits that architecture (AnyStack — never a client layer).
- Real stack commands are recorded in `.claude/rules/stack.md`, or the command stops in CLARIFY.
- No blocking blueprint gap remains unresolved.
- Nothing is built, published, deployed or accepted. State is written to disk and the command stops at human review of the plan.

## Hard rules (non-negotiable)

- Do not invent product intent. If the blueprint is missing, contradictory or ambiguous, CLARIFY with the human or stop — never guess.
- Single writer: only you write `blueprint/**` fills and `.orchestrator-state/**`. Agents read and inform; they do not write state.
- Disk is the source of truth. Rehydrate from disk; do not rely on chat memory.
- Per data unit there is exactly one canonical source of truth, and it is never a client/frontend.
- Build only what the blueprint and stack actually require; no speculative foundations.

## How — moves available to you (order is your judgment)

1. **Preflight.** Work from the repo root. Read `CLAUDE.md`, `.claude/rules/*.md`, the schemas and templates under `.orchestrator/`, and the worked examples in `.orchestrator/examples/` to know what good state looks like. Run `python3 .orchestrator/scripts/lint-blueprint.py` FIRST: its errors (duplicate IDs, dangling refs, after[] cycles) must be fixed in `blueprint/**` before launching any fan-out — they are structural, not product decisions; its warnings (stubs, missing acceptance) become CLARIFY input for step 3. If `$ARGUMENTS` has `--reset-state`, run `bash .orchestrator/scripts/reset-state.sh --force` first. Inspect `.orchestrator-state/features.json`: a `scaffold-placeholder` (`initialized:false`) may be replaced; an already-initialized state must stop with `Project already initialized; use /reslice or /init-build --reset-state`; malformed state must not be overwritten.

2. **Let the fan-out workflows feed you context (phase 0).** You hold the central thread and remain the writer; delegate the reading to read-only lens-agents and consume their structured extractions:
   - **COMPILE the blueprint** — **always launch the `compile-blueprint` workflow** (mandatory, not a preference): one `research-*` agent per blueprint file, in whole-blueprint COMPILE mode (14 `logic/*.md` — including `shell.md`, `engine.md` and `pipeline.md` — + `research-product` + `research-screens` + `research-design`), reading every file in parallel. Only if the Workflow capability is genuinely unavailable in this session, fall back to the `research-*` agents sequentially in compile mode (`inline-fallback`) — never as a shortcut. You consolidate their extractions into: the detected architecture, the `rules_index`, the full screen/unit inventory (slice `SCREENS.md` into `SCR-*` units with `order` + `after[]` dependencies), per-unit `data_engine` drafts, verification routes, and cross-file gaps/contradictions/`clarify_questions[]`.
   - **EXPLORE** — when a partial repo/stack already exists, **always launch the `explore-fanout` workflow** (`explore-scout` then `explore-{data,backend,ui,existing,tests}`; `inline-fallback` only if the Workflow capability is genuinely unavailable, never as a shortcut) to map real code, runtime entrypoints, test commands and available tooling.
   Pass the blueprint paths and the detected stack. Subagents have isolated context — give them what they need.

3. **Resolve clarity with the human.** Apply `auto_fill` proposals to `blueprint/**` only when purely structural/derivable. Batch the genuine product decisions (`clarify_questions[]`) into one CLARIFY round and wait for answers. Do not proceed while a blocking gap remains. Typical CLARIFY triggers: dangling/contradictory IDs, ambiguous order/dependency/route/platform/role/permission/state, unclear canonical store or architecture for a data unit, or stack commands that cannot be inferred.

3.5. **Architecture gate (`/arch-review`, mandatory).** With the blueprint clarified but BEFORE compiling `features.json`, run `/arch-review` (follow `.claude/skills/arch-review/SKILL.md`): launch the `arch-review` workflow — all 6 `arch-*` lenses + `arch-synthesizer` — over the blueprint. This is the only moment the architecture can change for free: research-* owns the ABSENCE, arch-* owns the ERROR. Write the report to `.orchestrator-state/evidence/APP-INTEGRATION/reports/arch-review.md` and the machine record to `features.json.meta.architecture_review` (statuses `clear` | `accepted_with_risk` | `deferred`; `architecture_hash` from `python3 .orchestrator/scripts/validate-state.py --arch-hash`). Every blocker resolves through one of the three human exits (emit a foundation unit into `SCREENS.md`, accept the risk via a `DEC-*` in `blueprint/DECISIONS.md`, or defer with a trip-wire) — the state cannot validate with `open_blockers[]` non-empty, and step 6's `--init-gate` refuses a project born without the review.

4. **Write the state (you are the writer).** Grounded in the agents' context and the blueprint, write:
   - `.orchestrator-state/spec.md`: product summary, business rules, logic index by ID, screen/unit map, platform map, the **architecture + data-engine map** (source rules → canonical store → pipeline → read model → clients, with single-value invariants), verification matrix, CLARIFY decisions, and blueprint/design hashes.
   - `.orchestrator-state/features.json`: valid against `.orchestrator/schemas/features.schema.json` and the validator. Each unit carries stable ID/slug/title/kind/platforms/order/dependencies/source refs/routes/applied IDs/acceptance criteria/verification plan/empty implementation arrays/evidence path/initial status. For data units, compile `data_engine` (engine refs, canonical store fit to the detected architecture, write/read path, generation/seed/backfill/replay method, `single_value_contract` mapping source→transport→client) and `verify.data_checks[]`. Initial status: no deps → `ready`; deps → `todo`; never start `verified`/`accepted`/`passes:true`.
   Create empty evidence containers only where useful (no PASS evidence). Append an `INIT_BUILD` entry to `.orchestrator-state/progress.md`.

5. **Bootstrap the stack.** Resolve and record the real install/dev/test/migrate/seed/smoke/build commands in `.claude/rules/stack.md` (fill the `<COMMAND_*>` placeholders). If commands remain unknown, return to CLARIFY.

6. **Gate (deterministic).** Run `python3 .orchestrator/scripts/validate-state.py --init-gate` (the `--init-gate` flag additionally requires `meta.architecture_review` to exist — a project cannot be born without the architecture review; on an already-initialized state the plain gate never demands it) and `bash .orchestrator/scripts/validate-structure.sh`. Run the setup/smoke commands recorded in `.claude/rules/stack.md` only when meaningful. If a gate fails because a product/stack decision is missing, return to CLARIFY — do not weaken the state to pass.

## Stop

Print the detected architecture, the `ready` units, any remaining (non-blocking) gaps, and the next command: `/next-pantalla`. Do not start building.
