---
name: accept
description: Human gate. Accept one verified screen/unit and unlock dependent units.
argument-hint: <screen-id>
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /accept

Run inline in the current main session. Do not implement code.

Arguments: `$ARGUMENTS`

## Preconditions

- ID exists in `.orchestrator-state/features.json`.
- status is `verified`.
- `passes:true`.
- evidence file exists.
- `result.json.verdict == "PASS"`.
- all required checks passed, including any checks added by `/review-pantalla`, `/verify-pipelines-data-ultracode` or `/production-code-review`.

- if the unit cites `DATA-*` or has `data_engine`, `result.json` contains passing `data_engine_assertions[]` proving engine -> canonical store -> API/service/read-model -> client equality (with observed literal `db_value`/`api_value`/`ui_value`), or a concrete not-applicable reason.
- `result.json.phase_runs[]` proves the full workflow cycle ran with complete lens sets (the STATE GATE enforces this; a unit that skipped a fan-out workflow cannot be accepted).
- failures are empty.

## Flow

1. Read `features.json` and the selected `result.json`.
2. Validate preconditions.
   - For data-bearing units, reject acceptance if the visible/API values are not proven to come from the declared canonical store value (falsifiable equality over observed literal db_value/api_value/ui_value).
   - The unit's `result.json` must be `verdict:"PASS"` with `passes:true`, and its `checks[]` must contain BOTH §5.5 auto-gate checks by id, each `passed:true`: `CHK-<ID>-PRODUCTION-CODE-REVIEW` and `CHK-<ID>-PIPELINES-DATA-ULTRACODE` (the latter may be `required:false, passed:true, notes:"not applicable"` when the unit cites no data engine). A missing check means that gate never ran — do not accept; hand back to `/next-pantalla <ID>`.
3. Run `python3 .orchestrator/scripts/validate-state.py`.
4. Change selected unit to `accepted`.
5. Mark `todo` dependents as `ready` when all `after[]` dependencies are accepted.
6. Append `ACCEPTED <ID>` to progress.
7. Validate again (`python3 .orchestrator/scripts/validate-state.py --emit-status` to refresh the external read projections).
8. **Cross-screen auto-gate:** if this acceptance completed one or more journeys (`JOUR-*` in `blueprint/logic/journey.md` whose UI screens are now ALL `accepted`), automatically run `/verify-app <JOUR-ID>` for each (follow `.claude/skills/verify-app/SKILL.md`). It reports seams (navigation, cross-screen values, shell coherence) and recommends; it never re-opens or moves any status by itself.
9. **Cross-architecture auto-gate:** on the same trigger (an acceptance that completed a journey), also run `/audit-motores` once (follow `.claude/skills/audit-motores/SKILL.md`). Where `/verify-app` walks the journey LIVE, this one audits the built product STATICALLY: every `ENG-*` implemented exactly once and faithful to its contract, the `PIPE-* → canonical store → ENG-* → read-model → screens` topology, real-data provenance, module coupling and scale profile. It reports and recommends — pending blueprint write-backs and architecture debt — and never moves any status.
10. Print the next suggested `/next-pantalla` command or project complete.

If evidence fails, do not repair here. Use `/next-pantalla <ID>`.
