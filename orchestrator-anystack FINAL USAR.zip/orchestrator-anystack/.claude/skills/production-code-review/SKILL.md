---
name: production-code-review
description: "Production-readiness review and optional cleanup for one screen/unit, path or project scope without relying on a diff. Checks code is shippable: no runtime TODOs/placeholders, no noisy comments, DRY without over-abstraction, YAGNI, KISS, errors, validation, security, tests and maintainability. Runs AUTOMATICALLY inside /next-pantalla after REVIEW (with --fix, sweeps on Sonnet); can also be re-run manually."
argument-hint: <screen-id|slug|name|path|all> [--fix|--report-only]
disable-model-invocation: true
model: sonnet
effort: xhigh
---

# /production-code-review

Run inline in the current main session. Do not use `context: fork` or call `Agent(orchestrator-flow)`. This gate runs **automatically** as part of every `/next-pantalla` (§5.5, with `--fix` on the active unit) and may also be invoked manually with any scope.

Arguments: `$ARGUMENTS`

Default mode is report-only. Repair only when `$ARGUMENTS` contains `--fix` (the auto-launch from `/next-pantalla` always passes `--fix`).

**Model:** spawn every subagent (explore-scout / explore-* sweeps) this gate uses with `model: 'sonnet'`; the conductor remains the single writer.

## 0. Resolve scope

1. Read `CLAUDE.md`, `.claude/rules/*.md`, `.orchestrator-state/spec.md`, `.orchestrator-state/features.json` and `.orchestrator-state/progress.md`.
2. Interpret `$ARGUMENTS`: `SCR-*`/slug/title reviews relevant feature files; a path reviews that path; `all` reviews app/product code and tests excluding dependency/build/generated directories.
3. If feature-scoped, run `explore-scout` (or the `explore-*` lens-agents) for relevant files and commands.
4. If scope is too broad, narrow it and state the chosen scope before edits.
5. If target is `accepted`, run report-only and recommend `/reslice` if the accepted contract should reopen.

## Status guard (before any --fix edit and before writing any verdict)

Apply per the target unit's status, mirroring the reopen protocol in `constitution.md` (Minimal lifecycle) and its sibling gates:
- **`building`** (the §5.5 auto-gate path, the normal case): repair freely; a FAIL leaves `passes:false` for the conductor to resolve — the unit is already in flight.
- **`verified`** (a manual `--fix` re-run): do NOT write `verified` + `passes:false`/`verdict:"FAIL"` — that state is rejected by the STATE GATE. If you repair its code or FAIL it, REOPEN it: set `status:"building"`, `passes:false`, `checkpoint:{"phase":"DEVELOP","iteration":<prev+1>}` (at the cap of 3, go `blocked` instead), require no other unit to be `building` (if one is, stop and hand to the human), record `REOPENED <ID> (production-code-review --fix|FAIL)` in `progress.md`, and hand back with `Next: /next-pantalla <ID>`. The re-VERIFY/re-VALIDATE there re-earns the PASS evidence.
- **`accepted`**: report-only (step 5 above); never auto-edit.

## 1. Review checklist

Production blockers:

- final `TODO`, `FIXME`, `HACK`, placeholder UI, fake responses, demo constants or mock-only acceptance paths;
- hardcoded secrets, tokens, private payloads or personal data;
- console/print/debug logs not suitable for production;
- commented-out code;
- broad catches that swallow errors;
- missing input validation at boundaries;
- missing permission/tenant/user scoping declared by `PERM-*`;
- invalid state transitions declared by `ST-*`;
- error behavior inconsistent with `ERR-*`;
- tests that pass without the real required backend/DB/provider boundary.

- frontend/mobile data constants, local JSON product truth, duplicated platform-specific business values or mock API paths used as acceptance behavior;
- pipelines that transform or generate data without persisting the canonical value in the declared canonical store (database, event store/projection, state store/checkpointer, ledger or external system of record).

Comments policy: remove comments that merely repeat code, narrate history or hide uncertainty. Keep only legal/license headers, public API docs required by the project, generated-code markers, lint/tooling markers, framework directives or non-obvious domain/security/provider rationale.

DRY / YAGNI / KISS:

- DRY only when duplication creates real maintenance risk or inconsistent behavior.
- Prefer small local functions over broad abstract frameworks.
- Delete unused code instead of routing around it.
- Keep names direct and domain-specific.
- Avoid configuration switches not used by the active contract.
- Simplify control flow without changing product behavior.

## 2. Optional fix

If `--fix` is present, apply the smallest safe cleanup, do not broaden architecture, do not prebuild future units, rerun relevant formatter/linter/type/test/smoke commands from `.claude/rules/stack.md`, and refresh evidence if needed.

If `--fix` is absent, do not modify code. Return prioritized findings with exact files, symbols and commands.

## 3. Evidence

For feature scope, write `.orchestrator-state/evidence/<ID>/reports/production-code-review.md`.

For path/all scope, write `.orchestrator-state/evidence/global/reports/production-code-review.md`.

Report format:

```markdown
# production-code-review

## Scope
## Commands/checks run
| Check | Command | Result | Evidence |
## Blocking findings
## Non-blocking cleanups
## Fixes applied
## Verdict
PASS|FAIL|BLOCKED
```

For feature scope, merge a check into `.orchestrator-state/evidence/<ID>/result.json.checks[]`:

```json
{
  "id": "CHK-<ID>-PRODUCTION-CODE-REVIEW",
  "name": "Production readiness review",
  "type": "production_code_review",
  "required": true,
  "passed": true,
  "acceptance_ids": [],
  "artifacts": [".orchestrator-state/evidence/<ID>/reports/production-code-review.md"],
  "notes": "No production blockers: no placeholders/TODO/mock-as-final, no secrets, DRY/YAGNI/KISS respected."
}
```

The check id is stable and required: `/accept` looks for it by id, and its ABSENCE means this gate never ran. Path/`all` scope writes no check (there is no unit to gate).

If the verdict is FAIL, merge the same check with `passed:false` and add the blocking findings to `result.json.failures[]`. On a unit that is already `verified`, apply the Status guard above (reopen to `building`) instead of leaving `verified` + `passes:false`, which the gate rejects. Never change an `accepted` unit automatically.

## 4. Close

Run `python3 .orchestrator/scripts/validate-state.py` and `bash .orchestrator/scripts/validate-structure.sh` after any state write.

End with:

```text
Scope: <screen/path/all>
Verdict: PASS|FAIL|BLOCKED
Report: <path>
Next: <exact next command>
```

Never move a screen to `accepted`.
