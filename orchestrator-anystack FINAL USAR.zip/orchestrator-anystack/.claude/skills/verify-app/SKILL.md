---
name: verify-app
description: "Optional cross-screen gate: drive the completed journeys (JOUR-*) end-to-end across accepted screens in the real runtime — navigation seams, cross-screen value consistency, shell coherence. Reports and recommends; never changes any unit's status."
argument-hint: "[JOUR-ID|all] [--include-verified]"
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /verify-app

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the anti-Frankenstein seam check — per-screen VALIDATE proves each screen alone; this proves the screens work **together**.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** `/accept` launches it when an acceptance completes a journey (all its UI screens `accepted`) — see accept step 8. **Manually:** any time on demand, with the SAME criterion — a journey is runnable only when all its UI screens are `accepted`. A journey whose screens are merely `verified` has not passed the human gate: run it only with the explicit `--include-verified` flag, and then step 3's report MUST tag every such screen `(verified, not accepted)` and downgrade that journey's verdict to `provisional`. Otherwise it stops and says exactly which screens block which journeys.

## Flow

1. Read `.orchestrator-state/features.json`, `blueprint/logic/journey.md` and `blueprint/logic/shell.md`. Run `python3 .orchestrator/scripts/validate-state.py` first — do not drive a broken state.
2. **Always launch the `validate-journeys` workflow** (mandatory, not a preference): a read-only loader resolves the runnable journeys from disk (`$ARGUMENTS` may pin one `JOUR-ID`; `--include-verified` is passed to the workflow as `include_verified: true` — the loader defaults to `accepted`-only (the human gate) and this flag is the only way to widen it to `verified` screens; the workflow returns each journey's `provisional` flag and its `unaccepted_screens[]` so step 3 can label the report), then one `validate-journey` lens per journey drives the real runtime — navigation per `UI-SHELL-002`/`UI-SHELL-004`, same canonical value on every screen that shows it, shell coherence in motion, permission gates across hops — plus `validate-logs` once. Only if the Workflow capability is genuinely unavailable, run the same lenses sequentially and record `inline-fallback`; never as a shortcut.
3. Consolidate (you are the writer) into `.orchestrator-state/evidence/APP-INTEGRATION/reports/verify-app.md`: per journey — verdict, hops table, observed cross-screen literals, findings with `JOUR-*`/`UI-SHELL-*`/`SCR-*` refs and artifact paths. Real observations only; a journey that could not run is reported `n/a` with the reason, never invented; and a journey run under `--include-verified` is labelled `provisional (includes screens not yet accepted: <IDs>)`.
4. **Route each finding to its owner — you never change a status here:**
   - a screen implemented out of contract → its evidence is stale: recommend re-VERIFY/re-VALIDATE of that `SCR-*` (via `/next-pantalla <ID>` on a reopened unit if the human agrees);
   - the shared contract itself is wrong or outgrown → recommend `/reslice` (which propagates staleness to dependent screens);
   - a missing nav entry/component that no screen owns → CLARIFY with the human, persist the answer in `blueprint/logic/shell.md`.
5. Append a `VERIFY_APP` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "VERIFY_APP" "APP-INTEGRATION"`), and print the report path plus the exact recommended next command.

## Hard rules

- Real runtime, real data (declared generation path), real observations — the evidence standard applies unchanged.
- This skill never moves any unit's lifecycle: not to `accepted`, not out of it. The STATE GATE and the human `/accept` remain the only anchors.
- Active-unit discipline does not apply here (this gate is cross-screen by design), but write access stays limited to `.orchestrator-state/evidence/APP-INTEGRATION/**` and `progress.md`.
