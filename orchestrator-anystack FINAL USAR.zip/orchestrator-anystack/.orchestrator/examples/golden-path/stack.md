# Stack and canonical commands — golden path "Notas rápidas"

Resolved commands for the worked example (web + SQLite). A real initialized project looks
like this: every `<COMMAND_*>` replaced with a runnable command. The smoke test mounts this
over `.claude/rules/stack.md` so the golden path exercises an already-resolved stack.

## Stack

- Runtime: Node.js 20
- Backend framework: Express
- Frontend framework: vanilla HTML + fetch
- Mobile framework: n/a (web-only)
- Canonical store (database / event store / state store / ledger / external system / file store): SQLite (WAL)
- ORM / migrations / schema tooling (if any): node-sqlite3 + a plain SQL migration
- Testing: node --test
- UI verification: Claude in Chrome → Chrome DevTools MCP
- Local URLs (web / API / other surfaces): http://localhost:3000 (web + API)

## Canonical commands

```bash
# install dependencies
npm ci

# prepare local environment
npm run setup

# start development server
npm run dev

# apply migrations
npm run migrate

# load minimal verifiable seed
npm run seed

# lint/static checks
npm run lint

# unit/integration tests
npm test

# build
npm run build

# minimal smoke check
npm run smoke
```
