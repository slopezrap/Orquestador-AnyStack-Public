# Integration Logic — proveedores externos

Sin integraciones externas: este producto no consume ningún sistema de terceros (decisión explícita de alcance, ver PRODUCT.md §3). No hay IDs `INT-*` activos.

Si el producto incorpora un proveedor (por ejemplo sincronización o backup remoto), se añade aquí su `INT-*` con frontera de adaptador, credenciales vía `.env` y verificación de sonda real — y se reconcilia vía `/reslice`.

La lente `research-integration` debe devolver `covered: n/a` para las pantallas actuales.
