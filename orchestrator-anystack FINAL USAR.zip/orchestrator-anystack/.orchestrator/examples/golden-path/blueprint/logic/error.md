# Error Logic — errores estructurados

## Reglas

### ERR-001 — Error estructurado y recuperable

```logic
id: ERR-001
type: error_contract
status: ready
summary: "Errores de validación → 422 {error:{code,message}}; la UI muestra mensaje recuperable sin perder contexto"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: []
severity: must
verification:
  observable_by: [api, ui, logs]
  evidence: [api_response, screenshot, server_log]
```

**Regla:** todo error de la API usa el sobre `{error: {code, message}}` (UI-SHELL-005): validación → `422 NOTE_TEXT_INVALID`; error inesperado → `500 INTERNAL` sin filtrar detalles internos. La UI traduce el `code` a un mensaje claro, permite reintentar y nunca pierde el texto escrito. Los errores se loguean en el servidor con su código, nunca con payloads privados.

**Verificable:** petición inválida real → 422 con el sobre exacto; captura de la UI en estado error con el texto conservado; log del servidor con el código.
