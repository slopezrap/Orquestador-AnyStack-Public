# Core Logic — arquitectura

## Reglas

### CORE-001 — Arquitectura relacional mínima

```logic
id: CORE-001
type: architecture
status: ready
summary: "Relacional: SQLite como almacén canónico, API Flask /api/v1, frontend web estático que solo lee vía API"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: []
severity: must
verification:
  observable_by: [code_review, api]
  evidence: [code_citation, api_response]
```

**Regla:** el almacén canónico es la base de datos SQLite `notas.db` (nunca el cliente). Toda lectura de producto pasa por la API (`service/api`); el frontend no define verdad propia ni usa fixtures locales. Capas separadas: dominio / aplicación / adaptadores (API, persistencia, UI).

**Verificable:** revisión de código: ningún valor de producto hardcodeado en el frontend; la API responde el mismo valor que la tabla.
