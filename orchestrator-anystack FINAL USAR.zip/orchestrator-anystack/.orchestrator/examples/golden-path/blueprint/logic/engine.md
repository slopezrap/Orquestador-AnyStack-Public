# Engine Logic — motores de la aplicación

## Reglas

No aplica a este producto.

```logic
id: ENG-NONE
type: engine_not_applicable
status: ready
summary: "Notas rápidas no tiene motor de decisión ni de transformación"
product_refs: [BR-001]
severity: must
not_applicable_reason: "La única regla del producto (texto de 1..500 caracteres) es un invariante de dominio DOM-001 aplicado por un CHECK del esquema y por la validación de entrada de APP-001. No hay decisión, derivación, agregación ni grafo de agentes: no existe un módulo motor que contratar, versionar ni explicar. Declararlo sería sobre-modelado (YAGNI/KISS)."
verification:
  observable_by: [test]
  evidence: [test_output]
```

**Regla:** este fichero se declara explícitamente no aplicable en lugar de dejarse vacío. Un producto SIN motor debe decirlo con una razón concreta, igual que `data_engine.not_applicable_reason`; el silencio no distingue "no hay motor" de "nadie lo pensó todavía".

**Verificable:** ninguna unidad de `features.json` cita un `ENG-*`, y `research-engine` devuelve `n/a` citando esta razón.
