# Shell Logic — contrato compartido entre pantallas

## Reglas

### UI-SHELL-001 — Shell global

```logic
id: UI-SHELL-001
type: shell_rule
area: shell
status: ready
summary: "Header con título 'Notas rápidas' + nav + <main>; toda pantalla renderiza dentro"
product_refs: [BR-001]
related_screens: [ALL]
depends_on: []
severity: must
platforms: [web]
verification:
  observable_by: [screenshot, e2e]
  evidence: [screenshot]
```

**Regla:** toda pantalla `kind: ui` renderiza dentro de la shell: header fijo con el título de la app y la navegación, contenido en `<main>`. Ninguna pantalla re-implementa su propia copia del header.

### UI-SHELL-002 — Mapa de navegación

```logic
id: UI-SHELL-002
type: shell_rule
area: navigation
status: ready
summary: "Una entrada: Notas → SCR-001; /notas es la ruta raíz de entrada"
product_refs: []
related_screens: [ALL]
depends_on: [UI-SHELL-001]
severity: must
platforms: [web]
verification:
  observable_by: [e2e, route_check]
  evidence: [flow_recording]
```

| Entrada | Pantalla (SCR-*) | Visible para (PERM-*) | Orden |
|---|---|---|---|
| Notas | SCR-001 | PERM-001 | 1 |

### UI-SHELL-003 — Inventario de componentes

```logic
id: UI-SHELL-003
type: shell_rule
area: components
status: ready
summary: "NoteCard y EmptyState son compartidos; se reutilizan, nunca se duplican"
product_refs: []
related_screens: [ALL]
depends_on: [UI-SHELL-001]
severity: must
platforms: [web]
verification:
  observable_by: [code_review, screenshot]
  evidence: [code_citation, screenshot]
```

| Componente | Propósito | Ubicación (al construirse) | Estados |
|---|---|---|---|
| NoteCard | Renderizar una nota | static/components/note-card.js | default |
| EmptyState | Listas vacías | static/components/empty-state.js | icono+mensaje+CTA |

### UI-SHELL-004 — Convención de rutas

```logic
id: UI-SHELL-004
type: shell_rule
area: routes
status: ready
summary: "Rutas web en kebab-case, plural para colecciones: /notas; API espejo bajo /api/v1"
product_refs: []
related_screens: [ALL]
depends_on: []
severity: must
platforms: [web]
verification:
  observable_by: [route_check]
  evidence: [code_citation]
```

**Regla:** un término por entidad (siempre "nota", nunca sinónimos); colecciones en plural (`/notas`, `/api/v1/notas`). Sin excepciones declaradas.

### UI-SHELL-005 — Contrato de API interna

```logic
id: UI-SHELL-005
type: shell_rule
area: api
status: ready
summary: "Base /api/v1; sobre {data}|{error:{code,message}}; errores según ERR-001"
product_refs: []
related_screens: [ALL]
depends_on: [ERR-001]
severity: must
platforms: [all]
verification:
  observable_by: [api_check]
  evidence: [api_response]
```

**Regla:** todo endpoint interno vive bajo `/api/v1`, responde `{data: ...}` en éxito y `{error: {code, message}}` en fallo. JSON siempre; sin endpoints fuera del sobre.
