# PRODUCT.md — plantilla de producto

> Este archivo es prosa de producto. No describas componentes, tablas, endpoints ni frameworks salvo que sean una restricción real de negocio.

## 0. Metadatos

```yaml
product_name: "<NOMBRE_DEL_PRODUCTO>"
version: "v1"
status: "draft"
owner: "<PERSONA_O_EQUIPO>"
last_reviewed: "YYYY-MM-DD"
markets: ["<PAIS_O_MERCADO>"]
platforms: [web, android, ios]
languages: [es]
```

## 1. Qué es

`<NOMBRE_DEL_PRODUCTO>` es `<DESCRIPCION_CORTA_EN_2_O_3_FRASES>`.

Debe quedar claro:

- Qué problema resuelve.
- Qué tarea permite completar.
- Qué resultado observable obtiene el usuario.
- Qué diferencia este producto de una solución manual o genérica.

## 2. Por qué existe

### Problema principal

`<DOLOR_O_NECESIDAD_DEL_USUARIO>`

### Coste de no resolverlo

`<QUE_OCURRE_HOY_SI_EL_USUARIO_NO_TIENE_ESTE_PRODUCTO>`

### Resultado esperado

`<RESULTADO_DE_NEGOCIO_O_USUARIO_QUE_DEBE_MEJORAR>`

## 3. Para quién

### Actores

| Actor | Descripción | Objetivo principal | Restricciones |
|---|---|---|---|
| `<ACTOR_1>` | `<QUIEN_ES>` | `<QUE_QUIERE_LOGRAR>` | `<LIMITES>` |
| `<ACTOR_2>` | `<QUIEN_ES>` | `<QUE_QUIERE_LOGRAR>` | `<LIMITES>` |

### Roles operativos

| Rol | Puede | No puede | Observaciones |
|---|---|---|---|
| `<ROL_1>` | `<ACCIONES>` | `<ACCIONES_PROHIBIDAS>` | `<NOTAS>` |

## 4. Alcance v1

Incluye solo lo que debe existir en la primera versión aceptable.

- `<CAPACIDAD_1>`
- `<CAPACIDAD_2>`
- `<CAPACIDAD_3>`

## 5. No-alcance v1

Lista explícita para evitar que el agente construya de más.

- `<FUERA_DE_ALCANCE_1>`
- `<FUERA_DE_ALCANCE_2>`
- `<FUERA_DE_ALCANCE_3>`

## 6. Reglas de negocio no negociables

Cada regla debe tener ID estable. Estas reglas pueden ser citadas por `SCREENS.md` y por `logic/*.md`.

### BR-001 — `<NOMBRE_DE_REGLA>`

```logic
id: BR-001
type: business_rule
status: draft
summary: "<RESUMEN_DE_LA_REGLA>"
rationale: "<POR_QUE_EXISTE>"
severity: must
applies_to: ["<ACTOR_O_PROCESO>"]
related_screens: [SCR-001]
related_logic: [DOM-001, UC-001, DATA-001]
```

**Regla:** `<DESCRIBE_LA_REGLA_EN_LENGUAJE_DE_NEGOCIO>`

**Ejemplos válidos:**

- `<EJEMPLO_VALIDO>`

**Contraejemplos:**

- `<EJEMPLO_QUE_NO_DEBE_PERMITIRSE>`

**Implicación para aceptación:** `<COMO_SE_OBSERVA_QUE_SE_CUMPLE>`

## 7. Principios de experiencia

- `<PRINCIPIO_1>`
- `<PRINCIPIO_2>`
- `<PRINCIPIO_3>`

Ejemplo: "El usuario siempre debe saber qué ha pasado, qué puede hacer después y si sus datos han quedado guardados".

## 8. Tono, marca y comunicación

### Voz

`<FORMAL_CERCANA_TECNICA_INSTITUCIONAL_ETC>`

### Microcopy prohibido

- `<PALABRA_O_TONO_A_EVITAR>`

### Microcopy obligatorio

- `<PALABRA_O_TONO_A_USAR>`

## 9. Restricciones legales, compliance o seguridad

- `<RESTRICCION_1>`
- `<RESTRICCION_2>`

## 10. Métricas de éxito

| Métrica | Definición | Cómo se observa en v1 |
|---|---|---|
| `<METRICA_1>` | `<DEFINICION>` | `<EVENTO_O_COMPROBACION>` |

## 11. Supuestos

- `<SUPUESTO_1>`
- `<SUPUESTO_2>`

## 12. Preguntas abiertas

| ID | Pregunta | Impacto si no se resuelve | Decisión |
|---|---|---|---|
| Q-001 | `<PREGUNTA>` | `<IMPACTO>` | `<PENDIENTE_O_DECISION>` |

## 13. Checklist de calidad

- [ ] El producto se entiende sin leer código.
- [ ] El alcance v1 es construible y verificable.
- [ ] El no-alcance evita sobreconstrucción.
- [ ] Las reglas `BR-*` son observables.
- [ ] Los actores y roles están definidos.
- [ ] No hay decisiones técnicas disfrazadas de necesidad de producto.
