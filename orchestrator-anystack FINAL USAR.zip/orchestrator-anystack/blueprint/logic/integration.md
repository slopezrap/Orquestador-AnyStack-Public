# Integration Logic — sistemas externos

Define APIs, webhooks, colas, jobs, pagos, correo, contratos, retry e idempotencia. Plantilla completa: `blueprint-templates/logic/integration-template.md`.

## Reglas

### INT-001 — Pendiente de definir

```logic
id: INT-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
