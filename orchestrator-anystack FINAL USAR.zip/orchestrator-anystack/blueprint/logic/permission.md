# Permission Logic — autorización y ownership

Define quién puede hacer qué, sobre qué recurso, bajo qué condición y cómo se audita. Plantilla completa: `blueprint-templates/logic/permission-template.md`.

## Reglas

### PERM-001 — Pendiente de definir

```logic
id: PERM-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
