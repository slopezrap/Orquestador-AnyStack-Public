# Error Logic — fallos y recuperación

Define errores esperados, mensajes visibles, recuperación, logging y severidad. Plantilla completa: `blueprint-templates/logic/error-template.md`.

## Reglas

### ERR-001 — Pendiente de definir

```logic
id: ERR-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.

### ERR-002 — Pendiente de definir (errores de la unidad backend — lo cita SCR-002)

```logic
id: ERR-002
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
