# Data Logic — motor, persistencia y evidencia

Define el motor de datos que alimenta el producto: modelos, ownership, consultas, constraints, seeds/generadores, migraciones, pipelines, retencion y privacidad. Plantilla completa: `blueprint-templates/logic/data-template.md`.

Regla central: todo dato de producto que aparezca en una pantalla debe tener origen persistido o una justificacion explicita. La base de datos es el valor canonico; web, Android e iOS deben leer ese mismo valor por API/servicio/read model.

## Reglas

### DATA-001 — Pendiente de definir

```logic
id: DATA-001
type: data_engine
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
canonical_store:
  source_of_truth: database
  resources: []
pipeline:
  generation_method: "migration|seed|backfill|job|api_write|user_action|pending"
  writes_to_database: true
  read_path: [database, service_api, frontend_mobile]
single_value_contract: []
verification:
  observable_by: [db, api, ui]
  evidence: [db_query, api_response, screenshot_or_mobile_capture]
```

**Regla:** Pendiente.

**Verificable:** Pendiente.

### DATA-002 — Pendiente de definir (identidad, perfil y sesión — lo cita SCR-FOUNDATION-AUTH)

```logic
id: DATA-002
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
canonical_store:
  source_of_truth: database
  resources: []
pipeline:
  generation_method: "migration|seed|backfill|job|api_write|user_action|pending"
  writes_to_database: true
  read_path: [database, service_api, frontend_mobile]
single_value_contract: []
verification:
  observable_by: [db, api, ui]
  evidence: [db_query, api_response, screenshot_or_mobile_capture]
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
