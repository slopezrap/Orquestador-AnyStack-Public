# State Logic — estados y transiciones

Define estados, transiciones válidas/prohibidas, concurrencia y estados visibles. Plantilla completa: `blueprint-templates/logic/state-template.md`.

## Reglas

### ST-001 — Pendiente de definir

```logic
id: ST-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
