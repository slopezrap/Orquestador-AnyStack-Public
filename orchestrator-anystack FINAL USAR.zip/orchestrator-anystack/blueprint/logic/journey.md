# Journey Logic — recorridos end-to-end

Define recorridos de usuario entre pantallas, ramas, errores y resultado final. Plantilla completa: `blueprint-templates/logic/journey-template.md`.

## Reglas

### JOUR-001 — Pendiente de definir

```logic
id: JOUR-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
