# SCREENS.md — conductor plane template

> This file drives the build. Every `SCR-*` section must be convertible into an entry in `.orchestrator-state/features.json` during `/init-build`.

## 0. Screen and foundation index

| Order | ID | Type | Name | Platform | Route/deeplink | Depends on | Design | Status |
|---:|---|---|---|---|---|---|---|---|
| 1 | SCR-FOUNDATION-SCHEMA | foundation | Base schema | all | null | [] | null | draft |
| 2 | SCR-FOUNDATION-AUTH | foundation | Authentication | all | null | [SCR-FOUNDATION-SCHEMA] | null | draft |
| 3 | SCR-FOUNDATION-SHELL | foundation | Shared shell and design system | web/android/ios | null | [SCR-FOUNDATION-AUTH] | `design/screens/<shell-reference-file>` | draft |
| 4 | SCR-FOUNDATION-ENGINE-<NAME> | foundation | Shared engine foundation | all | null | [SCR-FOUNDATION-SCHEMA] | null | draft |
| 5 | SCR-FOUNDATION-PIPELINE-<NAME> | foundation | Shared pipeline foundation | all | null | [SCR-FOUNDATION-SCHEMA] | null | draft |
| 6 | SCR-WALKING-SKELETON-<NAME> | ui | Walking skeleton (thinnest real path) | web | `/<minimal-debug-or-real-route>` | [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-PIPELINE-<NAME>, SCR-FOUNDATION-ENGINE-<NAME>] | null | draft |
| 10 | SCR-001 | ui | `<SCREEN_NAME>` | web/android/ios | `<ROUTE>` | [SCR-FOUNDATION-SHELL] | `design/screens/<file>` | draft |

## 1. Recommended foundations

Foundations are not visible screens, but they are units the orchestrator must build and accept before dependent screens.

**Decision rule for engine/pipeline foundations (derivable, no CLARIFY needed):** an `ENG-*`/`PIPE-*` earns its own foundation only if its `module.consumed_by` (engines, `engine-template.md:45`) or `related_screens`/`feeds` (pipelines) names MORE THAN ONE `SCR-*`, or a `SCR-*` different from the one that introduces it. With a single consumer, the engine/pipeline lives inside that screen's vertical slice — shared support code the active unit needs, not a foundation (YAGNI, `constitution.md`: "do not build speculative abstractions").

**Corollary — thin vertical slice first.** Multiple consumers justify listing something as a foundation; they never justify building it before anything proves it. For every `SCR-FOUNDATION-ENGINE-*`/`SCR-FOUNDATION-PIPELINE-*` you declare, also declare — in the same pass, not a later phase — the thinnest real `kind: ui`/`kind: backend` unit that exercises it end to end: the `SCR-WALKING-SKELETON-*` unit below. Set that consumer's `order` immediately after the foundation's, never several foundations later. A foundation with no consumer scheduled within a few `order` numbers is not a foundation, it is unproven scaffolding — nothing in the plan will run it, so nothing in VERIFY/VALIDATE catches a wrong contract until whatever eventually depends on it. This is not hypothetical: on the one project this orchestrator has actually shipped, a blueprint classified 9 `ENG-*` and 14 `PIPE-*` as pure foundation, spent 3 days and 75 tables, and shipped 0 lines of executed product behavior — the schema unit alone iterated 14 times because nothing ever ran it.

### Repair units (`SCR-FIX-*`) — emitted, never hand-written

You do not author these. The two cross gates write them when they find a concrete defect that the code owns: `/verify-app` emits `SCR-FIX-VERIFY-APP-<nnn>` for a broken journey seam, `/audit-motores` emits `SCR-FIX-AUDIT-<nnn>` for architecture debt. They exist so a gate's finding becomes work the loop actually picks up instead of a paragraph in a report nobody reads.

A repair unit is an ordinary unit in every respect that matters — born `todo`, full pipeline, full evidence standard, still gated by `/accept`. Its one extra field is `remediates[]`: the units whose behaviour was wrong. Note that it *never* changes their status; the repair lands as new work sitting after them.

```screen
id: SCR-FIX-VERIFY-APP-001
kind: fix
platforms: [web]
route: null
order: <after the screens it repairs>
after: [SCR-004, SCR-007]        # the screens whose seam broke
applies: [JOUR-002, UI-SHELL-002]  # the rules the repair must satisfy
remediates: [SCR-004, SCR-007]   # what drifted — traceability, not a status change
status: draft
acceptance:
  - "<the finding's own wording, copied verbatim — a repaired defect is proven against
     what was observed, not against a paraphrase of it>"
```

`remediates` is a reference list like `after`/`applies`: `lint-blueprint.py` checks every id in it resolves to a real block, so a repair unit cannot cite a screen nobody defines.

### SCR-FOUNDATION-SCHEMA — Base data schema

```screen
id: SCR-FOUNDATION-SCHEMA
slug: schema
kind: foundation
platforms: [all]
route: null
order: 1
after: []
applies: [CORE-001]
# NOT DATA-001, deliberately — citing a DATA-* makes this unit a data-bearing unit, and
# the gate then demands a full data_engine including a single_value_contract mapping
# store -> API -> client. A schema-only foundation has no API and no client yet, so it
# cannot fill that honestly. The schema still IMPLEMENTS DATA-001; it is the units that
# read and write through it that carry the contract. The golden-path reference does
# exactly this (.orchestrator/examples/golden-path/blueprint/SCREENS.md).
design_ref: null
acceptance:
  - When migrations are run from scratch, the system shall create the required schema without errors.
  - When the base schema is queried, the system shall expose the tables, collections or models defined by DATA-001.
verify:
  tests:
    - "<SCHEMA_TEST_COMMAND>"
  commands:
    - "<MIGRATIONS_COMMAND>"
  ui_states: []
  data_check:
    db_query: "<SCHEMA_QUERY_OR_COMMAND>"
    expect: "The schema exists and matches DATA-001."
  evidence_required:
    - migration_log
    - schema_snapshot
```

### SCR-FOUNDATION-AUTH — Authentication and session

```screen
id: SCR-FOUNDATION-AUTH
slug: auth
kind: foundation
platforms: [all]
route: null
order: 2
after: [SCR-FOUNDATION-SCHEMA]
applies: [PERM-001, DATA-002, ERR-001]
design_ref: null
acceptance:
  - When a user registers with valid credentials, the system shall create a persisted identity and a valid session.
  - When a user logs in with valid credentials, the system shall establish an authenticated session.
  - When an unauthenticated user accesses a protected resource, the system shall block access and log the attempt according to PERM-001.
verify:
  tests:
    - "<AUTH_TEST_COMMAND>"
  commands:
    - "<AUTH_SMOKE_COMMAND>"
  ui_states: []
  data_check:
    db_query: "<AUTH_QUERY>"
    expect: "The identity, profile and session comply with DATA-002 and PERM-001."
  evidence_required:
    - auth_test_log
    - db_snapshot
```

### SCR-FOUNDATION-SHELL — Shared shell and design system

Build the cross-screen contract ONCE, before any visible screen: the shell/layout every screen renders inside, the navigation skeleton, the initial reusable component inventory and the design-token wiring. Every `kind: ui` screen should list this foundation in `after` so screens built one at a time stay coherent with each other. If the product has more than one UI screen and this foundation is missing, `/init-build` should flag it as a gap (checklist below).

```screen
id: SCR-FOUNDATION-SHELL
slug: shell
kind: foundation
platforms: [web, android, ios]
route: null
order: 3
after: [SCR-FOUNDATION-AUTH]
applies: [UI-SHELL-001, UI-SHELL-002, UI-SHELL-003, UI-SHELL-004, UI-SHELL-005]
design_ref: "design/screens/<shell-reference-file>"
acceptance:
  - When any screen route is opened, the system shall render it inside the shared shell (header/navigation/footer per UI-SHELL-001), never a per-screen copy.
  - When the navigation map (UI-SHELL-002) is rendered for a role, the system shall show exactly the entries that role's permissions allow.
  - When a screen needs a shared visual pattern, the system shall provide it from the component inventory (UI-SHELL-003) with its declared states.
  - When any component declares color/typography/spacing, the system shall consume tokens from design/tokens.css, not hardcoded values.
verify:
  tests:
    - "<SHELL_TEST_COMMAND>"
  commands:
    - "<SHELL_SMOKE_COMMAND>"
  ui_states: [loading, success]
  data_check:
    db_query: null
    expect: "Not applicable: the shell renders no product data of its own."
  evidence_required:
    - screenshot_or_recording
    - test_output
```

### SCR-FOUNDATION-ENGINE-`<NAME>` — Shared engine foundation

Build once, before any screen that consumes it, exactly when the decision rule above triggers: `ENG-*`'s `module.consumed_by` names more than one `SCR-*`. A single-consumer engine stays inside that screen's vertical slice and does not get a foundation.

```screen
id: SCR-FOUNDATION-ENGINE-<NAME>
slug: engine-<name>
kind: foundation
platforms: [all]
route: null
order: 4
after: [SCR-FOUNDATION-SCHEMA]
applies: [ENG-001, DOM-001, DATA-001, ERR-001]
design_ref: null
acceptance:
  - "When ENG-001's `determinism` is `deterministic`, the system shall reproduce `engine_value` from `input_value` and match `stored_value` with literal, recomputable equality (input_value -> engine_value -> stored_value), per engine-template.md's `engine_assertions[]`."
  - "When ENG-001's `determinism` is `agent_graph`, the system shall pass the golden-set evaluation at or above its declared `threshold`, persist a checkpoint readable back from the canonical state store, and exercise the declared `fallback` at least once."
verify:
  tests:
    - "<ENGINE_TEST_COMMAND>"
  commands:
    - "<ENGINE_SMOKE_COMMAND>"
  ui_states: []
  data_check:
    db_query: "<ENGINE_OUTPUT_QUERY>"
    expect: "The engine's decision/output is observable in a decision trace, log, store or eval output, and matches ENG-001's contract."
  evidence_required:
    - decision_trace
    - test_output
    - db_query
```

### SCR-FOUNDATION-PIPELINE-`<NAME>` — Shared pipeline foundation

Build once, before any screen that depends on it, exactly when the decision rule above triggers: `PIPE-*`'s `related_screens`/`feeds` names more than one `SCR-*`. A single-consumer pipeline stays inside that screen's vertical slice and does not get a foundation.

```screen
id: SCR-FOUNDATION-PIPELINE-<NAME>
slug: pipeline-<name>
kind: foundation
platforms: [all]
route: null
order: 5
after: [SCR-FOUNDATION-SCHEMA]   # add the engine foundation too when the pipeline feeds it
applies: [PIPE-001, DATA-001]
design_ref: null
acceptance:
  - "When PIPE-001's trigger fires, the system shall run the pipeline and the produced value shall land in the declared canonical store."
  - "When PIPE-001 is re-run over the same window, the system shall prove idempotency via its `guarantees.idempotency_key`: the output does not duplicate or diverge."
verify:
  tests:
    - "<PIPELINE_TEST_COMMAND>"
  commands:
    - "<PIPELINE_RUN_COMMAND>"
  ui_states: []
  data_check:
    db_query: "<PIPELINE_OUTPUT_QUERY>"
    expect: "The canonical store holds the produced rows/events; `how_to_prove_it_ran` resolves to a real run."
  evidence_required:
    - logs/pipeline-run.txt
    - db/pipeline-output-check.txt
```

### SCR-WALKING-SKELETON-`<NAME>` — Walking skeleton (thinnest real path: source → pipeline → engine → verifiable output → one route)

**Shell note, decide it deliberately.** This mold ships WITHOUT `SCR-FOUNDATION-SHELL` in `after[]` on purpose: a walking skeleton is allowed to render on a bare debug route, and making it wait for the shared shell would re-create the very queue it exists to jump. But the checklist rule still stands for anything real — the moment this unit uses a route users will see, add `SCR-FOUNDATION-SHELL` to `after[]` and reuse the shared chrome, or it becomes the first screen that quietly diverges from the shell contract every other screen honours. Nothing enforces this mechanically; it is your call, and the cross-screen coherence lens (`verify-coherence`) will judge it later.

The corollary to the decision rule above, made concrete. A `SCR-FOUNDATION-ENGINE-*`/`SCR-FOUNDATION-PIPELINE-*` earns the right to keep existing only once something in the plan actually runs it. Build this unit in the SAME pass as the foundation it proves, `order` it immediately after — never behind further foundations — and keep it deliberately thin: no polish beyond what AUTO-007's three states require, no edge cases beyond what the cited `ST-*`/`ERR-*` already contract. When the product has no UI surface yet, use `kind: backend`, `route: null`, drop the `platforms`/`web:` block below and prove the same chain through `db_query`/`api_probe` alone. If the capability cannot be proven this thin, that is itself evidence for `arch-risk`'s sequencing question: the "foundation" was never separable from the product.

This is how one real project avoided becoming the other one. On the one project this orchestrator has actually shipped, a blueprint classified 9 `ENG-*` and 14 `PIPE-*` as pure "cimiento": 3 days, 75 tables, 0 lines of executed product behavior. The unit holding the schema iterated 14 times because nothing ever ran it — every REVIEW found something real, and nothing closed the loop. The one unit in that same project that DID have a real consumer reached `verified` in 78 launches; the one that didn't took 307. A walking skeleton is the cheapest way to buy that difference: prove the path once, thinly, before authorizing the next foundation on top of it.

```screen
id: SCR-WALKING-SKELETON-<NAME>
slug: walking-skeleton-<name>
kind: ui
platforms: [web]
route:
  web: "/<minimal-debug-or-real-route>"
order: 6
after: [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-PIPELINE-<NAME>, SCR-FOUNDATION-ENGINE-<NAME>]
# Cite ONLY the foundations you actually declared. The decision rule scores ENG-* and
# PIPE-* independently, so a <NAME> may earn a pipeline foundation and no engine one
# (or the reverse) — the engine then lives inside this slice as shared support code.
# Drop the reference you did not declare: leaving it makes after[] dangle, and
# lint-blueprint.py will reject it at /init-build.
applies: [PIPE-001, ENG-001, DATA-001, ERR-001]
data_engine:
  # engine_refs is DATA/APP/UC/DOM/PERM ONLY (constitution.md, "Data engine authority").
  # ENG-001/PIPE-001 are cited in `applies` above, never here — conflating the two fields
  # is the exact confusion that rule exists to prevent.
  engine_refs: [DATA-001]
  canonical_store:
    source_of_truth: "<database | event_store | state_store | ledger | external_system | file_store>"
    resources: ["<table_or_collection_or_stream>"]
  pipeline:
    writes_to_database: true
    generation:
      required: true
      method: "<job|event_replay|state_transition|api_write>"
      no_frontend_fixtures: true
    write_path: ["PIPE-001", "ENG-001", "<table_or_collection_or_stream>"]
    read_path: ["<canonical store>", "service/api", "<the minimal route above>"]
  single_value_contract:
    - field: "<the one value this skeleton proves, end to end>"
      db_source: "<table_or_stream>.<field>"
      api_field: "<response.path>"
      ui_field: "<selector_or_widget, or 'db-query only' if no UI surface exists yet>"
      invariant: "the value ENG-001 produced from real source data is the value visible at the end of the path"
design_ref: null
acceptance:
  - "When a real source event/record enters via PIPE-001's declared trigger, the system shall carry it through ENG-001 and land the produced value in the declared canonical store."
  - "When the produced value is queried through the declared read path (canonical store -> API/service -> the minimal route above), the system shall return the SAME literal value at every layer."
  - "When the source event is malformed or ENG-001's declared error case fires, the system shall surface the ERR-* this path already contracts, not a silent drop."
verify:
  tests:
    - "<PIPELINE_TEST_COMMAND>"
    - "<ENGINE_TEST_COMMAND>"
  commands:
    - "<PIPELINE_RUN_COMMAND>"
  ui_states: [loading, success, error]
  data_check:
    engine_refs: [DATA-001]
    db_query: "<REAL_QUERY_PROVING_THE_PRODUCED_VALUE>"
    api_probe: "<REAL_ENDPOINT_OR_SERVICE, when one already exists>"
    visible_selector_or_finder: "<SELECTOR_OR_WIDGET, or 'none: db/API only' when there is no UI surface yet>"
    expect: "The value observed at the source matches what ENG-001 produced, matches what PIPE-001 persisted, and matches what the minimal route displays or returns."
  evidence_required:
    - logs/pipeline-run.txt
    - traces/engine-decision.json
    - db/pipeline-output-check.txt
    - result_json
```

## 2. UI screen template

Copy this block for each visible screen. A screen must represent a complete vertical slice: data, logic, API, UI and verification.

### SCR-001 — `<VISIBLE_SCREEN_NAME>`

#### What it builds

`<DESCRIPTION_OF_THE_VISIBLE_CAPABILITY_AND_VALUE_FOR_THE_USER>`

#### Main actor

`<ACTOR_OR_ROLE>`

#### User entry

- From: `<ORIGIN_SCREEN_OR_EVENT>`
- With prior data: `<REQUIRED_DATA>`
- Expected initial state: `<LOADING_EMPTY_ERROR_SUCCESS_OR_OTHER>`

#### Output or result

- Expected persistence: `<WHAT_DATA_CHANGES>`
- Next navigation: `<DESTINATION>`
- Visible feedback: `<MESSAGE_TOAST_STATE_ETC>`

#### Applied rules

List only IDs that exist in `PRODUCT.md` or `logic/*.md`.

- BR-001
- DOM-001
- UC-001
- APP-001
- PERM-001
- ST-001
- ERR-001
- INT-001
- UI-001
- DATA-001

#### Design and references

- Visual design: `design/screens/<file>`
- Tokens: `design/tokens.css`
- Responsive notes: `<BREAKPOINTS_OR_RULES>`
- Existing components to reuse: `<COMPONENTS>`

#### Observable criteria

Use EARS format where possible.

- When `<CONDITION>`, the system shall `<OBSERVABLE_RESULT>`.
- While `<STATE>`, the system shall `<OBSERVABLE_RESULT>`.
- If `<ERROR_EVENT>`, the system shall `<OBSERVABLE_RESULT_AND_RECOVERY>`.
- Where `<CONTEXT>`, the system shall `<RULE>`.

```screen
id: SCR-001
slug: "<stable-slug>"
kind: ui
platforms: [web, android, ios]
route:
  web: "/<route>"
  android: "app://<deeplink>"
  ios: "app://<deeplink>"
order: 10
after: [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-AUTH, SCR-FOUNDATION-SHELL]
applies: [BR-001, DOM-001, UC-001, APP-001, PERM-001, ST-001, ERR-001, UI-001, DATA-001]
data_engine:
  engine_refs: [DATA-001, APP-001, UC-001, DOM-001, PERM-001]
  canonical_store:
    source_of_truth: database
    resources: ["<table_or_collection>"]
  pipeline:
    writes_to_database: true
    generation:
      required: true
      method: "<migration|seed|backfill|job|api_write|user_action>"
      no_frontend_fixtures: true
    write_path: ["APP-001", "repository", "<table_or_collection>"]
    read_path: ["database", "service/api", "frontend/mobile"]
  single_value_contract:
    - field: "<business_field>"
      db_source: "<table>.<field>"
      api_field: "<response.path>"
      ui_field: "<selector_or_widget>"
      invariant: "same value for the same user/tenant/permission context"
design_ref: "design/screens/<file>"
acceptance:
  - "When the user opens the screen, the system shall display a loading state while fetching real data."
  - "When no data exists for the current user, the system shall display an empty state with a clear primary action."
  - "When the operation fails, the system shall display a recoverable message and allow retry without losing context."
  - "When persisted data exists, the system shall display exactly the records authorized for the current user."
verify:
  test_level: e2e
  tests:
    - "<THIS_SCREEN_TEST_COMMAND>"
  commands:
    - "<BACKEND_LOGS_COMMAND>"
    - "<DB_CHECK_COMMAND>"
  web:
    preferred_tools: [claude_chrome, chrome_devtools_mcp]
    required_evidence: [screenshot, console_log, network_log]
    viewports:
      - { name: desktop, width: 1440, height: 900 }
      - { name: mobile_web, width: 390, height: 844 }
  mobile:
    framework: flutter
    android:
      required_evidence: [screenshot, adb_logcat, flow_record]
      commands:
        - "adb devices"
        - "adb logcat -d"
    ios:
      required_evidence: [screenshot, idb_log, flow_record]
      commands:
        - "idb list-targets"
        - "xcrun simctl list devices"
  ui_states: [loading, empty, error, success]
  data_check:
    engine_refs: [DATA-001, APP-001, UC-001]
    db_query: "<REAL_QUERY_THAT_CHECKS_WHAT_IS_VISIBLE>"
    api_probe: "<REAL_ENDPOINT_OR_SERVICE>"
    visible_selector_or_finder: "<SELECTOR_OR_WIDGET>"
    expect: "Visible data matches DB and API/read model, and respects permissions."
  logs_check:
    frontend: "No console/runtime errors."
    backend: "No 5xx errors or unhandled exceptions."
    database: "No constraint violations or invalid queries."
  evidence_required:
    - result_json
    - screenshot_or_recording
    - test_output
    - db_check_output
```

## 3. Backend/data unit template (no UI)

### SCR-002 — `<BACKEND_OR_DATA_UNIT_NAME>`

```screen
id: SCR-002
slug: "<stable-slug>"
kind: backend
platforms: [all]
route: null
order: 20
after: [SCR-FOUNDATION-SCHEMA]
applies: [APP-002, DATA-002, ERR-002]
design_ref: null
acceptance:
  - "When the use case is invoked with valid input, the system shall persist the expected result."
  - "When the input is invalid, the system shall reject it with a controlled error and no partial side effects."
verify:
  tests:
    - "<BACKEND_TEST_COMMAND>"
  commands:
    - "<BACKEND_LOGS_COMMAND>"
  ui_states: []
  data_check:
    db_query: "<REAL_QUERY>"
    expect: "The persisted state complies with DATA-002."
  evidence_required:
    - test_output
    - db_snapshot
    - backend_log
```

## 4. Checklist before `/init-build`

- [ ] Every section has a unique `SCR-*` `id`.
- [ ] `order` defines a clear sequence.
- [ ] `after` only references existing screens or foundations.
- [ ] `applies` only references existing IDs.
- [ ] Every UI screen declares how to verify web, mobile or both as applicable.
- [ ] Every UI screen includes `loading`, `empty`, `error`, `success` states, unless justified.
- [ ] Every screen has observable acceptance criteria.
- [ ] Every screen with data has `data_engine` and `data_check`.
- [ ] Every visible datum maps DB -> API/read model -> UI/mobile.
- [ ] No screen depends on frontend constants, local JSON or mocks for data acceptance.
- [ ] Every foundation has verifiable evidence.
- [ ] If the product has more than one UI screen, `SCR-FOUNDATION-SHELL` exists, every UI screen lists it in `after`, and `blueprint/logic/shell.md` defines the shared shell/navigation/components/routes (`UI-SHELL-*`).
- [ ] If an ENG-*/PIPE-* is consumed by more than one screen, a SCR-FOUNDATION-ENGINE-*/PIPELINE-* unit exists and every consumer lists it in after[].
- [ ] Every SCR-FOUNDATION-ENGINE-*/PIPELINE-* has a SCR-WALKING-SKELETON-* (or an equivalent thin real kind:ui/backend consumer) scheduled within a few order numbers of it — never deferred behind further foundations.
