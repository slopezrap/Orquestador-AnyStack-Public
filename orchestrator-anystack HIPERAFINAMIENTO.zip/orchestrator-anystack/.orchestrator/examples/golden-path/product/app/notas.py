"""FIXTURE del golden path — stub minimo. Existe para que source_manifest cite ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. Sigue el contrato del blueprint (DATA-001, DOM-001, ERR-001), no es codigo de produccion.

APP-001: unica via de escritura sobre la tabla notas (DATA-001).
"""
from domain.nota import Nota, validar_texto


def crear_nota(store, texto: str) -> Nota:
    return store.insertar(texto=validar_texto(texto))


def listar_notas(store) -> list[Nota]:
    return store.listar_desc()
