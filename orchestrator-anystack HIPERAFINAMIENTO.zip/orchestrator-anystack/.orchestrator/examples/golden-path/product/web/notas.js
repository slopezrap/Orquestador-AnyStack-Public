// FIXTURE del golden path — stub minimo. Existe para que source_manifest cite ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. Sigue el contrato del blueprint (DATA-001, DOM-001, ERR-001), no es codigo de produccion.
// UI-001/ST-001: estados carga/vacio/error. ERR-001: conserva el texto escrito al fallar.
// El literal visible vive en [data-testid=note-text] (DATA-001).
const API = "/api/v1/notas";

export async function cargarNotas(render) {
  render({ estado: "cargando" });
  const r = await fetch(API);
  const payload = await r.json();
  render(payload.data.length ? { estado: "ok", notas: payload.data } : { estado: "vacio" });
}

export async function crearNota(texto, render) {
  const r = await fetch(API, { method: "POST", body: JSON.stringify({ texto }) });
  const payload = await r.json();
  if (r.status === 422) return render({ estado: "error", code: payload.error.code, texto });
  return cargarNotas(render);
}
