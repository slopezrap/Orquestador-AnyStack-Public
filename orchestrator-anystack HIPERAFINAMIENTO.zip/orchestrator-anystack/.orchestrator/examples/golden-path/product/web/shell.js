// FIXTURE del golden path — stub minimo. Existe para que source_manifest pueda citar ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. No es codigo de producto.
export function montarShell(root) { root.dataset.ready = "1"; }
