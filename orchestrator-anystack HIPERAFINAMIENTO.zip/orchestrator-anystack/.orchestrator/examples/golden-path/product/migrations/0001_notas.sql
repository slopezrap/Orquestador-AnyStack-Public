-- FIXTURE del golden path — stub minimo. Existe para que source_manifest cite ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. Sigue el contrato del blueprint (DATA-001, DOM-001, ERR-001), no es codigo de produccion.
-- DATA-001: esquema exacto que declara blueprint/logic/data.md.
CREATE TABLE notas (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  texto     TEXT NOT NULL CHECK(length(texto) BETWEEN 1 AND 500),
  creada_en TEXT NOT NULL
);
