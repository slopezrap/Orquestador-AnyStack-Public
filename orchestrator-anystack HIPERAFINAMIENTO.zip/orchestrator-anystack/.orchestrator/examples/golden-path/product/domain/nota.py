"""FIXTURE del golden path — stub minimo. Existe para que source_manifest cite ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. Sigue el contrato del blueprint (DATA-001, DOM-001, ERR-001), no es codigo de produccion.

DOM-001: Nota {id, texto, creada_en}. El invariante de longitud se valida AQUI,
en el dominio, no solo en la UI. ERR-001: el codigo de validacion es NOTE_TEXT_INVALID.
"""
from dataclasses import dataclass

TEXTO_MIN, TEXTO_MAX = 1, 500


class NotaInvalida(ValueError):
    code = "NOTE_TEXT_INVALID"


@dataclass(frozen=True)
class Nota:
    id: int
    texto: str
    creada_en: str


def validar_texto(texto: str) -> str:
    limpio = (texto or "").strip()
    if not (TEXTO_MIN <= len(limpio) <= TEXTO_MAX):
        raise NotaInvalida("el texto debe tener entre 1 y 500 caracteres")
    return limpio
