# PLAN SCR-001 — Lista de notas

Escrito al cerrar EXPLORE, antes de tocar código. Citado desde
`result.json.phase_runs[EXPLORE].plan`.

- **verification_route**: web (`/notas`) — navegador real + `logs/console.txt`,
  `logs/network.txt`, `db/data-check.txt`; sin plataforma móvil.
- **consumer** (quién ejerce esta unidad): **ella misma**. Es una unidad `kind: ui` con
  ruta propia, así que la acción de usuario en `/notas` recorre el camino entero
  `PIPE-001 → notas → GET /api/v1/notas → DOM`. Además es el consumidor declarado de
  los dos cimientos que tiene detrás (`SCR-FOUNDATION-SCHEMA`, `SCR-FOUNDATION-SHELL`):
  hasta esta unidad, ninguno de los dos había sido ejecutado por nada.

## Acceptance map

Una fila por criterio. La columna *cómo se prueba* se rellena **antes** de escribir
código: un criterio sin respuesta ahí es un criterio que va a fallar en VERIFY, y este
es el momento barato de descubrirlo.

| criterio | IDs que lo rigen | ficheros a tocar | cómo se prueba | artefacto |
|---|---|---|---|---|
| AC-SCR-001-001 carga | ST-001, UI-001 | `web/notas.js`, `web/notas.css` | navegador: estado de carga visible antes de la respuesta | `screenshots/success.png`, `logs/network.txt` |
| AC-SCR-001-002 vacío | ST-001, UI-001 | `web/notas.js` | tabla `notas` vacía → estado vacío con CTA | `screenshots/success.png` |
| AC-SCR-001-003 crear | BR-001, APP-001, UC-001, DATA-001 | `app/notas.py`, `api/v1.py`, `web/notas.js` | POST real desde la UI → fila en `notas` → aparece sin recargar | `db/data-check.txt`, `traces/api-response.json` |
| AC-SCR-001-004 inválido | ERR-001, DOM-001 | `domain/nota.py`, `web/notas.js` | texto vacío y >500 → error recuperable, el texto escrito se conserva | `screenshots/error.png`, `logs/console.txt` |
| AC-SCR-001-005 mismo valor | DATA-001, PIPE-001 | `api/v1.py` | `notas.texto` == `$.data[0].texto` == `[data-testid=note-text]`, literal a literal | `db/data-check.txt` + `data_engine_assertions[]` |

## Vertical order

1. esquema: ya existe (`SCR-FOUNDATION-SCHEMA`); no se toca
2. dominio: validación de `texto` (no vacío, ≤500) en `domain/nota.py` — `DOM-001`, `ERR-001`
3. aplicación: comando de creación + consulta de listado — `APP-001`, `UC-001`
4. API: `POST /api/v1/notas`, `GET /api/v1/notas` — contrato de `DATA-001`
5. UI: `/notas` dentro de la shell, reutilizando el inventario de `UI-SHELL-003`
6. tests + generación real del dato por `PIPE-001` (nunca fixtures de cliente)

## Risks accepted

- El listado no pagina (`AUTO-002` pide paginación en toda lista). Aceptable aquí porque
  el alcance v1 del golden path es un único usuario y la tabla no crece; **trip-wire**: en
  cuanto `DATA-001` gane un `owner_id` real, esto vuelve a RESEARCH.

## Delivery

Rellenado al cerrar DEVELOP, antes de VERIFY. Desviarse es legal; desviarse en silencio
no. `verify-conformance` confirma o refuta cada fila contra el código.

| criterio | estado | nota |
|---|---|---|
| AC-SCR-001-001 | entregado | sin desviación |
| AC-SCR-001-002 | entregado | sin desviación |
| AC-SCR-001-003 | entregado | sin desviación |
| AC-SCR-001-004 | entregado con desviación | el límite se validó también en el cliente además del dominio; el dominio sigue siendo la autoridad, el cliente solo evita el viaje |
| AC-SCR-001-005 | entregado | sin desviación |

## Learned for the blueprint

Listado al cerrar DEVELOP, sin escribir en `blueprint/**`: el harvest de §7 lo aplica cuando el
código ya está probado. Una entrada aquí es una reclamación que `verify-blueprint-drift` puede
refutar, no una defensa.

| hecho aprendido | capa a la que pertenece |
|---|---|
| el texto se recorta (trim) antes de validar longitud, así que `"   "` cuenta como vacío | `logic/error.md` (`ERR-001`) |
| el listado ordena por `id` descendente; sin desempate por id la paginación repetiría filas | `logic/data.md` (`DATA-001`, consulta) |
| nada más | — |
