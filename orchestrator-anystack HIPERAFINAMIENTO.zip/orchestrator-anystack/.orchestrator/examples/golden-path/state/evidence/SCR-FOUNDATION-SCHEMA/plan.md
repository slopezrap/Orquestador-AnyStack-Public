# PLAN SCR-FOUNDATION-SCHEMA — Esquema canónico de notas

- **verification_route**: sin superficie de UI. Migración real + inspección del esquema y
  la suite; VALIDATE no aplica (no posee runtime ni cita `ENG-*`/`PIPE-*`).
- **consumer** (quién ejerce esta unidad): **`SCR-001`**, dos posiciones más adelante en el
  orden de obra. Es el dato que hace legítimo construir esto ahora: un cimiento sin nada
  que lo ejecute no falla en su primera pasada, falla en la ronda 4 — medido, 4× de coste.
  Si `SCR-001` se aleja en `order`, esta unidad vuelve a discutirse, no se construye igual.

## Acceptance map

| criterio | IDs que lo rigen | ficheros a tocar | cómo se prueba | artefacto |
|---|---|---|---|---|
| AC-SCR-FOUNDATION-SCHEMA-001 migra limpio | CORE-001 | `migrations/0001_notas.sql` | migrar desde cero sobre base vacía, sin errores | `logs/migration.txt` |
| AC-SCR-FOUNDATION-SCHEMA-002 columnas | CORE-001, DOM-001 | `migrations/0001_notas.sql` | inspección del esquema: `id`, `texto`, `creada_en` | `logs/migration.txt`, `logs/test-output.txt` |

## Vertical order

1. migración de `notas` (única capa que esta unidad posee)
2. test que la ejecuta desde cero y afirma las columnas

## Risks accepted

- Ninguno. La unidad no toma decisiones de producto: compila `DATA-001` tal como está.

## Delivery

| criterio | estado | nota |
|---|---|---|
| AC-SCR-FOUNDATION-SCHEMA-001 | entregado | sin desviación |
| AC-SCR-FOUNDATION-SCHEMA-002 | entregado | sin desviación |

## Learned for the blueprint

| hecho aprendido | capa a la que pertenece |
|---|---|
| `creada_en` se sella en UTC ISO-8601 en la migración, no en el cliente | `logic/data.md` (`DATA-001`) |
