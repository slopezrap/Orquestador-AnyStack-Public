#!/usr/bin/env bash
# Run the project's own deterministic checks BEFORE paying for a fan-out.
#
#   bash .orchestrator/scripts/preflight-check.sh "<PHASE>" [KEY...]
#   default keys: COMMAND_LINT COMMAND_BUILD
#
# WHY THIS EXISTS. verify-fanout.js awaits its four documentary lenses in full before the
# serialized half starts, and the lens that proves the build (verify-frontend) is the FIRST of
# that serialized half. So on a pass where the code does not compile, five subagents are launched
# and consolidated to report something `<COMMAND_BUILD>` says in seconds. Worse than the cost: a
# failed VERIFY is a repair pass, and a unit only gets three of those per episode — so a typo can
# spend a third of the unit's debugger budget. This is the orchestrator's own rule applied to
# itself: "when a finding could have been produced by a script, the defect is not only the
# finding, it is that a lens was the one to produce it."
#
# WHAT IT IS NOT. It is not evidence, it never appears in phase_runs[] or result.json.checks[],
# and it does not replace verify-frontend or verify-tests — those still run, still judge against
# the documents, and remain the only things that can put a verdict on disk. A green preflight
# proves nothing; a red one only saves the fan-out from being spent to learn the same thing.
#
# EXIT CONTRACT, and note it DIVERGES from reset-test-data.sh on purpose:
#   0  every requested command either passed or does not apply to this project
#   1  a DECLARED, RESOLVED command actually failed — repair and re-run before the fan-out
#   2  the check could not run at all (wrong invocation, missing lib) — still non-zero, still
#      "do not launch the fan-out", but it is the SCRIPT that is broken, not the project
# reset-test-data.sh is non-fatal even when its delegated command fails, because a reset is
# preparation and must never block a phase. Here the failure IS the signal, so swallowing it
# would remove the only reason the script exists.
#
# NOT APPLICABLE is not failure. A project with no lint command, or one still being wired by
# /init-build, reports the fact and continues — same three-state reading reset-test-data.sh uses
# (undeclared / malformed / unresolved placeholder), for the same reason: guessing which line is
# the command runs the wrong one and calls it success.
set -uo pipefail

# BASH_SOURCE is checked, not assumed — the same guard reset-test-data.sh carries, and for a
# sharper reason here. Under a shell that does not define it (zsh running this file directly, or
# the script piped into bash), ROOT resolves to empty, the source below fails, and the run falls
# through to "stack.md not found; nothing to check" with EXIT 0 — a SILENT SUCCESS reported by the
# one script whose entire job is to say when something failed. `cd "" || ...` does not save it:
# cd with an empty argument is a no-op that returns 0, so the fallback never fires.
# Exit 2, distinct from both contract codes below: this is neither "nothing to check" (0) nor "a
# declared command failed" (1) — it is "the check could not run at all", and the caller must still
# treat it as non-zero and not launch the fan-out.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "preflight-check: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/preflight-check.sh <PHASE>" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT" || { echo "preflight-check: cannot enter repo root '$ROOT'." >&2; exit 2; }
[ -f "$ROOT/.orchestrator/scripts/lib/stack-command.sh" ] || {
  echo "preflight-check: lib/stack-command.sh missing under '$ROOT'; refusing to report a clean pre-flight it never performed." >&2
  exit 2
}

STACK_FILE=".claude/rules/stack.md"
# shellcheck source=lib/stack-command.sh
. "$ROOT/.orchestrator/scripts/lib/stack-command.sh"

phase="${1:-PHASE}"
shift || true
KEYS=("$@")
# LINT then BUILD: the order is derived, not chosen. verify-fanout.js runs verify-frontend first
# "because it fails on the thing that invalidates everything downstream (the code does not
# build)", and lint is the cheaper half of the same question. COMMAND_TEST is deliberately NOT a
# default: verify-tests runs the full suite unconditionally on every pass anyway, so putting it
# here too pays the slowest command twice on the happy path. Pass it explicitly when this
# project's suite is fast enough for that trade to be worth it.
[ ${#KEYS[@]} -eq 0 ] && KEYS=(COMMAND_LINT COMMAND_BUILD)

# macOS ships bash 3.2, where `"${arr[@]}"` on an EMPTY array under `set -u` aborts with
# "unbound variable" (`${#arr[@]}` on the same array is fine — only the expansion trips). The
# default above means KEYS is never empty here today, so this guard is not fixing a live bug:
# it is making the loop below independent of that line surviving a future edit. The idiom
# `${arr[@]+"${arr[@]}"}` expands to nothing when the array is empty instead of aborting.
# Verified on this project's own machine: bash 3.2.57, `A=(); for x in "${A[@]}"` -> unbound.

if [ ! -f "$STACK_FILE" ]; then
  echo "preflight[$phase]: $STACK_FILE not found; nothing to check." >&2
  exit 0
fi

ran=0
for KEY in ${KEYS[@]+"${KEYS[@]}"}; do
  parse="$(stack_command "$KEY" "$STACK_FILE")"

  case "$parse" in
    "MALFORMED "*)
      echo "preflight[$phase]: the $KEY marker line in $STACK_FILE carries trailing content ('${parse#MALFORMED }'). The command must be on the line AFTER the comment. Refusing to guess; $KEY not checked." >&2
      continue
      ;;
    "AMBIGUOUS "*)
      echo "preflight[$phase]: $KEY is declared ${parse#AMBIGUOUS } times in $STACK_FILE. Leave exactly one declaration; $KEY not checked." >&2
      continue
      ;;
  esac

  command_line="${parse#OK }"
  [ "$parse" = "$command_line" ] && command_line=""

  if [ -z "$command_line" ]; then
    echo "preflight[$phase]: $KEY is not declared in $STACK_FILE; skipped." >&2
    continue
  fi

  case "$command_line" in
    "<"*">")
      echo "preflight[$phase]: $KEY is declared but still the placeholder '$command_line'; /init-build must resolve it. Skipped." >&2
      continue
      ;;
  esac

  echo "preflight[$phase]: running $KEY -> $command_line"
  if ! bash -c "$command_line"; then
    # FAIL FAST. Everything after this key is unasked on purpose: a project that does not build
    # cannot produce a meaningful test result, and reporting the second failure would describe
    # the first one twice.
    echo "preflight[$phase]: '$command_line' FAILED. Repair this before launching the fan-out — the lenses would spend a full round to tell you the same thing." >&2
    exit 1
  fi
  ran=$((ran + 1))
done

if [ "$ran" -eq 0 ]; then
  echo "preflight[$phase]: no applicable command declared; nothing checked." >&2
  exit 0
fi

echo "preflight[$phase]: $ran command(s) clean."
exit 0
