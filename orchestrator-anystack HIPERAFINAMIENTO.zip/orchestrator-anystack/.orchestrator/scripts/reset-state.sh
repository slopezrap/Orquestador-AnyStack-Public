#!/usr/bin/env bash
set -euo pipefail
# self-root to repo root so destructive paths are never cwd-relative
# This one matters most: the script deletes .orchestrator-state/. Without the check, a shell that
# does not define BASH_SOURCE leaves ROOT empty and every path below becomes cwd-relative — the
# one thing the comment above says it exists to prevent. It happens to fail safe today, but on an
# accident and with a message that lies (it reports .orchestrator/ missing when it is right there).
# A destructive script must refuse, not be lucky.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "reset-state: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/reset-state.sh --force" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

force=0
for arg in "$@"; do
  case "$arg" in
    --force) force=1 ;;
    -h|--help)
      cat <<'EOF'
Usage: bash .orchestrator/scripts/reset-state.sh --force

Reset only .orchestrator-state/ to a clean scaffold placeholder.
Does not modify .claude/, .orchestrator/, blueprint/, blueprint-templates/, design/ or product code.
EOF
      exit 0
      ;;
    *) echo "unknown argument: $arg" >&2; exit 2 ;;
  esac
done

if [ ! -d .orchestrator ]; then
  echo "missing .orchestrator/" >&2
  exit 1
fi

if [ "$force" -ne 1 ]; then
  echo "Refusing to reset without --force." >&2
  echo "Run: bash .orchestrator/scripts/reset-state.sh --force" >&2
  exit 1
fi

rm -rf .orchestrator-state
mkdir -p .orchestrator-state/evidence

cp .orchestrator/templates/spec.template.md .orchestrator-state/spec.md
cp .orchestrator/templates/features.empty.json .orchestrator-state/features.json
cat > .orchestrator-state/progress.md <<'EOF'
# Orchestrator progress

<!-- ORCHESTRATOR_PROGRESS_V1 -->

State reset. The next expected action is `/init-build`.
EOF
: > .orchestrator-state/evidence/.keep

python3 .orchestrator/scripts/validate-state.py
printf '%s\n' "orchestrator state reset OK"
