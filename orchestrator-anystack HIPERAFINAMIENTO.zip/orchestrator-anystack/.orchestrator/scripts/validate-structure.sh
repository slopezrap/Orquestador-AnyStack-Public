#!/usr/bin/env bash
set -euo pipefail
# Without the check, ROOT is empty and this reports ~90 required files as missing when every one of
# them exists — a total false alarm from the script whose job is to say the structure is sound.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "validate-structure: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/validate-structure.sh" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

required=(
  "CLAUDE.md"
  ".claude/settings.json"
  ".claude/agents/orchestrator-flow.md"
  ".claude/agents/pantalla-reviewer.md"
  ".claude/agents/research-shell.md"
  ".claude/agents/verify-coherence.md"
  ".claude/agents/verify-blueprint-drift.md"
  ".claude/agents/research-engine.md"
  ".claude/agents/research-pipeline.md"
  ".claude/agents/explore-engine.md"
  ".claude/agents/explore-pipeline.md"
  ".claude/agents/explore-config.md"
  ".claude/agents/validate-engine.md"
  ".claude/agents/validate-pipeline.md"
  ".claude/agents/audit-synthesizer.md"
  ".claude/agents/arch-fit.md"
  ".claude/agents/arch-data-model.md"
  ".claude/agents/arch-identity.md"
  ".claude/agents/arch-engines.md"
  ".claude/agents/arch-pipelines.md"
  ".claude/agents/arch-risk.md"
  ".claude/agents/arch-synthesizer.md"
  ".claude/agents/discovery-product.md"
  ".claude/agents/discovery-data.md"
  ".claude/agents/discovery-architecture.md"
  ".claude/agents/discovery-stack.md"
  ".claude/agents/discovery-infra.md"
  ".claude/agents/discovery-ux.md"
  ".claude/agents/discovery-synthesizer.md"
  ".claude/agents/context-loader.md"
  ".claude/agents/validate-journey.md"
  ".claude/agents/compile-synthesizer.md"
  ".claude/agents/research-synthesizer.md"
  ".claude/agents/verify-synthesizer.md"
  ".claude/hooks/block-rm.sh"
  ".claude/hooks/validate-state.sh"
  ".claude/hooks/precompact-checkpoint.sh"
  ".claude/workflows/compile-blueprint.js"
  ".claude/workflows/research-fanout.js"
  ".claude/workflows/explore-fanout.js"
  ".claude/workflows/verify-fanout.js"
  ".claude/workflows/validate-live.js"
  ".claude/workflows/validate-journeys.js"
  ".claude/workflows/audit-architecture.js"
  ".claude/workflows/arch-review.js"
  ".claude/workflows/discovery.js"
  ".claude/workflows/diff-adversary.js"
  ".claude/agents/repair-class-scan.md"
  ".claude/skills/init-build/SKILL.md"
  ".claude/skills/discovery/SKILL.md"
  ".claude/skills/next-pantalla/SKILL.md"
  ".claude/skills/build-loop/SKILL.md"
  ".claude/skills/accept/SKILL.md"
  ".claude/skills/status/SKILL.md"
  ".claude/skills/reslice/SKILL.md"
  ".claude/skills/review-pantalla/SKILL.md"
  ".claude/skills/verify-pipelines-data-ultracode/SKILL.md"
  ".claude/skills/production-code-review/SKILL.md"
  ".claude/skills/verify-app/SKILL.md"
  ".claude/skills/audit-motores/SKILL.md"
  ".claude/skills/arch-review/SKILL.md"
  ".claude/skills/fix/SKILL.md"
  ".claude/rules/constitution.md"
  ".claude/rules/stack.md"
  ".claude/rules/conventions.md"
  ".claude/rules/autonomy.md"
  ".orchestrator/schemas/features.schema.json"
  ".orchestrator/schemas/result.schema.json"
  ".orchestrator/schemas/batch.schema.json"
  ".orchestrator/templates/spec.template.md"
  ".orchestrator/templates/features.empty.json"
  ".orchestrator/templates/discovery-checklist.md"
  ".orchestrator/templates/evidence/result.json"
  ".orchestrator/examples/features.example.json"
  ".orchestrator/examples/result.example.json"
  ".orchestrator/examples/batch.example.json"
  ".orchestrator/examples/golden-path/README.md"
  ".orchestrator/examples/golden-path/blueprint/PRODUCT.md"
  ".orchestrator/examples/golden-path/blueprint/SCREENS.md"
  ".orchestrator/examples/golden-path/blueprint/logic/shell.md"
  ".orchestrator/examples/golden-path/blueprint/logic/engine.md"
  ".orchestrator/examples/golden-path/blueprint/logic/pipeline.md"
  ".orchestrator/examples/golden-path/state/features.json"
  ".orchestrator/examples/golden-path/state/evidence/SCR-001/result.json"
  ".orchestrator/scripts/validate-state.py"
  ".orchestrator/scripts/lint-blueprint.py"
  ".orchestrator/scripts/original-coverage.py"
  ".orchestrator/scripts/smoke-golden-path.sh"
  ".orchestrator/scripts/reset-state.sh"
  ".orchestrator/scripts/reset-test-data.sh"
  ".orchestrator/scripts/preflight-check.sh"
  ".orchestrator/scripts/lib/stack-command.sh"
  ".orchestrator/scripts/validate-structure.sh"
  ".orchestrator/scripts/phase-push.sh"
  ".orchestrator-state/spec.md"
  ".orchestrator-state/features.json"
  ".orchestrator-state/progress.md"
  ".orchestrator-state/evidence/.keep"
  "blueprint/PRODUCT.md"
  "blueprint/SCREENS.md"
  "blueprint/logic/domain.md"
  "blueprint/logic/application.md"
  "blueprint/logic/core.md"
  "blueprint/logic/journey.md"
  "blueprint/logic/permission.md"
  "blueprint/logic/state.md"
  "blueprint/logic/error.md"
  "blueprint/logic/integration.md"
  "blueprint/logic/ui.md"
  "blueprint/logic/shell.md"
  "blueprint/logic/data.md"
  "blueprint/logic/usecases.md"
  "blueprint-templates/PRODUCT-template.md"
  "blueprint-templates/SCREENS-template.md"
  "blueprint-templates/logic/domain-template.md"
  "blueprint-templates/logic/application-template.md"
  "blueprint-templates/logic/core-template.md"
  "blueprint-templates/logic/journey-template.md"
  "blueprint-templates/logic/permission-template.md"
  "blueprint-templates/logic/state-template.md"
  "blueprint-templates/logic/error-template.md"
  "blueprint-templates/logic/integration-template.md"
  "blueprint-templates/logic/ui-template.md"
  "blueprint-templates/logic/shell-template.md"
  "blueprint-templates/logic/data-template.md"
  "blueprint-templates/logic/usecases-template.md"
  "design/tokens.css"
)

missing=0
for path in "${required[@]}"; do
  if [ ! -e "$path" ]; then
    echo "missing: $path" >&2
    missing=1
  fi
done
if [ "$missing" -ne 0 ]; then
  exit 1
fi

python3 -m json.tool .claude/settings.json >/dev/null
python3 -m json.tool .orchestrator-state/features.json >/dev/null
python3 -m json.tool .orchestrator/schemas/features.schema.json >/dev/null
python3 -m json.tool .orchestrator/schemas/result.schema.json >/dev/null
python3 -m json.tool .orchestrator/schemas/batch.schema.json >/dev/null
python3 -m json.tool .orchestrator/examples/batch.example.json >/dev/null
bash -n .claude/hooks/precompact-checkpoint.sh
bash -n .orchestrator/scripts/reset-state.sh
bash -n .orchestrator/scripts/reset-test-data.sh
bash -n .orchestrator/scripts/preflight-check.sh
bash -n .orchestrator/scripts/lib/stack-command.sh
bash -n .orchestrator/scripts/phase-push.sh
bash -n .orchestrator/scripts/smoke-golden-path.sh
python3 -m json.tool .orchestrator/examples/golden-path/state/features.json >/dev/null
python3 - <<'PYCODE'
from pathlib import Path
source = Path('.orchestrator/scripts/validate-state.py').read_text(encoding='utf-8')
compile(source, '.orchestrator/scripts/validate-state.py', 'exec')
PYCODE
python3 .orchestrator/scripts/validate-state.py

python3 - <<'PYCODE'
from pathlib import Path
bad = [
    bytes([78,117,101,118,111,79,114,113,117,101,115,116,97,100,111,114]).decode(),
    bytes([78,117,101,118,111,32,79,114,113,117,101,115,116,97,100,111,114]).decode(),
    bytes([65,110,121,80,108,97,116,102,111,114,109]).decode(),
]
hits = []
for path in Path('.').rglob('*'):
    if path.is_dir():
        continue
    rel = str(path)
    if '__pycache__' in rel or rel.endswith('.pyc'):
        continue
    try:
        text = path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        continue
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term in line for term in bad):
            hits.append(f'{rel}:{idx}:{line}')
if hits:
    print('stale project name references found:', file=__import__('sys').stderr)
    print('\n'.join(hits), file=__import__('sys').stderr)
    raise SystemExit(1)
PYCODE

python3 - <<'PYCODE'
import re, sys
from pathlib import Path
agents = {p.stem for p in Path('.claude/agents').glob('*.md')}
wf_stems = {p.stem for p in Path('.claude/workflows').glob('*.js')}
missing = []
for wf in sorted(Path('.claude/workflows').glob('*.js')):
    text = wf.read_text(encoding='utf-8')
    for ref in re.findall(r"'((?:research|explore|verify|validate|audit|arch|discovery)-[a-z-]+)'", text):
        if ref in wf_stems:
            continue
        if ref not in agents:
            missing.append(f"{wf.name} references missing lens-agent: {ref}")
if missing:
    print('workflow lens-agent references broken:', file=sys.stderr)
    print('\n'.join(sorted(set(missing))), file=sys.stderr)
    raise SystemExit(1)
PYCODE

# Lens-set sync gate: the SAME full lens set must be declared by the workflow .js
# (what actually fans out) and by validate-state.py (what the STATE GATE requires).
# Adding a lens to one side but not the other would otherwise fail silently at the
# first /next-pantalla — catch it here, deterministically.
python3 - <<'PYCODE'
import re, sys
from pathlib import Path

wf_stems = {p.stem for p in Path('.claude/workflows').glob('*.js')}

def js_lenses(path, prefix):
    text = Path(path).read_text(encoding='utf-8')
    return {ref for ref in re.findall(rf"'({prefix}-[a-z-]+)'", text)
            if not ref.endswith('-synthesizer') and ref not in wf_stems}

def py_set(name):
    text = Path('.orchestrator/scripts/validate-state.py').read_text(encoding='utf-8')
    # Anchored to line start: RESEARCH_LENSES literally ends with "ARCH_LENSES", so an
    # unanchored search for the latter matches the former.
    match = re.search(rf"^{name}\s*=\s*\{{(.*?)\}}", text, re.DOTALL | re.MULTILINE)
    if not match:
        print(f"lens-sync: cannot find {name} in validate-state.py", file=sys.stderr)
        raise SystemExit(1)
    return set(re.findall(r'"([a-z-]+)"', match.group(1)))

failures = []
pairs = [
    ('research-fanout.js', js_lenses('.claude/workflows/research-fanout.js', 'research'), py_set('RESEARCH_LENSES')),
    ('compile-blueprint.js', js_lenses('.claude/workflows/compile-blueprint.js', 'research'), py_set('RESEARCH_LENSES')),
    ('explore-fanout.js', js_lenses('.claude/workflows/explore-fanout.js', 'explore'), py_set('EXPLORE_LENSES')),
    ('verify-fanout.js', js_lenses('.claude/workflows/verify-fanout.js', 'verify'), py_set('VERIFY_LENSES')),
]
for name, js, py in pairs:
    if js != py:
        failures.append(f"{name} fans out {sorted(js)} but validate-state.py requires {sorted(py)}")
vl = js_lenses('.claude/workflows/validate-live.js', 'validate')
gate_text = Path('.orchestrator/scripts/validate-state.py').read_text(encoding='utf-8')
dict_match = re.search(r"UI_PLATFORM_VALIDATORS\s*=\s*\{(.*?)\}", gate_text, re.DOTALL)
expected_vl = set(re.findall(r'"(validate-[a-z]+)"', dict_match.group(1) if dict_match else '')) | {'validate-logs'}
# VALIDATE is no longer UI-only: the gate can also require the engine/pipeline validators for a
# unit that cites ENG-*/PIPE-*, so validate-live.js must be able to fan out to them too.
eng_match = re.search(r"ENGINE_VALIDATORS\s*=\s*\{(.*?)\}", gate_text, re.DOTALL)
expected_vl |= set(re.findall(r'"(validate-[a-z]+)"', eng_match.group(1) if eng_match else ''))
if not expected_vl <= vl:
    failures.append(f"validate-live.js is missing validators the gate can require: {sorted(expected_vl - vl)}")
AUDIT_LENSES = {'audit-engine-inventory', 'audit-engine-contract', 'audit-pipeline-topology',
                'audit-data-reality', 'audit-scale'}
# arch-review.js must fan out to the exact set validate-state.py's ARCH_LENSES demands in
# meta.architecture_review.lenses — same sync discipline as the per-unit fan-outs above.
ar = {ref for ref in re.findall(r"'(arch-[a-z-]+)'",
                                Path('.claude/workflows/arch-review.js').read_text(encoding='utf-8'))
      if not ref.endswith('-synthesizer') and ref not in wf_stems}
if ar != py_set('ARCH_LENSES'):
    failures.append(f"arch-review.js fans out {sorted(ar)} but validate-state.py ARCH_LENSES is {sorted(py_set('ARCH_LENSES'))}")
al = {ref for ref in re.findall(r"'(audit-[a-z-]+)'",
                                Path('.claude/workflows/audit-architecture.js').read_text(encoding='utf-8'))
      if not ref.endswith('-synthesizer') and ref not in wf_stems}
if al != AUDIT_LENSES:
    failures.append(f"audit-architecture.js fans out {sorted(al)} but the audit lens set is {sorted(AUDIT_LENSES)}")
# discovery.js must fan out to the exact set validate-state.py's DISCOVERY_LENSES demands in
# meta.discovery.lenses — same sync discipline as arch-review above.
dl = {ref for ref in re.findall(r"'(discovery-[a-z-]+)'",
                                Path('.claude/workflows/discovery.js').read_text(encoding='utf-8'))
      if not ref.endswith('-synthesizer') and ref not in wf_stems}
if dl != py_set('DISCOVERY_LENSES'):
    failures.append(f"discovery.js fans out {sorted(dl)} but validate-state.py DISCOVERY_LENSES is {sorted(py_set('DISCOVERY_LENSES'))}")
# diff-adversary.js is checked DIFFERENTLY on purpose, and the difference is the point: its four
# agents are deliberately NOT a lens set in validate-state.py. Giving it a *_LENSES constant there
# would make it a required phase with a mandatory full set — turning a cheap advisory read into the
# very round-generator its charter forbids. So it gets the two guarantees that actually matter and
# not the third: the four names it fans out to must EXIST on disk, and each must be read-only in
# its own frontmatter (it reads a diff; it never runs anything, and giving one Bash would silently
# put it in the serialized class it was never scheduled for).
adv = set(re.findall(r"'(diff-adversary-[a-z-]+)'",
                     Path('.claude/workflows/diff-adversary.js').read_text(encoding='utf-8')))
if len(adv) != 4:
    failures.append(f"diff-adversary.js fans out {sorted(adv)} — expected exactly 4 questions; "
                    f"the charter in next-pantalla §6 names four and no more")
for a in sorted(adv):
    if not Path(f'.claude/agents/{a}.md').is_file():
        failures.append(f"diff-adversary.js fans out to {a}, which has no agent file")
if failures:
    print('lens sets OUT OF SYNC between workflows and validate-state.py:', file=sys.stderr)
    print('\n'.join(failures), file=sys.stderr)
    raise SystemExit(1)
PYCODE

# Isolation gate: a workflow .js declares WHICH of its lenses are documentary (safe to fan out in
# parallel) as a literal list, because a Workflow script has no filesystem access and cannot read
# the agents' frontmatter itself. That list is a claim, and this is where the claim is checked:
# re-derive the split from .claude/agents/*.md and fail when they disagree. Same discipline as the
# lens-set sync above — the .js says what it does, this script proves it. Without this, the
# hand-written list drifts the first time someone adds or re-scopes a lens, and the collision it
# prevents comes back silently at runtime.
python3 - <<'PYCODE'
import re, sys
from pathlib import Path

READ_ONLY = {'read', 'grep', 'glob'}

def frontmatter(agent):
    """The YAML frontmatter block only — the text between the opening and closing '---'.

    Scoping to the block is load-bearing, not tidiness: a `tools:` line written anywhere in the
    markdown BODY (a note, an example, a quoted contract) is indistinguishable from the real
    field to a whole-file regex, and would let an executing lens be certified read-only. That is
    the precise drift this gate exists to catch, so reading past the closing '---' would make the
    check agree with any lie told below it.
    """
    path = Path(f'.claude/agents/{agent}.md')
    if not path.is_file():
        print(f"lens isolation: {path} does not exist, but a workflow .js names '{agent}'. "
              f"Fix the name in the .js or add the agent.", file=sys.stderr)
        raise SystemExit(1)
    lines = path.read_text(encoding='utf-8').split('\n')
    if not lines or lines[0].strip() != '---':
        return ''
    for i, line in enumerate(lines[1:], 1):
        if line.strip() == '---':
            return '\n'.join(lines[1:i])
    return ''  # unterminated frontmatter: treat as declaring nothing (i.e. full tools)

def is_documentary(agent):
    """A lens is documentary iff its FRONTMATTER restricts it to read-only tools.

    No `tools:` line means it inherits the FULL tool set (it can run commands), and any tool
    beyond the read-only set — Bash, WebFetch, Write, an MCP server — means the same. The
    constitution calls this field the only real guarantee: inside a workflow, edits are
    auto-approved, so prose asking a lens not to write controls nothing.
    """
    m = re.search(r'^tools:\s*(.+)$', frontmatter(agent), re.MULTILINE)
    if not m:
        return False
    declared = {t.strip().lower() for t in m.group(1).split(',') if t.strip()}
    return bool(declared) and declared <= READ_ONLY

def js_list(path, name):
    text = Path(path).read_text(encoding='utf-8')
    # Strip line comments before matching: the repo writes `phase_runs[]`/`unmerged[]` style
    # notation inside comments, and a stray ']' there would truncate a non-greedy match and
    # report a drift that does not exist. Lens names contain no ']', so after stripping
    # comments the first ']' is the real end of the array.
    text = re.sub(r'//[^\n]*', '', text)
    m = re.search(rf'^const {name}\s*=\s*\[(.*?)\]', text, re.DOTALL | re.MULTILINE)
    if not m:
        print(f'isolation: cannot find {name} in {path}', file=sys.stderr)
        raise SystemExit(1)
    return set(re.findall(r"'([a-z-]+)'", m.group(1)))

failures = []

# The four diff adversaries read a diff and never execute anything, so they fan out in parallel
# with nothing to collide over. That is only true while their frontmatter says so: give one Bash
# and it silently joins the class this workflow never serializes, which is exactly the
# belongs-to-the-neighbour failure the isolation rule exists to remove.
for a in sorted(js_list('.claude/workflows/diff-adversary.js', 'ADVERSARIES')):
    if not is_documentary(a):
        failures.append(f"{a} must be read-only (tools: Read, Grep, Glob): diff-adversary.js fans "
                        f"out all four in parallel on the assumption that none of them executes")

declared_doc = js_list('.claude/workflows/verify-fanout.js', 'DOCUMENTARY_LENSES')
all_verify = js_list('.claude/workflows/verify-fanout.js', 'LENSES')
derived_doc = {a for a in all_verify if is_documentary(a)}
if declared_doc != derived_doc:
    failures.append(
        f"verify-fanout.js DOCUMENTARY_LENSES declares {sorted(declared_doc)} but the agents' "
        f"tools: frontmatter says {sorted(derived_doc)}. Fix whichever is wrong: a lens that can "
        f"run commands MUST be serialized, or two of them will collide over the tree/store/ports."
    )
if not declared_doc <= all_verify:
    failures.append(f"verify-fanout.js DOCUMENTARY_LENSES names lenses outside its own set: {sorted(declared_doc - all_verify)}")

# validate-live is the opposite case and is asserted, not assumed: if a validate-* lens ever
# becomes read-only, its phase could regain real parallelism and the serialize-everything
# decision written in that file would need revisiting. Fail so someone re-decides deliberately.
# Derived from the names validate-live.js can actually fan out to — NOT from a glob of
# .claude/agents/validate-*.md, which also sweeps in validate-journey (it belongs to
# validate-journeys.js / the /verify-app gate) and would fail this file over a lens it never runs.
vl_text = Path('.claude/workflows/validate-live.js').read_text(encoding='utf-8')
wf_stems = {p.stem for p in Path('.claude/workflows').glob('*.js')}
vl_agents = sorted({r for r in re.findall(r"'(validate-[a-z-]+)'", re.sub(r'//[^\n]*', '', vl_text))
                    if r not in wf_stems})
vl_doc = [a for a in vl_agents if is_documentary(a)]
if vl_doc:
    failures.append(
        f"validate-live.js serializes its whole phase on the premise that every lens it runs "
        f"drives a live runtime, but these are now read-only: {vl_doc}. Re-decide the scheduling "
        f"in that file and update its rationale comment."
    )

# A declared partition that the code does not execute is a lie the lists cannot catch: LENSES and
# DOCUMENTARY_LENSES could stay perfectly in sync with every frontmatter while the executing half
# is quietly fanned out in parallel again. Assert the SCHEDULING too, not just the membership.
SCHEDULING = [
    ('.claude/workflows/verify-fanout.js', 'for (const a of EXEC_LENSES)', 'parallel(EXEC_LENSES',
     'the executing verify-* lenses must run one at a time'),
    ('.claude/workflows/validate-live.js', 'for (const a of ORDERED)', 'parallel(ORDERED',
     'the whole VALIDATE phase must run one lens at a time'),
    ('.claude/workflows/validate-journeys.js', 'for (const a of ORDERED)', 'parallel(ORDERED',
     'the whole cross-screen Drive phase must run one lens at a time — a journey drives the '
     'same shell/backend/canonical store as its neighbours, exactly like a validate-* lens'),
]
for path, required, forbidden, why in SCHEDULING:
    src = Path(path).read_text(encoding='utf-8')
    if required not in src:
        failures.append(f"{path}: expected `{required}` — {why}. The isolation guarantee is the scheduling, not the list.")
    if forbidden in src:
        failures.append(f"{path}: found `{forbidden}` — {why}. Fanning them out re-creates the collision this partition exists to prevent.")

if failures:
    print('lens isolation OUT OF SYNC with the agents\' tools: frontmatter:', file=sys.stderr)
    print('\n'.join(failures), file=sys.stderr)
    raise SystemExit(1)
PYCODE

echo "structure OK"
