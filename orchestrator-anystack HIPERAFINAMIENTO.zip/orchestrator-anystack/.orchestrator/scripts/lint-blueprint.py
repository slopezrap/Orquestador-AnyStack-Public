#!/usr/bin/env python3
"""Deterministic blueprint linter — no LLM, stdlib only.

Runs BEFORE the research fan-out spends tokens (/init-build step 1,
/next-pantalla after CLARIFY writes, /reslice step 1) so the pipeline starts
from a referentially intact spec instead of discovering broken IDs mid-build.

ERRORS (exit 1) — structurally broken blueprint:
  - duplicate IDs (same ID defined in more than one ``` block, or a DEC-* whose
    `## heading` sections outnumber the blocks that define it)
  - a DECISIONS.md index row listed more than once
  - dangling references (after/applies/depends_on/related_screens/product_refs/
    data_refs/engine_refs pointing to an ID no file defines)
  - a `written_to` path that resolves to no file on disk
  - dependency cycles in SCREENS after[]

WARNINGS (exit 0, printed) — incomplete but not broken; /init-build turns these
into CLARIFY questions instead of guessing:
  - leftover stubs ("Pendiente de definir", "TBD", unresolved <PLACEHOLDER> tokens)
  - screen blocks without acceptance criteria
  - non-ID tokens inside a reference list
  - references that resolve only to a heading (no ``` block defines them)
  - uncited claims: a layer declares `related_screens: [SCR-X]` while SCR-X's
    `applies[]` does not cite it back (see "Referential integrity is bidirectional")
  - a `written_to` target that exists but never mentions its decision, and a file
    that cites a decision the decision's own `written_to` does not name
  - an ID family living entirely outside this linter's registry (see the
    META-INVARIANT below — the check that keeps this file honest about its own
    coverage instead of reporting 15 of 16 families as clean)

An ID counts as DEFINED only when a ```logic/```screen block declares it via
`id:`. A heading alone is a title, not a definition — otherwise an empty
section would satisfy referential integrity and duplicate detection (which
only sees blocks) would disagree with it.

The ONE exception is `DEC-*`, and it is registered rather than excused: a
decision is routinely written as a heading plus an index row with no block, so
the ledger sat outside every rule here. Heading occurrences in excess of the
blocks that define the same id are registered into the shared registry, which
puts DEC-* under the duplicate rule — and under every rule added later — without
teaching any individual rule about DECISIONS.md.

DECIDEDNESS (--decidedness, never fatal) — a separate question from the above.
The checks above ask "is the blueprint internally consistent?". This one asks
"has anyone actually DECIDED anything?", and the two are independent: a
blueprint straight out of blueprint-templates/ is perfectly consistent and
entirely undecided.

It reports two kinds of silence:
  - `placeholder`       — the value is still a <SCAFFOLD_TOKEN>. Obviously absent.
  - `template_default`  — the value is byte-identical to what the template ships.
                          This is the dangerous one, because it does not LOOK
                          absent: `source_of_truth: database`, `replay_safe: true`,
                          `delivery: at_least_once` read exactly like decisions.

Consumed by /arch-review and the arch-* lenses, whose governing rule is
`research-* owns the ABSENCE, arch-* owns the ERROR`: a finding whose only
support is an undecided field is not a finding, it is silence. Without this
output that distinction cannot be drawn, so the lenses either raise template
defaults as blockers or the gate reviews a blueprint nobody has filled in.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path.cwd()
BLUEPRINT = ROOT / "blueprint"
TEMPLATES = ROOT / "blueprint-templates"

ID_PATTERN = re.compile(r"^(?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*$")
HEADING_ID = re.compile(r"^#{2,4}\s+((?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*)\b")
FENCED_BLOCK = re.compile(r"```(screen|logic)\r?\n(.*?)```", re.DOTALL)
REF_KEYS = ("after", "applies", "depends_on", "related_screens", "product_refs", "data_refs", "engine_refs",
            "pipeline_refs", "feeds", "writes", "consumed_by", "related_engines",
            "supersedes", "written_to", "affects_screens", "reopens", "remediates")
STUB_MARKERS = ("Pendiente de definir", "Pendiente.", "PENDIENTE", "por definir", "TBD", "TODO", "To be defined")
# <UPPER_SNAKE> scaffold tokens. The {2,} floor (4+ chars inside <>) avoids
# false positives on HTML (<b>, <br>) and generics (<T>).
PLACEHOLDER = re.compile(r"<[A-Za-z][A-Za-z0-9_]{2,}>")
PLACEHOLDER_SAMPLE = 5

# The ID families this linter knows about — the same list ID_PATTERN accepts, spelled out so
# the coverage invariant below can iterate it. See "Every family must live INSIDE the
# machinery" for why a list nobody iterates is exactly how DEC-* went unchecked for so long.
ID_FAMILIES = ("BR", "SCR", "DOM", "APP", "CORE", "JOUR", "PERM", "ST", "ERR", "INT",
               "UI", "DATA", "UC", "ENG", "PIPE", "DEC")

# `written_to` holds either LAYER IDs (`DATA-004` — the form blueprint-templates ships) or
# PATHS (`blueprint/logic/data.md`, `stack.md`, optionally `file.py:symbol`). Both are legal
# and they are checked differently: an ID is resolved against the blueprint's own registry by
# the generic reference loop, a PATH is a claim about the FILESYSTEM and is checked below.
# Requiring a real `.ext` is what keeps `DATA-001` out of this branch.
PATH_TOKEN = re.compile(r"^[A-Za-z0-9_.][A-Za-z0-9_./-]*\.[A-Za-z0-9]{1,6}(?::[A-Za-z0-9_.-]+)?$")
# Any mention of a decision id in prose or in a block — used for the INVERSE written_to check.
DEC_MENTION = re.compile(r"\bDEC-[A-Z0-9][A-Z0-9-]*\b")

errors: list[str] = []
warnings: list[str] = []


def parse_list(raw: str) -> list[str]:
    raw = raw.strip()
    if not (raw.startswith("[") and raw.endswith("]")):
        return []
    inner = raw[1:-1].strip()
    if not inner:
        return []
    return [tok.strip().strip("\"'") for tok in inner.split(",") if tok.strip()]


def blueprint_files() -> list[Path]:
    files = [BLUEPRINT / "PRODUCT.md", BLUEPRINT / "SCREENS.md", BLUEPRINT / "DECISIONS.md"]
    files += sorted((BLUEPRINT / "logic").glob("*.md"))
    return [f for f in files if f.exists()]


# --- decidedness ------------------------------------------------------------
# A scalar line inside a ``` block: `key: value`, no list, no empty value.
# Indentation is captured so nested keys can be reported by their real path
# (`canonical_store.source_of_truth`), which is what the arch-* lenses cite.
# The value group is OPTIONAL on purpose. A line that is just `canonical_store:` opens a
# nested mapping and carries no value of its own — but it is what gives its children their
# real path. An earlier version required a non-empty value here, which meant those lines
# never matched, the indentation stack never got pushed, and EVERY nested key was reported
# under its bare name: `source_of_truth` instead of `canonical_store.source_of_truth`. The
# branch that pushes onto the stack was unreachable code. Worse than cosmetic — two layers
# that both declare `source_of_truth` became indistinguishable in the report and collided
# in the defaults table, so a deliberately-decided field could be reported as untouched.
SCALAR_LINE = re.compile(r"^(\s*)([a-z_][a-z0-9_]*):[ \t]*(.*?)\s*$")
# Identity, addressing and classification — never decisions, so never absences.
# Every project's DATA-001 is called DATA-001; a business rule's `type` is
# `business_rule` because that is what it IS, not because nobody chose. Leaving
# these in drowns the real signal: the scaffold's SCREENS.md alone contributed 36
# such rows, which is exactly how a report stops being read.
#
# The bar for this set is "coinciding with the template carries no information".
# Keep anything a human could have decided differently and did not — `status`,
# `severity`, `source_of_truth`, `delivery`, `replay_safe` — however innocuous it
# looks. Those wired-looking defaults are the entire point of the check.
# Identical in project and template BY CONSTRUCTION — they name the block's kind, not a choice.
# Deliberately minimal: with the block-ratio test below doing the real filtering, a wider skip
# list would start MASKING genuinely untouched blocks instead of denoising edited ones.
DECIDEDNESS_SKIP_KEYS = {"id", "type"}

# A single field equal to its template value proves almost nothing. `severity: must`,
# `status: draft` and `delivery: at_least_once` have two or three legal values, so a real
# decision collides with the template by chance. Measured on a real filled blueprint,
# per-field matching alone reported 165 fields, nearly all of them deliberate.
#
# Absence has a different SHAPE: a block NOBODY EDITED, where the coincidences pile up. So a
# template match only counts as undecided when most of its own block still matches too.
#
# The asymmetry is deliberate, and it is the whole point: over-reporting is the DANGEROUS
# direction here. The arch-* lenses are told that a finding supported only by an
# `undecided_fields[]` entry is not a finding — so a false positive SILENCES real judgment
# rather than merely adding noise. Under-reporting costs a missed prompt; over-reporting
# costs a lens that stops speaking.
#
# Every entry carries its own `block_match_ratio`, so a reader can weigh the evidence instead
# of trusting this threshold blindly. Placeholders bypass the test entirely: an unresolved
# <TOKEN> is absence with no ambiguity at all.
UNEDITED_BLOCK_RATIO = 0.6


def template_for(path: Path) -> Path | None:
    """blueprint/logic/data.md -> blueprint-templates/logic/data-template.md
       blueprint/PRODUCT.md    -> blueprint-templates/PRODUCT-template.md"""
    rel = path.relative_to(BLUEPRINT)
    candidate = TEMPLATES / rel.parent / f"{rel.stem}-template{rel.suffix}"
    return candidate if candidate.exists() else None


def parse_scalars(body: str) -> list[tuple[str, str]]:
    """Scalars of one ``` block as (dotted_key_path, value), preserving nesting."""
    out: list[tuple[str, str]] = []
    stack: list[tuple[int, str]] = []   # (indent, key)
    for line in body.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = SCALAR_LINE.match(line)
        if not match:
            continue
        indent, key, value = len(match.group(1)), match.group(2), match.group(3)
        while stack and stack[-1][0] >= indent:
            stack.pop()
        # Strip a trailing comment only when something precedes it. A value that STARTS
        # with '#' is a value, not a comment (an unquoted hex colour is the obvious case),
        # and splitting there left it empty — which this parser then read as "opens a nested
        # mapping", corrupting the indentation stack for everything below it.
        if not value.startswith("#"):
            value = value.split("#", 1)[0]
        value = value.strip().strip("\"'")
        if not value:                      # `parent:` opening a nested mapping
            stack.append((indent, key))
            continue
        path = ".".join([k for _, k in stack] + [key])
        if value.startswith("[") or key in DECIDEDNESS_SKIP_KEYS:
            continue
        out.append((path, value))
    return out


def template_defaults(path: Path) -> dict[str, set[str]]:
    """Every scalar value the layer's template ships, as key_path -> {values}.

    Deliberately pooled across ALL blocks of the template rather than matched
    block-by-block: a real project renames and renumbers blocks, so pairing
    DATA-001 to DATA-001 would stop working the moment anyone adds DATA-007.
    What identifies an untouched default is the value itself, not its address.

    Every value the template shows for a key is kept, including keys whose example
    blocks disagree with each other. Filtering those out was an earlier attempt at
    the same problem UNEDITED_BLOCK_RATIO solves properly — and the ratio solves it
    better, because it asks the right question. Whether a value is undecided is not
    a property of the value; it is a property of whether anyone edited the block it
    sits in."""
    pooled: dict[str, set[str]] = {}
    template = template_for(path)
    if template is None:
        return {}
    for _, body in FENCED_BLOCK.findall(template.read_text(encoding="utf-8")):
        for key, value in parse_scalars(body):
            pooled.setdefault(key, set()).add(value)
    return pooled


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="lint-blueprint.py",
        description="Deterministic blueprint linter. With no flags, behaves exactly as "
                    "it always has: lint the blueprint and print human-readable output.",
    )
    parser.add_argument(
        "--decidedness", action="store_true",
        help="also report undecided_fields[]: scalars still at their blueprint-templates/ "
             "default or still a <PLACEHOLDER>. Never fatal — absence is not an error.",
    )
    parser.add_argument(
        "--json", action="store_true", dest="as_json",
        help="emit the result as JSON on stdout instead of human-readable lines.",
    )
    args = parser.parse_args(argv)

    if not BLUEPRINT.exists():
        print("lint-blueprint: missing blueprint/ directory", file=sys.stderr)
        raise SystemExit(1)

    # Without the moulds a template default is indistinguishable from a decision, and answering
    # "nothing is undecided" would be a FALSE CLEAR — the worst possible output for a gate whose
    # entire job is to notice silence. Refuse to answer rather than answer wrongly.
    if args.decidedness and not TEMPLATES.is_dir():
        print(f"lint-blueprint --decidedness: {TEMPLATES} not found. Without the moulds a "
              f"template default cannot be told from a decision, and reporting 'nothing is "
              f"undecided' would be a false clear. Refusing to answer.", file=sys.stderr)
        raise SystemExit(1)

    undecided: list[dict[str, object]] = []
    defined: dict[str, list[str]] = {}   # id -> [locations of ``` block definitions]
    known_ids: set[str] = set()          # block ids only — the real definitions
    heading_ids: set[str] = set()        # ids seen as a title (checked only after known_ids)
    refs: list[tuple[str, str, str]] = []  # (source_location, key, token)
    after_edges: dict[str, list[str]] = {}
    # The two halves of the bidirectional check below. `screen_applies` is registered for
    # EVERY screen block, including one with no applies: line at all — otherwise a screen
    # that cites nothing would silently satisfy every claim made about it.
    screen_applies: dict[str, set[str]] = {}      # screen id -> ids its applies[] cites
    claims: list[tuple[str, str, str]] = []       # (claiming block id, screen id, location)
    uncited: list[dict[str, str]] = []
    # EVERY heading occurrence, with its location — a set would collapse the very duplicate
    # this exists to find. `heading_ids` above stays a set because its only job is membership
    # ("does this token resolve to a title?"); counting is a different question.
    heading_occurrences: dict[str, list[str]] = {}   # id -> ["file:line", ...]
    file_texts: dict[str, str] = {}                  # rel -> full text, for the written_to checks
    dec_written_to: dict[str, list[str]] = {}        # DEC id -> tokens its written_to declares

    for path in blueprint_files():
        rel = str(path.relative_to(ROOT))
        text = path.read_text(encoding="utf-8")
        file_texts[rel] = text
        defaults = template_defaults(path) if args.decidedness else {}

        placeholder_hits: dict[str, int] = {}
        for lineno, line in enumerate(text.splitlines(), 1):
            heading = HEADING_ID.match(line)
            if heading:
                heading_ids.add(heading.group(1))
                heading_occurrences.setdefault(heading.group(1), []).append(f"{rel}:{lineno}")
            for marker in STUB_MARKERS:
                if marker in line:
                    warnings.append(f"{rel}:{lineno}: stub marker '{marker}' — still undefined")
                    break
            for token in PLACEHOLDER.findall(line):
                placeholder_hits[token] = placeholder_hits.get(token, 0) + 1

        # One warning per file, not per line: a fresh copy of the templates has
        # hundreds of these and /init-build needs the signal, not the noise.
        if placeholder_hits:
            distinct = sorted(placeholder_hits)
            sample = ", ".join(distinct[:PLACEHOLDER_SAMPLE])
            extra = len(distinct) - PLACEHOLDER_SAMPLE
            if extra > 0:
                sample += f", +{extra} more"
            warnings.append(
                f"{rel}: {sum(placeholder_hits.values())} unresolved placeholder token(s) "
                f"({len(distinct)} distinct: {sample}) — fill them in or turn them into CLARIFY questions"
            )

        for kind, body in FENCED_BLOCK.findall(text):
            block_id = None
            id_match = re.search(r"^\s*id:\s*([^\s#]+)\s*$", body, re.MULTILINE)
            if id_match:
                block_id = id_match.group(1).strip().strip("\"'")
                if ID_PATTERN.match(block_id):
                    defined.setdefault(block_id, []).append(rel)
                    known_ids.add(block_id)
                    if kind == "screen":
                        screen_applies.setdefault(block_id, set())
                elif "<" in block_id:
                    warnings.append(f"{rel}: block id '{block_id}' is an unresolved placeholder")
                else:
                    warnings.append(f"{rel}: block id '{block_id}' does not match any known ID prefix")
            else:
                warnings.append(f"{rel}: {kind} block without id:")

            if kind == "screen" and "acceptance:" not in body:
                warnings.append(f"{rel}: screen block {block_id or '<no-id>'} has no acceptance criteria")

            if args.decidedness:
                # The ratio is computed over the WHOLE block first, then each field is judged
                # against it. A field cannot know on its own whether it was chosen; the block
                # it lives in can.
                scalars = parse_scalars(body)
                matches = [(k, v) for k, v in scalars if v in defaults.get(k, ())]
                ratio = len(matches) / len(scalars) if scalars else 0.0
                for key_path, value in scalars:
                    if PLACEHOLDER.search(value):
                        reason = "placeholder"        # unambiguous: bypasses the ratio entirely
                    elif (key_path, value) in matches and ratio >= UNEDITED_BLOCK_RATIO:
                        reason = "template_default"
                    else:
                        continue
                    undecided.append({
                        "file": rel,
                        "block": block_id or "<no-id>",
                        "key": key_path,
                        "value": value,
                        "reason": reason,
                        "block_match_ratio": round(ratio, 2),
                    })

            for key in REF_KEYS:
                for ref_match in re.finditer(rf"^\s*{key}:\s*(\[.*?\])\s*(?:#.*)?$", body, re.MULTILINE):
                    tokens = parse_list(ref_match.group(1))
                    for tok in tokens:
                        refs.append((f"{rel} ({block_id or kind})", key, tok))
                    # A decision's written_to is the one reference list that is ALSO a claim
                    # about disk, so it needs its own record. Registered even when empty: an
                    # `applied` decision that declares nothing is itself the finding.
                    if key == "written_to" and block_id and block_id.startswith("DEC-"):
                        dec_written_to.setdefault(block_id, []).extend(tokens)
                    if block_id and ID_PATTERN.match(block_id):
                        if key == "applies" and kind == "screen":
                            screen_applies.setdefault(block_id, set()).update(tokens)
                        elif key == "related_screens":
                            claims.extend((block_id, tok, rel) for tok in tokens)
                    if key == "after" and block_id and ID_PATTERN.match(block_id):
                        after_edges.setdefault(block_id, []).extend(
                            t for t in tokens if ID_PATTERN.match(t)
                        )

    # --- DECISIONS.md joins the SHARED registry -------------------------------
    # Every referential rule in this file operates on `defined` — and `defined` is filled only
    # from ```logic/```screen blocks. `DEC-*` is the one family whose entries are routinely
    # written as a markdown HEADING plus an index row, with no block, so the whole ledger sat
    # outside every rule this linter has. Measured on a real project: 15 of 16 families were
    # 100% block-declared and covered; DEC-* had 1 block (the template's own DEC-001 example)
    # and 62 heading-only entries — invisible. Two `## DEC-062` sections and the linter exited
    # 0; three VERIFY lenses found it instead, at the price of a full debugger round, which is
    # the exact inversion of "what a script can decide must never cost a fan-out".
    #
    # Registering headings here — rather than teaching each rule about DECISIONS.md — is what
    # makes the fix general: the duplicate rule below is unchanged, and so is every rule added
    # later. Three traps were measured while getting this right; all three are closed by the
    # arithmetic on this one line, so do not "simplify" it:
    #   1. `heading_ids |= headings` produced 314 SPURIOUS errors, because the two DECISIONS
    #      presence checks below depend on `dec_heading_ids` being NARROW (DEC-* only). Hence
    #      those locals are named apart from the file-wide `heading_ids` instead of merged.
    #   2. Registering every heading blindly reported "duplicate ID DEC-001" on the CANONICAL
    #      shape, which is heading + block (blueprint-templates/DECISIONS-template.md ships
    #      exactly that). A heading that pairs with a block is one entry written properly, not
    #      two definitions.
    #   3. Guarding with `if dec_id not in defined` looks like the fix for (2) and silently
    #      disables the whole check: `defined` accumulates, so the FIRST heading registers and
    #      every later one is skipped — which is precisely the duplicate we are hunting.
    # What satisfies all three: register only the heading occurrences IN EXCESS of the blocks
    # that already define the id. 1 heading + 1 block -> nothing (canonical). 2 headings + 0
    # blocks -> both (the measured bug). 2 headings + 1 block -> one (still a duplicate).
    for dec_id, occurrences in heading_occurrences.items():
        if not dec_id.startswith("DEC-"):
            continue
        for where in occurrences[len(defined.get(dec_id, [])):]:
            defined.setdefault(dec_id, []).append(f"{where} (## heading)")

    for bid, locations in sorted(defined.items()):
        if len(locations) > 1:
            errors.append(f"duplicate ID {bid} defined in: {', '.join(locations)}")

    # --- META-INVARIANT: every family must live INSIDE the machinery ----------
    # This is the check that stops the defect above from recurring, and it is the one worth
    # keeping. Fixing DEC-* fixes DEC-*; what let DEC-* rot was that NOTHING measured whether a
    # family was covered at all. The linter covered 15 of 16 families and said so nowhere, so
    # the sixteenth was indistinguishable from clean. The next layer someone writes in prose
    # instead of in blocks will reproduce it exactly, and an expensive lens will find it again.
    #
    # The warning fires only when a family is ENTIRELY outside the registry: some heading-only
    # ids while others are registered is normal work-in-progress (USO.md §3 documents writing
    # SCREENS.md last), and warning there would fire on healthy states, which is how a check
    # gets routed around. The full table always ships under --json for anyone who wants it.
    family_coverage: dict[str, dict[str, object]] = {}
    for family in ID_FAMILIES:
        registered = [i for i in defined if i.split("-", 1)[0] == family]
        heading_only = sorted(i for i in heading_ids
                              if i.split("-", 1)[0] == family and i not in defined)
        family_coverage[family] = {
            "registered": len(registered),
            "heading_only": len(heading_only),
            "heading_only_sample": heading_only[:PLACEHOLDER_SAMPLE],
        }
        if heading_only and not registered:
            sample = ", ".join(heading_only[:PLACEHOLDER_SAMPLE])
            extra = len(heading_only) - PLACEHOLDER_SAMPLE
            if extra > 0:
                sample += f", +{extra} more"
            warnings.append(
                f"ID family {family}-*: {len(heading_only)} id(s) exist only as markdown "
                f"headings and NONE reaches this linter's shared registry ({sample}) — so every "
                f"referential rule here (duplicate ids, dangling refs, cycles, stubs) is blind "
                f"to that family. Declare them in ```logic blocks, or register them the way "
                f"DEC-* headings are registered above; a family checked by nothing is not clean, "
                f"it is unmeasured"
            )

    # blueprint/DECISIONS.md: the index table must list every decision, and list only
    # decisions that exist. This is not bookkeeping. The ~23 discovery-*/research-* lenses are
    # instructed to read the INDEX and stop at the first `## DEC-` heading, so a decision missing
    # from the table is invisible to every lens that would have consulted it — and the failure is
    # silent and precisely inverted: the lens does not error, it asks the human a question the
    # human already answered, which the constitution names as the fastest way to make someone
    # stop trusting the questions. A row pointing at no section is the cheaper mirror defect: a
    # lens cites a decision that does not exist.
    #
    # It is an ERROR, not a warning, because the whole index-only reading rests on it, and it is
    # decided by a script rather than asked of whoever writes the decision — the same reason every
    # other referential rule in this file is here instead of in a checklist someone must remember.
    decisions_path = BLUEPRINT / "DECISIONS.md"
    if decisions_path.is_file():
        dtext = decisions_path.read_text(encoding="utf-8")
        # NAMED APART from the file-wide `heading_ids` on purpose. These two locals used to be
        # called `heading_ids`/`row_ids` and REASSIGNED the file-wide set built above, which was
        # filled with every heading of every blueprint file. Everything downstream that reads
        # `heading_ids` runs AFTER this point, so the dangling-reference loop's "resolves only to
        # a heading" branch was measuring a 63-id DEC-only set instead of the full 376: that
        # branch was dead for every non-DEC family, silently downgrading a real warning into a
        # hard error path. Merging the two sets is NOT the fix — the two presence checks below
        # subtract these sets from each other, so a wide `heading_ids` makes every `## APP-001`
        # in the blueprint report as "a section with no row in the DECISIONS index" (314 spurious
        # errors, measured). Narrow scope here, wide scope there, different names.
        dec_heading_ids = set(re.findall(r"^##\s+(DEC-[A-Za-z0-9-]+)", dtext, re.MULTILINE))
        # Index rows look like `| DEC-001 | ... |`; the placeholder row (`| — | ... |`) has no id.
        # `~~` is tolerated around the id because a real project marks superseded rows with
        # strikethrough, and a struck-through row IS still a row: the lens reads the table as
        # text and the id is right there, readable. Failing on it would have reported a decision
        # as "invisible to every lens" when the only thing invisible was the id to this regex.
        #
        # Collected as a LIST first: `set()` silently collapses a duplicated row, which is the
        # mirror of the duplicated-heading defect and was found the same way — a probe against
        # the real binary showed two identical `| DEC-062 |` rows exiting 0. The heading side is
        # covered by the shared registry above; the row side has no other owner, so it is here.
        dec_row_list = re.findall(r"^\|\s*~{0,2}(DEC-[A-Za-z0-9-]+)~{0,2}\s*\|", dtext, re.MULTILINE)
        dec_row_ids = set(dec_row_list)
        for repeated in sorted({r for r in dec_row_list if dec_row_list.count(r) > 1}):
            errors.append(
                f"blueprint/DECISIONS.md: the index table lists {repeated} "
                f"{dec_row_list.count(repeated)} times. One decision is one row: the lenses read "
                f"this table as their whole view of the ledger, so a repeated id shows them two "
                f"decisions where there is one, and whichever row they read first wins")
        for missing in sorted(dec_heading_ids - dec_row_ids):
            errors.append(
                f"blueprint/DECISIONS.md: {missing} has a `## {missing}` section but no row in the "
                f"index table (`## Índice` / `## Index`). The lenses read the index and stop before "
                f"the first `## DEC-` heading, "
                f"so an unlisted decision is invisible to all of them and they will ask "
                f"the human something already decided")
        for orphan in sorted(dec_row_ids - dec_heading_ids):
            errors.append(
                f"blueprint/DECISIONS.md: the index table lists {orphan} but no `## {orphan}` "
                f"section defines it; a lens citing that row would be citing nothing")

    for source, key, tok in refs:
        if tok == "ALL":
            continue  # documented sentinel (shell rules: every ui screen)
        if "<" in tok or ">" in tok:
            warnings.append(f"{source}: {key} contains unresolved placeholder '{tok}'")
            continue
        if key == "written_to" and not ID_PATTERN.match(tok) and PATH_TOKEN.match(tok):
            continue  # a PATH, not a layer id — checked against the filesystem below
        if not ID_PATTERN.match(tok):
            warnings.append(f"{source}: {key} contains non-ID token '{tok}'")
            continue
        if tok not in known_ids:
            if tok in heading_ids:
                warnings.append(
                    f"{source}: {key} references {tok}, which only exists as a heading — "
                    "no ```logic/```screen block defines it"
                )
                continue
            errors.append(f"{source}: {key} references undefined ID {tok}")

    # --- `written_to` is a claim about DISK, so it is checked against DISK ----
    # A decision's `written_to` says where that decision LANDED. The template calls it "the IDs
    # whose files now carry this truth" and `autonomy.md` already warns, in prose, that it is an
    # assertion about disk rather than an intention. It was wrong FOUR times in two cycles of one
    # real project — a file declared that was never written, a file written that was never
    # declared. Four failures of the same written warning is not information about the author, it
    # is information about the RULE: prose is not a control, which is the same conclusion this
    # orchestrator already reached for the `tools:` frontmatter. So it becomes a check.
    #
    # Two directions, because each catches what the other cannot:
    #   DIRECT  — what is declared, exists. A path that resolves to nothing is an ERROR: the
    #             decision cites a landing site that is not there, and every later reader takes
    #             it on trust. A path that exists but never mentions the id is a WARNING, not an
    #             error: a decision may legitimately change a file without the file citing the
    #             decision back.
    #   INVERSE — what was written, is declared. A blueprint file that cites DEC-0NN while that
    #             decision's `written_to` does not name it is the half nobody notices, and it is
    #             the half that makes a ledger stop being a record. WARNING for the mirror
    #             reason: a file may cite a decision (in prose, as context) without being one of
    #             its targets.
    # Layer-ID tokens are NOT re-checked here — the reference loop above already resolves them
    # against the blueprint's own registry, and checking twice would report one defect twice.
    WRITTEN_TO_SEARCH_ROOTS = ("blueprint", ".claude", ".orchestrator", "design")
    MAX_WRITTEN_TO_READ = 2_000_000   # do not slurp a giant artefact just to grep one id

    def _defining_files(token: str) -> set[str]:
        """The blueprint files a layer ID is defined in, normalised back to plain paths."""
        out: set[str] = set()
        for loc in defined.get(token, []):
            base = loc.split(" (", 1)[0]
            if base.endswith(".md"):
                out.add(base)
            else:                                   # "file.md:123" from a heading registration
                out.add(base.rsplit(":", 1)[0])
        return out

    def _resolve_written_to_path(token: str) -> tuple[Path | None, str | None]:
        """(path, note). A bare basename is resolved inside the orchestrator's own trees so a
        human writing `stack.md` instead of `.claude/rules/stack.md` gets a note, not a false
        error. Ambiguous or absent -> (None, reason)."""
        rel_tok = token.split(":", 1)[0]            # `file.py:symbol` -> `file.py`
        direct = ROOT / rel_tok
        if direct.is_file():
            return direct, None
        if "/" in rel_tok:
            return None, "does not exist"
        found = [p for root in WRITTEN_TO_SEARCH_ROOTS
                 if (ROOT / root).is_dir()
                 for p in (ROOT / root).rglob(rel_tok) if p.is_file()]
        if len(found) == 1:
            return found[0], f"resolved to {found[0].relative_to(ROOT)}"
        if not found:
            return None, "does not exist"
        return None, f"is ambiguous ({len(found)} files share that name)"

    written_to_targets: dict[str, set[str]] = {}    # DEC id -> repo-relative files it covers
    for dec_id in sorted(dec_written_to):
        covered: set[str] = set()
        for tok in dec_written_to[dec_id]:
            if "<" in tok or ">" in tok:
                continue                            # unresolved placeholder: already warned
            if ID_PATTERN.match(tok):
                covered.update(_defining_files(tok))
                continue
            if not PATH_TOKEN.match(tok):
                continue                            # already warned as a non-ID token
            target, note = _resolve_written_to_path(tok)
            if target is None:
                errors.append(
                    f"blueprint/DECISIONS.md ({dec_id}): written_to declares '{tok}', which "
                    f"{note}. `written_to` is a claim about the filesystem — where this decision "
                    f"actually landed — and a claim nobody can resolve is not a record. Write the "
                    f"repo-relative path, or drop it if the decision was never applied there")
                continue
            rel_target = str(target.relative_to(ROOT))
            covered.add(rel_target)
            if note:
                warnings.append(
                    f"blueprint/DECISIONS.md ({dec_id}): written_to says '{tok}' and it {note} — "
                    f"write the repo-relative path so the next reader does not have to guess")
            try:
                if target.stat().st_size <= MAX_WRITTEN_TO_READ:
                    body = target.read_text(encoding="utf-8", errors="replace")
                    if dec_id not in body:
                        warnings.append(
                            f"blueprint/DECISIONS.md ({dec_id}): written_to declares {rel_target}, "
                            f"but that file never mentions {dec_id}. Either the decision did not "
                            f"land there after all, or it landed without a trace — this is a "
                            f"warning, not an error, because a file may carry a decision without "
                            f"citing it")
            except OSError:
                pass                                # unreadable is not a lint failure
        written_to_targets[dec_id] = covered

    for rel, body in sorted(file_texts.items()):
        if rel == "blueprint/DECISIONS.md":
            continue                                # the ledger citing itself proves nothing
        for dec_id in sorted(set(DEC_MENTION.findall(body))):
            if dec_id not in written_to_targets:
                continue                            # no declaration for this decision to contradict
            if rel in written_to_targets[dec_id]:
                continue
            warnings.append(
                f"{rel}: cites {dec_id}, but that decision's written_to does not name this file "
                f"(it names {sorted(written_to_targets[dec_id]) or 'nothing'}). The ledger is the "
                f"record of where a decision landed, so a landing site it does not list is a "
                f"record that has already started drifting from the thing it records")

    # --- referential integrity is BIDIRECTIONAL -------------------------------
    # The loop above closes one direction: a citation pointing at an ID nothing defines.
    # The other direction was open, and it is the expensive one — a layer declaring
    # `related_screens: [SCR-014]` while SCR-014's `applies[]` never names it back.
    #
    # It matters because EVERY lens scopes itself to `applies[]`. verify-blueprint-drift
    # compares the code against "each blueprint layer the unit cites"; verify-conformance
    # does the same; research-* judges coverage for the screen against what it applies. So a
    # layer nobody cited has no owner: the unit is never judged against it, and it closes
    # green having proven nothing about it. A dangling reference is loud — the plan cites
    # intent that does not exist. This one is silent, which is why it survives longer.
    #
    # WARNING, not error, for one concrete reason: the documented authoring order writes
    # SCREENS.md LAST (USO.md §3, "el último, porque necesita saber a qué IDs apunta cada
    # unidad"). Every project therefore passes through a long, legitimate window where the
    # layers already claim screens that are not written yet or do not cite back. Failing
    # there would fire on healthy work-in-progress, and a check that refuses valid states
    # gets routed around. It surfaces separately in `uncited_claims[]` under --json so
    # /init-build can turn it into a CLARIFY question instead of leaving it in the warning
    # pile, which is exactly what this linter's warnings are for.
    seen_claims: set[tuple[str, str]] = set()
    for claimant, screen_id, rel in claims:
        if claimant == screen_id:
            continue                       # a block naming itself carries no claim
        if screen_id == "ALL":
            continue                       # documented sentinel (shell rules: every ui screen)
        if not ID_PATTERN.match(screen_id):
            continue                       # placeholder/non-ID: already warned above
        # One pair, one question. `related_screens: [SCR-001, SCR-001]` is one claim written
        # twice, and every row here becomes a CLARIFY question — duplicating them would ask a
        # human the same thing N times, which is how a question round stops being read.
        if (claimant, screen_id) in seen_claims:
            continue
        seen_claims.add((claimant, screen_id))
        if screen_id not in screen_applies:
            # NOT "already handled above" — that was wrong, and the wrongness was silent.
            # The dangling-ref loop only speaks when a token is in NO block at all. An ID that
            # IS defined, but as a ```logic``` block rather than a ```screen``` one, passed
            # both checks without a word: the first because it resolves, this one because it
            # has no applies[] to compare against. The claim is still broken — a layer cannot
            # be "related to" something that is not a unit — so say so here.
            if screen_id in known_ids:
                uncited.append({"file": rel, "block": claimant, "screen": screen_id,
                                "reason": "target_is_not_a_screen"})
                warnings.append(
                    f"{rel} ({claimant}): related_screens claims {screen_id}, which is defined "
                    f"but NOT as a ```screen``` block — so it is not a unit and cannot cite "
                    f"anything back. Either {screen_id} is the wrong ID, or it belongs in "
                    f"depends_on/product_refs rather than related_screens"
                )
            continue                       # undefined IDs are already an error above
        if claimant in screen_applies[screen_id]:
            continue
        uncited.append({"file": rel, "block": claimant, "screen": screen_id,
                        "reason": "not_cited_back"})
        warnings.append(
            f"{rel} ({claimant}): related_screens claims {screen_id}, but {screen_id}.applies[] "
            f"does not cite {claimant} — one of the two is wrong. Every lens scopes itself to "
            f"applies[], so as written {claimant} has no owner on that unit and nothing will "
            f"judge the code against it"
        )

    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str, stack: list[str]) -> None:
        if node in visited:
            return
        if node in visiting:
            errors.append("after[] dependency cycle: " + " -> ".join(stack + [node]))
            return
        visiting.add(node)
        stack.append(node)
        for dep in after_edges.get(node, []):
            dfs(dep, stack)
        stack.pop()
        visiting.discard(node)
        visited.add(node)

    for node in sorted(after_edges):
        dfs(node, [])

    if args.as_json:
        # Machine contract for /arch-review and the arch-* lenses. Errors still set the
        # exit code, but they are IN the payload too: a consumer that only reads stdout
        # must not have to infer a broken blueprint from a status code it never saw.
        payload: dict[str, object] = {
            "schema_version": "orchestrator.blueprint-lint.v1",
            "errors": errors,
            "warnings": warnings,
            # Split out of `warnings` on purpose: each row names a specific pair of IDs a
            # human must reconcile, so it is a CLARIFY question with a machine-readable
            # subject, not a line to skim. Always present, empty when there is nothing.
            # `reason` is `not_cited_back` (the screen exists and does not cite the claimant)
            # or `target_is_not_a_screen` (the claimed ID is defined, but not as a unit).
            "uncited_claims": uncited,
            # Per-family coverage of this linter's own machinery: how many ids of each family
            # reach the shared registry versus how many exist only as markdown headings. It is
            # here rather than only in the warning because the warning is deliberately narrow
            # (a family entirely outside the registry), while the table answers the broader
            # question that went unasked for so long: which families is this linter actually
            # checking? A reader can see 15/16 instead of inferring it from silence.
            "family_coverage": family_coverage,
            "counts": {"errors": len(errors), "warnings": len(warnings),
                       "uncited_claims": len(uncited)},
        }
        if args.decidedness:
            payload["undecided_fields"] = undecided
            payload["counts"] = dict(payload["counts"], **{
                "undecided_fields": len(undecided),
                "undecided_placeholder": sum(1 for u in undecided if u["reason"] == "placeholder"),
                "undecided_template_default": sum(1 for u in undecided if u["reason"] == "template_default"),
            })
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        raise SystemExit(1 if errors else 0)

    for warning in warnings:
        print(f"warning: {warning}")
    if args.decidedness:
        for item in undecided:
            print(f"undecided: {item['file']} ({item['block']}): {item['key']} = "
                  f"{item['value']!r} — {item['reason']} "
                  f"[block_match_ratio {item['block_match_ratio']}]")
    if errors:
        for error in errors:
            print(f"error: {error}", file=sys.stderr)
        print(f"blueprint lint FAILED: {len(errors)} error(s), {len(warnings)} warning(s)", file=sys.stderr)
        raise SystemExit(1)
    tail = f", {len(undecided)} undecided field(s)" if args.decidedness else ""
    print(f"blueprint lint OK ({len(warnings)} warning(s){tail})")


if __name__ == "__main__":
    main()
