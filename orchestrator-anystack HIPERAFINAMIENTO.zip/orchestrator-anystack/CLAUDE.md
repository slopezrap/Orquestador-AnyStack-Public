# CLAUDE.md — orchestrator-anystack

A blueprint-driven orchestrator that builds one screen/unit at a time with real verification and
an acceptance gate — pressed by a human, or by a written policy for the units that policy covers.

## Governance

The rules below are the single source of truth. This file does not restate them; it points.

@.claude/rules/constitution.md
@.claude/rules/conventions.md
@.claude/rules/stack.md

`.claude/rules/autonomy.md` is the fourth. It loads with the others — Claude Code discovers
`.claude/rules/**/*.md` recursively and loads every file that declares no `paths:` frontmatter, at
the same priority as this file — but **read it explicitly at the two moments that consult it** —
*Think first, then ask* when the sources are silent, and `/accept --auto` before it accepts
anything. The explicit `Read` buys precision, not tokens: it puts the policy in front of you at
the moment a decision is taken instead of leaving it as background.

`.claude/policy/stack-infra.md` is deployment and infra governance. It lives outside
`.claude/rules/` on purpose — cold memory, read on demand, never loaded every turn.

## Main conductor

The main session runs as `orchestrator-flow` via `.claude/settings.json`. Never call
`Agent(orchestrator-flow)`; use `Agent(...)` only for specialist lenses, which explore, verify and
review but never own code changes or state transitions.

## Runtime truth — read disk, not chat

| What | Where |
| --- | --- |
| Work plan (the executable one) | `.orchestrator-state/features.json` |
| Consolidated spec | `.orchestrator-state/spec.md` |
| Handoff log | `.orchestrator-state/progress.md` |
| Evidence per unit | `.orchestrator-state/evidence/<ID>/result.json` |
| Batch state (`/build-loop`) | `.orchestrator-state/batch.json` |

**An ID is a reference, not intent.** For every active unit read its title, description,
acceptance criteria, `applies[]`, source refs, routes, platform, verification plan and the
blueprint sections behind them.

**The blueprint is a living spec.** Any product intent the human states, and any
blueprint-relevant fact the build discovers, is written into `blueprint/**` before you act on it —
then `lint-blueprint.py`, then reflect it in `spec.md`, then `/reslice` if it changes a compiled
or accepted contract. Full rule: `constitution.md` §Blueprint write-back.

## Commands

| Command | What it does | Runs automatically |
| --- | --- | --- |
| `/init-build` | blueprint + design → `spec.md` + `features.json`. May ask CLARIFY. Builds no screens. | — |
| `/discovery [--report-only]` | t=0 intake gate: 6 `discovery-*` lenses walk the universal checklist; every item ends answered/filled/asked/deferred/n-a. | inside `/init-build`, before COMPILE |
| `/arch-review [--report-only]` | t=0 architecture gate: 6 `arch-*` lenses judge the DESIGN before anything is built. | inside `/init-build`, before compiling `features.json`; re-triggered by `/reslice` on architecture-hash drift |
| `/next-pantalla [ID]` | build and verify exactly one unit vertically. Writes code. Stops at `verified` or `blocked`. | — |
| `/build-loop [max] [--autonomous]` | Ralph-style batch: the full `/next-pantalla` pipeline over every ready unit, one at a time. Never accepts. `--autonomous` adds auto-accept by policy, the cross gates, and `/reslice` until convergence. | — |
| `/accept <ID> [--auto]` | the ONLY path from `verified` to `accepted`. Records `accepted_by`. | — |
| `/status` | read-only state summary. | — |
| `/reslice [reason]` | reconcile changed blueprint/design, preserving history and evidence. | — |
| `/fix "<prompt>" [--report-only]` | prompt-driven maintenance: map a free-form bug or improvement to its owning unit(s), repair, and fully re-prove. Never accepts. | — |
| `/verify-pipelines-data-ultracode <ID>` | deep gate: data engine, pipelines, API/DB consistency, logs. | inside `/next-pantalla`, after REVIEW (`--fix`, sweeps on Sonnet) |
| `/production-code-review [ID\|path\|all]` | deep gate: production readiness, DRY, YAGNI, KISS. | inside `/next-pantalla`, after REVIEW (`--fix`, sweeps on Sonnet) |
| `/review-pantalla <ID>` | live UI parity: required controls, states, design fidelity. | — (manual extra pass) |
| `/verify-app [JOUR-ID\|all]` | cross-screen gate: drive completed journeys end-to-end in the real runtime. | from `/accept`, when an acceptance completes a journey |
| `/audit-motores [ENG-ID\|PIPE-ID\|all]` | cross-architecture gate: each `ENG-*` implemented once and matching its contract, pipeline topology, real-data provenance, scale. | from `/accept`, alongside `/verify-app` |

The two cross gates emit `SCR-FIX-*` repair units that `/accept` step 9b compiles into the plan;
they never change an existing unit's status. Skills chain **inline**: read the target `SKILL.md`
and execute it in this session — never the `Skill` tool (`constitution.md` §Authority).

## Scripts

```bash
python3 .orchestrator/scripts/validate-state.py       # STATE GATE (--emit-status also writes status.json + evidence/index.json)
python3 .orchestrator/scripts/lint-blueprint.py       # blueprint lint: duplicate IDs, dangling refs, cycles, stubs, written_to vs disk
python3 .orchestrator/scripts/original-coverage.py    # reconcile ORIGINAL.md vs the layers (--extract first); feeds CLARIFY, never blocks
bash .orchestrator/scripts/validate-structure.sh      # scaffold structure + lens-set sync (.js workflows vs validate-state.py)
bash .orchestrator/scripts/reset-state.sh --force     # reset .orchestrator-state/ to a clean scaffold
bash .orchestrator/scripts/reset-test-data.sh "<PHASE>"   # CONDUCTOR ONLY, once, before any phase that executes. Lenses never call it
bash .orchestrator/scripts/preflight-check.sh "<PHASE>"   # CONDUCTOR ONLY, before every verify-fanout launch. Not evidence, never in phase_runs[]
bash .orchestrator/scripts/phase-push.sh "<PHASE>" "<ID>" # commit + push after each phase. Non-fatal
bash .orchestrator/scripts/smoke-golden-path.sh       # end-to-end smoke of the deterministic machinery
```

## After a compaction

Re-read from disk; nothing said in chat survives. Three anchors, in order:

1. **`features.json`** — the active unit's `checkpoint` (`{phase, iteration}`). Resume from that
   phase; do not restart the unit. Its `phase_runs[]` in `result.json` stays valid.
2. **`evidence/<ID>/plan.md`** — once past EXPLORE. It holds the acceptance map, the vertical
   order, the declared consumer and, past DEVELOP, what was delivered against each row. Re-deriving
   the plan is exactly what you do worst right after a compaction.
3. **`batch.json`** — one level up: `/build-loop`'s own state (its cap, units built, why it
   stopped). The unit was always resumable; the loop around it was not.

Anything the human said with product intent that is not yet in `blueprint/**` does not survive
this step. That is what the write-back rule is for, and compaction is when it gets tested.
