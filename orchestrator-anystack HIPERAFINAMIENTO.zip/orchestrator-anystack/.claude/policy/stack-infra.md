# Stack infra and log targets

Companion to `.claude/rules/stack.md`, split out because it is COLD: filled once by `/discovery`
(`Q-INFRA-*`), read rarely afterwards, and left to grow. It lives OUTSIDE `.claude/rules/` on
purpose — Claude Code loads `CLAUDE.md`, `.claude/CLAUDE.md`, `.claude/rules/*.md` and
`CLAUDE.local.md` as standing project memory, and nothing else. A file here costs nothing per turn
and costs one `Read` when it matters.

That split is the whole point: `stack.md` holds what EVERY turn needs (the stack and its commands);
this file holds what a FEW moments need. Read it with `Read`:

- in `/discovery`, when resolving `Q-INFRA-*` and writing the fills below;
- in VALIDATE, when a lens needs a log source;
- in `/verify-app` and `/audit-motores`, which judge deployed/runtime behaviour.

Write-backs land here exactly as they do in `stack.md`: structural facts as a direct edit noting the
source, genuine decisions via a `DEC-*` in `blueprint/DECISIONS.md` first. **Everything infra-shaped
belongs here, not in `stack.md`** — that is what keeps standing memory from growing without bound.

## Deployment & infra

Filled by the `/discovery` gate (Q-INFRA-*) and kept current by write-backs; deployment/infra decisions live here — infra is stack governance, not a product layer. The *why* behind each non-obvious choice goes to `blueprint/DECISIONS.md` as a `DEC-*`.

- Pilot runtime (where it runs now — local, containers, host):
- Production target (and when the jump is decided):
- Tenancy (multi-tenant / instance per client) and isolation mechanism:
- Object/file storage (if any):
- Job queue / workers (if any):
- Backups and restore drill:
- Who operates it (client-facing or abstracted):
- Environments (dev/staging/prod) and promotion path:
- Observability (logs / metrics / alerts destinations):
- SLO / expected load / cost budget (if load-bearing):

## Useful log targets

Record the real project-specific sources during `/init-build`:

- frontend/browser console logs;
- backend/server logs;
- worker/job logs;
- database/query logs;
- Android `adb logcat` logs;
- iOS simulator/device logs;
- provider/integration diagnostic logs.

If no log source exists for a required runtime, record the limitation in evidence instead of inventing logs.
