---
name: production-code-review
description: "Production-readiness review and optional cleanup for one screen/unit, path or project scope without relying on a diff. Checks code is shippable: no runtime TODOs/placeholders, no noisy comments, DRY without over-abstraction, YAGNI, KISS, errors, validation, security, tests and maintainability. Runs AUTOMATICALLY inside /next-pantalla after REVIEW (with --fix, sweeps on Sonnet); can also be re-run manually."
argument-hint: <screen-id|slug|name|path|all> [--fix|--report-only]
disable-model-invocation: true
model: sonnet
effort: xhigh
---

# /production-code-review

Run inline in the current main session. Do not use `context: fork` or call `Agent(orchestrator-flow)`. This gate runs **automatically** as part of every `/next-pantalla` (§5.5, with `--fix` on the active unit) and may also be invoked manually with any scope.

`disable-model-invocation: true` above forbids the *harness* from spawning this skill as a separate agent — it does not forbid the conductor from running it. On the §5.5 auto-launch you get here by `Read`ing this file and following it inline with `$ARGUMENTS = "<ID> --fix"`; never by calling the `Skill` tool.

Arguments: `$ARGUMENTS`

Default mode is report-only. Repair only when `$ARGUMENTS` contains `--fix` (the auto-launch from `/next-pantalla` always passes `--fix`).

**Model:** spawn every subagent (explore-scout / explore-* sweeps) this gate uses with `model: 'sonnet'`; the conductor remains the single writer.

## 0. Resolve scope

1. Read `CLAUDE.md`, `.claude/rules/*.md`, `.orchestrator-state/spec.md`, `.orchestrator-state/features.json` and `.orchestrator-state/progress.md`.
2. Interpret `$ARGUMENTS`: `SCR-*`/slug/title reviews relevant feature files; a path reviews that path; `all` reviews app/product code and tests excluding dependency/build/generated directories.
3. If feature-scoped, run `explore-scout` (or the `explore-*` lens-agents) for relevant files and commands.
3b. If feature-scoped and `.orchestrator-state/evidence/<ID>/result.json`'s `verify_digest` exists, read its `findings[]` and `source_refs[]` first — `verify-quality` and `verify-logs` already surfaced code-quality/log findings during VERIFY. Confirm/extend/refute each one exactly as `pantalla-reviewer` does (cite the same evidence to confirm, your own command+output+artifact to refute); it narrows where to look first, it never replaces the checklist walk in §1.
4. If scope is too broad, narrow it and state the chosen scope before edits.
5. If target is `accepted`, run report-only and recommend `/reslice` if the accepted contract should reopen.

## Status guard (before any --fix edit and before writing any verdict)

Apply per the target unit's status, mirroring the reopen protocol in `constitution.md` (Minimal lifecycle) and its sibling gates:
- **`building`** (the §5.5 auto-gate path, the normal case): repair freely; a FAIL leaves `passes:false` for the conductor to resolve — the unit is already in flight.
- **`verified`** (a manual `--fix` re-run): do NOT write `verified` + `passes:false`/`verdict:"FAIL"` — that state is rejected by the STATE GATE. If you repair its code or FAIL it, REOPEN it per `constitution.md` §Minimal lifecycle (both counters and both caps are stated there). Specific to this skill: record `CHK-<ID>-PRODUCTION-CODE-REVIEW` with `required:true, passed:false` and its `failures[]` entry, append `REOPENED <ID> (production-code-review --fix|FAIL)` to `progress.md`, and hand back with `Next: /next-pantalla <ID>`. The re-VERIFY/re-VALIDATE there re-earns the PASS evidence.
- **`accepted`**: report-only (step 5 above); never auto-edit.

## 1. Review checklist

Production blockers:

- final `TODO`, `FIXME`, `HACK`, placeholder UI, fake responses, demo constants or mock-only acceptance paths;
- hardcoded secrets, tokens, private payloads or personal data;
- console/print/debug logs not suitable for production;
- commented-out code;
- broad catches that swallow errors;
- missing input validation at boundaries;
- missing permission/tenant/user scoping declared by `PERM-*`;
- invalid state transitions declared by `ST-*`;
- error behavior inconsistent with `ERR-*`;
- tests that pass without the real required backend/DB/provider boundary.

- frontend/mobile data constants, local JSON product truth, duplicated platform-specific business values or mock API paths used as acceptance behavior;
- pipelines that transform or generate data without persisting the canonical value in the declared canonical store (database, event store/projection, state store/checkpointer, ledger or external system of record).

Comments policy: remove comments that merely repeat code, narrate history or hide uncertainty. Keep only legal/license headers, public API docs required by the project, generated-code markers, lint/tooling markers, framework directives or non-obvious domain/security/provider rationale.

DRY / YAGNI / KISS:

- DRY only when duplication creates real maintenance risk or inconsistent behavior.
- Prefer small local functions over broad abstract frameworks.
- Delete unused code instead of routing around it.
- Keep names direct and domain-specific.
- Avoid configuration switches not used by the active contract.
- Simplify control flow without changing product behavior.

## 2. Optional fix

If `--fix` is present, apply the smallest safe cleanup, do not broaden architecture, do not prebuild future units, rerun relevant formatter/linter/type/test/smoke commands from `.claude/rules/stack.md`, and refresh evidence if needed.

If `--fix` is absent, do not modify code. Return prioritized findings with exact files, symbols and commands.

## 3. Evidence

For feature scope, write `.orchestrator-state/evidence/<ID>/reports/production-code-review.md`.

For path/all scope, write `.orchestrator-state/evidence/global/reports/production-code-review.md`.

Report format:

```markdown
# production-code-review

## Scope
## Commands/checks run
| Check | Command | Result | Evidence |
## Blocking findings
## Non-blocking cleanups          <- ALSO written to result.json.advisory_findings[]
## Fixes applied
## Verdict
PASS|FAIL|BLOCKED
```

**A non-blocking finding is RECORDED, not repaired.** Write every item under *Non-blocking
cleanups* into `result.json.advisory_findings[]` as `{id, severity, source:"production-code-review",
detail, refs, status:"open"}` — and then leave it alone. Do not fix it, do not open a repair pass
for it, do not let it fail a check.

This is the exit that keeps the loop finite. A finding used to have one way to be discharged —
fix it — so a cleanup of any size forced a repair, the repair produced new surface, and the next
round found something in the new surface. Measured on a real run: more than half the debugger
rounds did not fix code, they fixed the trail. The report section already existed; what did not
exist was anywhere downstream that consumed it, so repairing was the only way to stop a cleanup
being forgotten. Now it is carried: `/accept --auto` weighs its severity against the ceiling in
`.claude/rules/autonomy.md`, and a human reading the evidence sees it named.

The boundary is not negotiable: if it blocks, it is a **blocking finding** and goes to
`failures[]`/`checks[]` as always — `verified` still requires `verdict:"PASS"` with `failures`
empty. The gate rejects a finding recorded as `accepted_as_debt` that also sits in `failures[]`.
Recording debt is not lowering the bar; pretending the debt was never found is.

For feature scope, merge a check into `.orchestrator-state/evidence/<ID>/result.json.checks[]`:

```json
{
  "id": "CHK-<ID>-PRODUCTION-CODE-REVIEW",
  "name": "Production readiness review",
  "type": "production_code_review",
  "required": true,
  "passed": true,
  "acceptance_ids": [],
  "artifacts": [".orchestrator-state/evidence/<ID>/reports/production-code-review.md"],
  "notes": "No production blockers: no placeholders/TODO/mock-as-final, no secrets, DRY/YAGNI/KISS respected."
}
```

The check id is stable and required: `/accept` looks for it by id, and its ABSENCE means this gate never ran. Path/`all` scope writes no check (there is no unit to gate).

If the verdict is FAIL, merge the same check with `passed:false` and add the blocking findings to `result.json.failures[]`. On a unit that is already `verified`, apply the Status guard above (reopen to `building`) instead of leaving `verified` + `passes:false`, which the gate rejects. Never change an `accepted` unit automatically.

## 4. Close

Run `python3 .orchestrator/scripts/validate-state.py` and `bash .orchestrator/scripts/validate-structure.sh` after any state write.

End with:

```text
Scope: <screen/path/all>
Verdict: PASS|FAIL|BLOCKED
Report: <path>
Next: <exact next command>
```

Never move a screen to `accepted`.
