---
name: accept
description: The acceptance gate. Accept one verified screen/unit and unlock dependent units. Invoked by a human, or by policy under --auto.
argument-hint: "<screen-id> [--auto]"
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /accept

Run inline in the current main session. Do not implement code.

Arguments: `$ARGUMENTS`

## Who may press the button

This skill is the ONLY path from `verified` to `accepted`. That has not changed and does not change.

What changed is who invokes it. **Every precondition below is machine-checkable, and step 3 IS the STATE GATE** — there is no step here where a human reads code or looks at a screen, and nothing ever verified that they did. The human contributed exactly one thing: typing the command. So `--auto` does not weaken a single check; it lets a written policy press the button when every check already passed and the unit falls inside what that policy covers.

The judgement a human actually adds — *does this look right, is this what I meant* — is real and is not in this list. `.claude/rules/autonomy.md` protects it explicitly: anything in its **sensitive areas** never auto-accepts, however green its evidence. That is the queue a human reviews, and it is deliberately much smaller than "everything".

Without `--auto` this behaves exactly as it always has.

## Preconditions

- ID exists in `.orchestrator-state/features.json`.
- status is `verified`.
- `passes:true`.
- evidence file exists.
- `result.json.verdict == "PASS"`.
- all required checks passed, including any checks added by `/review-pantalla`, `/verify-pipelines-data-ultracode` or `/production-code-review`.

- if the unit cites `DATA-*` or has `data_engine`, `result.json` contains passing `data_engine_assertions[]` proving engine -> canonical store -> API/service/read-model -> client equality (with observed literal `db_value`/`api_value`/`ui_value`), or a concrete not-applicable reason.
- `result.json.phase_runs[]` proves the full workflow cycle ran with complete lens sets (the STATE GATE enforces this; a unit that skipped a fan-out workflow cannot be accepted).
- failures are empty.

## Flow

1. Read `features.json` and the selected `result.json`.
2. Validate preconditions.
   - For data-bearing units, reject acceptance if the visible/API values are not proven to come from the declared canonical store value (falsifiable equality over observed literal db_value/api_value/ui_value).
   - The unit's `result.json` must be `verdict:"PASS"` with `passes:true`, and its `checks[]` must contain BOTH §5.5 auto-gate checks by id, each `passed:true`: `CHK-<ID>-PRODUCTION-CODE-REVIEW` and `CHK-<ID>-PIPELINES-DATA-ULTRACODE` (the latter may be `required:false, passed:true, notes:"not applicable"` when the unit cites no data engine). A missing check means that gate never ran — do not accept; hand back to `/next-pantalla <ID>`.
3. Run `python3 .orchestrator/scripts/validate-state.py`.
3b. **Under `--auto` only — the policy check.** Read `.claude/rules/autonomy.md` and accept ONLY if all hold; the preconditions above are necessary, these are additionally required:
   - the unit touches no **sensitive area** listed there (auth/permissions, payments, personal data, irreversible user-facing actions, the shared shell `UI-SHELL-*`, destructive migrations, and whatever the project added);
   - no open advisory finding against it reaches that file's severity ceiling — read `result.json.advisory_findings[]` and the two gate reports, do not assume;
   - `autonomy.md` has no unresolved `<PLACEHOLDER>` in the sections you are relying on. An unfilled policy has not authorized anything, and reading a placeholder as permission is the one failure mode that would make this whole mechanism dishonest.

   If any fails, do NOT accept and do NOT block: leave the unit `verified`, add it to the human review queue, print why, and return. A unit waiting for a human is a normal outcome of an autonomous run, not an error — the batch continues with its siblings.
4. Change selected unit to `accepted`, and record who accepted it in `result.json.human_gate`: `{accepted_by: "human" | "auto", accepted_at, policy_rule: "<the autonomy.md rule>" (auto only), reviewed_findings: [<ids considered>]}`. This is what makes an autonomous run auditable after the fact — without it, three weeks later nothing distinguishes a unit a person signed off from one a policy did, and the first question anyone asks about an unattended run is exactly that.
5. Mark `todo` dependents as `ready` when all `after[]` dependencies are accepted.
6. Append `ACCEPTED <ID>` to progress.
7. Validate again (`python3 .orchestrator/scripts/validate-state.py --emit-status` to refresh the external read projections).
8. **Cross-screen auto-gate:** if this acceptance completed one or more journeys (`JOUR-*` in `blueprint/logic/journey.md` whose UI screens are now ALL `accepted`), automatically run `/verify-app <JOUR-ID>` for each (follow `.claude/skills/verify-app/SKILL.md`). Concrete seam defects become `SCR-FIX-VERIFY-APP-*` repair units (max 3 per run, worst first), compiled into the plan by step 9b below; it never re-opens or moves an EXISTING unit's status.
9. **Cross-architecture auto-gate:** on the same trigger (an acceptance that completed a journey), also run `/audit-motores` once (follow `.claude/skills/audit-motores/SKILL.md`). Where `/verify-app` walks the journey LIVE, this one audits the built product STATICALLY: every `ENG-*` implemented exactly once and faithful to its contract, the `PIPE-* → canonical store → ENG-* → read-model → screens` topology, real-data provenance, module coupling and scale profile. Architecture debt becomes a `SCR-FIX-AUDIT-*` repair unit, compiled into the plan by step 9b below; pending blueprint write-backs are written back. It never moves an EXISTING unit's status.
9b. **Absorb what the gates emitted.** Re-read `features.json` and check `meta.verify_app.emitted_fixes[]` and `meta.audit_motores.emitted_fixes[]`. If either is non-empty, **run `/reslice` inline** (`Read` `.claude/skills/reslice/SKILL.md` and execute its protocol, per the inline-chaining rule in `constitution.md`; never the `Skill` tool), with the reason `absorb SCR-FIX from <gate>`.

   Without this the cycle does not close. Steps 8 and 9 write repair units into `blueprint/SCREENS.md`, and `SCREENS.md` is not the runtime plan — `features.json` is. A `SCR-FIX-*` that nobody compiles is invisible to `/next-pantalla`, which selects from `features.json` alone: the gate did its work, wrote a real defect down, and nothing would ever pick it up. `/build-loop --autonomous` has always closed this itself (its ABSORB step), which is exactly why the hole was invisible — the unattended path worked and the ordinary one silently did not.

   `emitted_fixes[]` is the trigger because it is a fact on disk written by the gate itself, not a recollection of what just happened. Empty means the gates found nothing and there is nothing to compile: skip, and do not reslice for its own sake.

   **`/reslice` may stop and ask, and if it does, let it.** Its step 4 requires CLARIFY before changing scope, deleting accepted work, changing IDs or breaking dependencies. Compiling a new `SCR-FIX-*` does none of those, so the normal path needs nobody. But if this one *does* raise a CLARIFY, that is a Tier-3 question: do NOT answer it to keep the flow moving. Report it, leave the emitted units in `SCREENS.md` — they are recorded, not lost — and say plainly that a `/reslice` is pending. This step compiles work; it never accepts any of it, and the units it creates are born `todo`/`ready` like any other.

10. Print the outcome and the next suggested command, or project complete. Under `--auto`, say plainly which it was — `AUTO-ACCEPTED <ID> (policy: <rule>)` or `LEFT FOR HUMAN REVIEW <ID>: <the precise reason>`. A run that accepted nine units and left one for you is only useful if the tenth is impossible to miss. When step 9b compiled repair units, name them and point at `/next-pantalla`; when it stopped on a CLARIFY, say that instead — an unabsorbed `SCR-FIX-*` is work the plan does not yet know about.

If evidence fails, do not repair here. Use `/next-pantalla <ID>`.
