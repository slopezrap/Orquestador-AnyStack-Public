---
name: next-pantalla
description: Build and verify exactly one screen/unit vertically using disk state and specialist agents, then stop at the acceptance gate.
argument-hint: [screen-id]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /next-pantalla

Run inline in the current main session. This command may write product code and orchestrator
state. Do not use `context: fork` or `agent:`. Do not call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

## What this command does

Build **exactly one** unit from `.orchestrator-state/features.json` — usually a screen, sometimes
a required foundation — vertically, from the canonical store out to the client, and stop at
`verified` or `blocked`. It never accepts: only `/accept <ID>` moves a unit to `accepted`.

Seven phases, in order. Five of them are fan-outs, and launching the workflow with its FULL lens
set is mandatory every time:

| # | Phase | How it runs | Produces |
| --- | --- | --- | --- |
| §1.5 | RESEARCH | `research-fanout` → all **17** `research-*` | a blueprint that specifies this unit |
| §2 | EXPLORE | `explore-fanout` → `explore-scout` + all **8** `explore-*` | `plan.md` + the bound `verification_route` |
| §3–4 | DEVELOP | **you**, inline, no fan-out | the code, and the evidence skeleton |
| §5 | VERIFY | `verify-fanout` → all **10** `verify-*` | the static verdict + `expected_ui_values[]` |
| §5 | VALIDATE | `validate-live` → `validate-logs` + per owned runtime | the live verdict + observed `ui_value` |
| §5 | REVIEW | `Agent(pantalla-reviewer)` | one contractual verdict |
| §5.5 | GATES | the two deep gates, inline, on Sonnet | their `CHK-*` checks |

DEVELOP is the only phase with no fan-out by design, and it is also the debugger (§6): on any
failure you repair in-thread and re-run what the repair invalidated, up to 3 iterations.

The rules that govern all of this live in `.claude/rules/constitution.md`, which is standing
memory — this file is the PROCEDURE, not a second copy of the governance. Where a rule is stated
in full elsewhere, this file names it and moves on.

## Cross-cutting discipline

These apply in every phase below.

### You are the whole delivery team (expert roles)

You hold every role needed to ship the unit, each at senior level — see `constitution.md`
§Expert roles for what "senior" obliges. Each phase materializes those roles as lens-agents, or
as hats you wear directly:

| Phase | Roles, as lenses or hats |
| --- | --- |
| RESEARCH | one lens per blueprint file: product owner (`product`), architect (`core`/`screens`), DBA (`data`), backend (`application`), security (`permission`), UX (`ui`/`design`), cross-screen shell (`shell`), state (`state`), reliability (`error`), integration (`integration`), domain (`domain`), use cases (`usecases`), journey (`journey`), engine (`engine`), data engineer (`pipeline`) |
| EXPLORE | `explore-scout` + by scope: `data`, `backend`, `ui`, `tests`, `existing`, `engine`, `pipeline`, `config` |
| DEVELOP | **you**: architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA at once |
| VERIFY | `tests` (QA), `conformance` (requirements), `engine`/`pipeline` (data/runtime), `design`+`frontend` (UX), `logs` (SRE), `quality` (production), `coherence` (cross-screen drift), `blueprint-drift` (doc↔code drift) |
| VALIDATE | `logs` + `web`/`android`/`ios` per owned platform + `engine`/`pipeline` when cited |
| REVIEW | `pantalla-reviewer` — tech lead, contractual sign-off |

For the active unit, extract what each role needs from the blueprint, design and code
(architecture, data model and canonical store, API/service contract, deploy/runtime/env and CI,
permission gates, acceptance/test plan). DevOps/infra concerns no lens owns — environment,
runtime wiring, the checkpoint push below — are yours directly.

### Think first, then ask

Canonical rule: `constitution.md` §Expert roles. The sequence, because you execute it here:

1. **Resolve it yourself** — re-read the blueprint/design/code, including `ORIGINAL.md` and the
   `DEC-*` ledger; consult official docs when the answer is version-sensitive.
2. **Then consult the policy.** If the sources are silent, read `.claude/rules/autonomy.md`. A
   Tier-1 default applies silently; a Tier-2 one applies with a `DEC-*` (`decided_by:
   "auto:<rule>"`, the rejected alternative, a trip-wire). Tier 3 is never decided here.
3. **Ask** one precise question if it is still genuinely unresolved. Any phase may ask, but
   prefer to batch product decisions in RESEARCH (§1.5) — the cheapest point to resolve them.
4. **Persist** the answer: product intent goes into `blueprint/**` so it is never lost; a purely
   technical answer just unblocks the current step and is written nowhere.
5. **Block** only as a last resort — when the answer needs human setup or action beyond an
   answer, **or the human cannot unblock inline**. Set `blocked`, write `verdict:"BLOCKED"`
   evidence with the exact question and next action, stop.

Never invent product intent, fake a value or guess past a real unknown.

### Blueprint write-back (any phase)

Canonical rule: `constitution.md` §Blueprint write-back. You are the only writer. Two triggers:
the human expresses product intent at any moment (write it into its file BEFORE acting on it), or
you discover a blueprint-relevant fact while building (structural facts directly, product
decisions via one CLARIFY first). Routing: `BR→PRODUCT.md`, `SCR→SCREENS.md`, ID family →
`logic/*.md`, stack → `stack.md`, infra → `.claude/policy/stack-infra.md`.

After **every** write-back: run `python3 .orchestrator/scripts/lint-blueprint.py`, reflect the
change in the affected `spec.md` section, and route through `/reslice` if it changes an
already-compiled or `accepted` contract. Never patch state silently to match chat.

### Phase checkpoint push

After every phase below — RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW, each §5.5 gate,
and every debugger re-run in §6 — commit that phase's work and push it:

```bash
bash .orchestrator/scripts/phase-push.sh "<PHASE>" "<ID>"
```

It is a side effect, never a lifecycle transition: it does not change `status`, and the STATE GATE
plus `/accept` remain the only trust anchors. Non-fatal — with no git work tree or no `origin`
remote it logs and continues.

### Record each phase in `result.json.phase_runs[]` — enforced

Append an entry as each phase runs: `{phase, workflow, mode, lenses[]}`, where `lenses[]` is the
set that **actually** ran. The STATE GATE rejects a PASS whose `phase_runs` misses a phase or
carries an incomplete lens set, so a hand-picked subset makes the unit un-`verifiable`.

- Required full sets: RESEARCH → all 17 `research-*` · EXPLORE → `explore-scout` + 8 `explore-*`
  · VERIFY → all 10 `verify-*` · VALIDATE → `validate-logs` + `validate-{web,android,ios}` for
  every owned platform + `validate-engine`/`validate-pipeline` when the unit cites `ENG-*`/`PIPE-*`
  · REVIEW → `pantalla-reviewer`.
- `mode`: `"workflow"`, or `"inline-fallback"` only when the Workflow capability is genuinely
  unavailable and carrying the same full set. DEVELOP uses `"inline"`, REVIEW `"agent"`.
- The EXPLORE entry also carries `plan: ".orchestrator-state/evidence/<ID>/plan.md"` (§2).
- Never write `phase_runs` for a phase you did not run. That is fabricated evidence.

**A lens that returned nothing did not run, and the retry already happened.** Every fan-out names
the lenses that produced no result in `failed_lenses[]` — `validate-journeys` names each missing
journey as `validate-journey:<JOUR-ID>` rather than a count you would have to reconstruct. Each
fan-out re-launches its own empty lenses ONCE and reports them in `retried_lenses[]`, so
`failed_lenses[]` is already post-retry — do not re-launch it. What you own is the consequence, in order: (1) do NOT
list them in `phase_runs[].lenses`; (2) record each in `result.json.failures[]` with phase, lens
name and reason; (3) set the unit `blocked`, naming those lenses and the phase in
`blocked_reason`, with reproduction and next action. Retry (theirs), then block (yours) — there is
no third option.

### Tally real subagent launches (telemetry, not evidence)

After every fan-out call, add to a running per-unit total:

```text
launches += 1                                                     # the loader (every fan-out has one)
launches += (result.lenses.length + result.failed_lenses.length)  # every lens actually attempted
launches += result.retried_lenses.length                          # the extra relaunch for each retry
launches += 1  if result.scout   !== undefined                    # EXPLORE: the scout is its own call
launches += 1  if result.digest  !== undefined                    # RESEARCH/VERIFY: the synth reducer
```

REVIEW adds exactly 1. The two §5.5 gates add whatever calls they make internally, counted the
same way. At §7 persist the total verbatim as `result.json.subagents_spawned` — a real count for
this unit's whole build, debugger re-runs included. `/build-loop` sums it instead of guessing.

## 0. Rehydrate

Start from disk, in this order:

1. `pwd`
2. read `CLAUDE.md` and `.claude/rules/*.md`
3. read `.orchestrator-state/spec.md`
4. read `.orchestrator-state/progress.md`
5. read `.orchestrator-state/features.json`; require `initialized:true`
6. inspect the filesystem/runtime state relevant to the active unit
7. run `python3 .orchestrator/scripts/validate-state.py`
8. run `stack.md`'s setup command only if the environment needs preparing
9. run `stack.md`'s smoke command when one is declared

If the environment is broken, fix the environment first. Never start a screen on a broken base.

## 1. Choose one unit

With an ID in `$ARGUMENTS`: it must exist; `ready`, `building` and `blocked` may be retried;
`todo` only if every dependency is BUILT (`verified` or `accepted`), and mark it `ready` first;
`verified` stops with an instruction to run `/accept <ID>`; `accepted` stops as already complete.

Without an ID:

1. If any unit is `verified`, stop and ask for `/accept <ID>`. This does NOT apply when an
   explicit ID was passed — which is how `/build-loop` drives each iteration.
2. Recompute `ready` for `todo` units whose dependencies are all BUILT.
3. Choose the `ready` unit with the lowest `order`.
4. If none is ready, report complete, blocked or dependency status.

For the chosen unit set `status:"building"`, `passes:false` and
`checkpoint:{"phase":"RESEARCH","iteration":0}`, save `features.json`, append `BUILDING` to
progress.

**`checkpoint` is the crash/compaction anchor.** Update `checkpoint.phase` as each phase starts
and `checkpoint.iteration` on each debugger re-run (§6). If step 0 found the unit already
`building` with a checkpoint, **resume from that phase — do not restart the pipeline**;
already-recorded `phase_runs` stay valid.

## 1.5 RESEARCH — does the blueprint specify this unit? (fan-out)

Before touching code, make sure the blueprint fully specifies THIS unit across front, back, data
engine, pipelines, tables, infra and permissions.

- **Always launch `research-fanout`** — mandatory, not a preference. All **17** `research-*`
  lenses, every time, never a hand-picked subset; a non-applicable lens self-reports `covered:n/a`.
- Fall back to the agents sequentially and record `inline-fallback` ONLY when the Workflow
  capability is genuinely unavailable.

It returns coverage, gaps (`auto_fill` or `clarify`) and CLARIFY questions. As the single writer:

- apply `auto_fill` proposals to `blueprint/**` — structural/derivable only;
- ask the `clarify_questions` in ONE round, and write the agreed answers into `blueprint/**`;
- run `python3 .orchestrator/scripts/lint-blueprint.py` after any write — your edits must leave
  the blueprint referentially intact;
- if a blocking product gap cannot be resolved, set `blocked`, write `BLOCKED` evidence and stop.

Proceed only when the blueprint specifies this unit unambiguously, and re-read the updated
feature/blueprint before planning. Then push the RESEARCH checkpoint.

## 2. EXPLORE and plan (agents feed you; you hold the thread)

Get an actionable context contract from a deep explore over the existing code.

- **Always launch `explore-fanout`** — `explore-scout` lists relevant files by scope, then all
  **8** `explore-*` lenses audit them in parallel. Never a subset.
- `inline-fallback` only when Workflows are genuinely unavailable.

You own the single consolidated context; the lenses cover disjoint scopes, so the maps never
conflict. Handle what they flag with *Think first, then ask*: a `block_signal` (missing or
contradictory product intent, undeclared data owner, ambiguous architecture) is resolved from the
sources, then asked, then blocked — never guessed. A technical-context `risk` you resolve
yourself and proceed.

From the consolidated `acceptance_map[]`, write the vertical plan in dependency order:

```text
data/schema -> backend/API -> UI/flow -> tests -> verification/evidence
```

Map every acceptance criterion to implementation and evidence. For data units, map every critical
value through the architecture-appropriate path:

```text
engine refs -> generation (migration/seed/backfill/job/api_write/replay/transition)
            -> canonical store value -> service/API/read model -> client field
```

Do not plan UI before the canonical data path is clear. **Bind the `verification_route` now**: §5
uses it and does not re-derive verification from journey refs.

### Write the plan to disk — enforced

The plan is EXPLORE's deliverable, not a note to yourself. Write
`.orchestrator-state/evidence/<ID>/plan.md` and cite it from the EXPLORE entry of `phase_runs[]`.
The STATE GATE requires the field and checks the file is real, non-empty and inside this unit's
own evidence directory. Shape:

```markdown
# PLAN <ID> — <title>

- **verification_route**: <what EXPLORE bound: platforms, engine/pipeline, log sources>
- **consumer** (who exercises this unit): <for a `kind: foundation`, the SCR-* that will
  actually run it and how far behind it sits in build order; for a ui/backend unit, itself>

## Acceptance map            <- one row per acceptance criterion, no exceptions
| criterion | governing IDs | files to touch | how it will be proven | expected artifact |

## Vertical order            <- data/schema -> backend/API -> UI/flow -> tests
## Risks accepted            <- each with the trip-wire that would reopen it
## Delivery                  <- left empty here; filled at the end of DEVELOP (§4)
## Learned for the blueprint <- same: empty here, filled at the end of DEVELOP (§4)
```

**A criterion with no answer in *how it will be proven* is a criterion that will fail VERIFY.**
If you cannot fill that column, you have not finished EXPLORE — go back to the lenses or ask. Do
not write code and hope the proof appears later. The **consumer** line asks per unit what the
gate asks globally at `/init-build`: who will actually run this. Rationale: `DEC-ORCH-001`.

Then push the EXPLORE checkpoint.

## 3. Build vertically

You write the code, wearing every DEVELOP hat at once: layering as the architect, canonical store
and migrations/seeds as the DBA, pipelines and generation as the data engineer, API/service
contract and business rules as the backend, client UI/flow (inside the shared shell, reusing the
component inventory) as the frontend/mobile engineer, runtime and wiring as DevOps, permission
and input gates as security, tests and evidence as QA — in one coherent vertical. If a role's
input is still missing now, apply *Think first, then ask*; never guess.

Implement only the selected unit and the support it needs:

1. data model / schema / migration / seed
   - compile the unit's `data_engine` into concrete schema, seeds/generator, backfill/job or
     write path;
   - generate verification data in the canonical store, never in frontend constants or mock files;
2. domain / application / core logic;
3. API / service / integration boundary;
4. UI or mobile flow;
5. tests and verification hooks for this unit.

Three standing rules bind here and are stated once, in `constitution.md`: no stubs, fake data,
TODOs or mock-only paths (§Production quality); library coherence before adding any dependency
(§Production quality); every client reading product values through the same API/read model
(§Data engine authority). What this phase adds: **if verification needs data that does not exist
yet, produce it through the unit's declared REAL generation path** (migration/seed/backfill/job/
api_write/event replay/state transition) into the canonical store — never invent it at any layer.

### Build for what VERIFY will ask — every time you write code

VERIFY does not introduce new standards; it measures the ones that applied while you were writing.
**Every finding it raises that you could have anticipated is an iteration you spent to be told
something you already knew.** So hold all ten lenses in view AS you build, not after:

| What will be measured | So while writing, make sure |
| --- | --- |
| `verify-frontend` | it compiles, type-checks and lints — this one runs first in the serialized chain because everything downstream is invalid if it fails |
| `verify-tests` | the unit's tests exist, run and pass; a test you planned in `plan.md` and did not write is a criterion with no proof |
| `verify-conformance` | the code does what the cited `applies[]` IDs say, and every `## Delivery` line you are about to write is true of the code |
| `verify-design` | the screen matches its `design_ref` and uses `design/tokens.css` — never a hardcoded colour, spacing or radius |
| `verify-engine` | the `ENG-*` contract is honoured: declared inputs/outputs only, real determinism, the version stamped where the decision is produced |
| `verify-pipeline` | the `PIPE-*` contract runs: declared trigger, idempotency key, real generation path into the canonical store — no fixtures at any layer |
| `verify-logs` | operations log start/end, correlation ids, state transitions and typed errors — and no secrets, and no new runtime errors |
| `verify-quality` | production-grade: no stubs, TODOs, dead code, commented-out blocks or placeholder behaviour; DRY inside the unit; reuse the dependency that already solves the concern |
| `verify-coherence` | HORIZONTAL — reuse the shared shell and its component inventory instead of a private copy, follow the route/API convention, and match the sibling `verified`/`accepted` screens. This is what the §4 harvest into `shell.md` records |
| `verify-blueprint-drift` | VERTICAL — no knowledge that lives only in code. As you discover a fact the spec does not have, note it for `## Learned for the blueprint` (§4) while it is fresh |

The last two are the ones that most often cost a round, because their subject is not the code in
front of you: coherence looks sideways at screens you did not write, and drift looks up at
documents you did not open. Both are cheap to satisfy while writing and expensive to satisfy
afterwards — the fix is a component you did not duplicate and a line you noted, not a repair pass.

If the unit cannot be completed, set `blocked`, write `result.json` with `verdict:"BLOCKED"`,
append progress and stop.

## 4. Evidence skeleton, and closing the plan

Create:

```text
.orchestrator-state/evidence/<ID>/
├── result.json          # starts as FAIL; upgraded only after real verification
├── plan.md              # written at the end of EXPLORE (§2); here you fill its last two sections
├── screenshots/  logs/  traces/  db/  recordings/  videos/  reports/
```

Three things happen here, all before VERIFY, and none of them costs a subagent.

**1 — DECLARE what you delivered.** Fill `plan.md`'s `## Delivery`: one line per acceptance row —
delivered, delivered with a deviation (what changed and why), or not delivered (why not). This is
a declaration, not a self-review: `verify-conformance` confirms or refutes each line against the
code and `pantalla-reviewer` weighs it in the verdict. Deviating from the plan is legal;
deviating in **silence** removes the only record of what the code was supposed to be.

**2 — HARVEST the shared contract, one sweep over the whole surface.** Write every shared
convention this unit introduced into `blueprint/logic/shell.md` — reusable components
(`UI-SHELL-003`), the navigation map (`UI-SHELL-002`), route and API conventions, design-token
usage — then run `lint-blueprint.py`. It happens HERE, before VERIFY, because `verify-coherence`
audits it in §5; and in ONE sweep over everything the unit added, never piece by piece as a lens
names them. This is safe before the code is proven because *"this unit created a shared
`<DataTable>`"* is a structural fact, true the moment the code exists. If a later repair adds or
renames a shared piece, sweep again — one edit, not a round.

**3 — LIST what this unit learned.** In the same edit, fill `## Learned for the blueprint`: one
line per fact the spec does not yet contain — an error case, a state transition, a data
constraint, a provider quirk, a shared component, a new dependency — each with the layer it
belongs to (`ERR-*` → `logic/error.md`, a shared component → `logic/shell.md`, a dependency →
`stack.md`). Write "nothing" if there genuinely is nothing; that is a claim a lens can refute.
**This is a LIST, not a write:** you do NOT edit `blueprint/**` here. The harvest itself waits
for §7, because a fact learned in DEVELOP is not yet true of anything — VERIFY may contradict it.

The list is also what `verify-blueprint-drift` reads to tell two very different findings apart: a
fact ON it is **acknowledged**, pending harvest, and not a defect; a fact NOT on it is something
you never noticed — a much smaller set, and a much more useful finding.

Then push the DEVELOP checkpoint.

## 5. Verify → Validate → Review (from the bound route)

Run the three quality phases from the `verification_route` bound in EXPLORE, not from journey
refs. Each phase always launches its fan-out workflow with its FULL lens set (§Cross-cutting);
`inline-fallback` only when Workflows are genuinely unavailable, carrying the same set.

Lens-agents save only their own evidence artifacts under `.orchestrator-state/evidence/<ID>/` and
RETURN their findings. **You write the consolidated `result.json` and the verdict** — never the
lenses, so nothing writes that file in parallel.

**Reset the test-data store once, before each phase, and only you.**

```bash
bash .orchestrator/scripts/reset-test-data.sh "<PHASE>"
```

Run it immediately before VERIFY, before VALIDATE and before every debugger re-run of either —
**except on a docs-only pass** (§6), where the derived lens set is read-only and touches no store.
It delegates to `COMMAND_RESET_TEST_DATA` in `stack.md` and is non-fatal; read its output, because
it reports distinctly when the key is undeclared or still a placeholder, and an unreset store
means the phase's data is whatever the previous phase left. **Lens-agents must never call it.**

**The reset is a floor, not a substitute for scoping.** The executing lenses are serialized, so
one reset leaves a pristine store for the FIRST lens only. Never reset between lenses — you would
erase rows an earlier lens already cited. **Say this when you brief them:** each lens scopes
itself to identifiers it generated and concludes nothing from a global count.

**Consolidation is a CONTRAST, not a transcription.** Before writing any conclusion into
`result.json` or `blueprint/**`, open `.orchestrator-state/evidence/<ID>/` and read what the
lenses actually saved,
starting with the synthesizer's `contradicts_prior_claim[]` — that array is your read-list, not a
substitute for opening the directory. A contradicting finding is **reflected** or **refuted with
its own proof**. A NEGATIVE you are about to write carries a PASS's full burden: command, literal
output, artifact. Both rules in full: `constitution.md` §"Contrast before you conclude" and
§"The burden of proof is symmetric".

### VERIFY — static, against the documents

**Pre-flight first**, before every `verify-fanout` launch including every debugger re-run, right
after the reset — **except on a docs-only pass**, where the code cannot have moved:

```bash
bash .orchestrator/scripts/preflight-check.sh "<PHASE>"     # COMMAND_LINT then COMMAND_BUILD
```

Exit `0` = every requested command passed or does not apply (undeclared or still a placeholder —
it says which, and neither is a failure). `1` = a declared command actually failed. `2` = the
check could not run at all (it must be invoked with `bash`). **Non-zero: repair and re-run the
pre-flight — do NOT launch the fan-out, and do NOT increment `checkpoint.iteration`.**

Three boundaries keep this honest:

- **It is not evidence.** It never enters `phase_runs[]` or `checks[]`, and it does not replace
  `verify-frontend` or `verify-tests`, which still run and still own the verdict.
- **It does not spend an iteration.** `checkpoint.iteration` moves only when you re-launch VERIFY.
- **Stop after the SECOND consecutive failure — do not attempt a third.** Launch VERIFY as normal
  and let the lenses produce the evidence; without this bound a permanently broken environment
  loops forever and never reaches `blocked`. This counter has no field on disk, so a compaction
  resets it: if you resume mid-cycle and cannot tell how many have failed, treat the next as the
  last.

`COMMAND_TEST` is deliberately not in the default set — `verify-tests` runs the suite
unconditionally anyway. Pass it explicitly (`preflight-check.sh "<PHASE>" COMMAND_LINT
COMMAND_BUILD COMMAND_TEST`) only when this project's suite is fast enough for that trade.

**On a REPAIR pass, tell the lenses what the repair touched.** The first VERIFY of a unit is a
baseline: no scope. Every later VERIFY re-checks a specific repair, so compute the changed files:

```bash
git diff --name-only HEAD~1..HEAD    # the delta of THIS pass, against the checkpoint phase-push.sh left
```

**One range, always the delta of this pass** — never the accumulated diff since DEVELOP. With
several checkpoint pushes behind you the two are different lists, and the accumulated one re-scopes
lenses onto work two passes old that is already proven.

**Write the scope to disk, then launch.** `.orchestrator-state/evidence/<ID>/logs/changed-files.txt`,
in this exact shape — the first line is load-bearing:

```text
# iteration: <the checkpoint.iteration this repair belongs to>
# command: git diff --name-only HEAD~1..HEAD
# triage: fail_fast                             <- optional, see §6
# triage: scope_to=verify-tests,verify-design   <- optional, see §6
# triage: full_verify                           <- optional, opts OUT of docs-only derivation (§6)
<literal output, one path per line>
```

Then launch `verify-fanout.js` with `args.changed_files` set to the same list, and record it in
that VERIFY entry of `phase_runs[]` under the key `changed_files`.

- **Both channels, and disk is the one that counts.** `args` has been measured not to reach the
  workflow on some runs, silently. The workflow reads the file when `args` arrives empty, and
  honours it only when the `# iteration:` header matches the unit's current `checkpoint.iteration`
  — a stale scope is worse than none.
- **Check what came back.** `verify-fanout` returns `args_seen`, `scope_source`, `scope_to_source`
  and `fail_fast_source` (each `args` | `disk` | `none`). If you asked for something and got
  `none`, say so in `phase_runs[]` rather than recording a scope it never used.
- **The `# triage:` lines are optional and belong only on a triage pass. Delete them before the
  closing pass** — a leftover one forces `full_set:false`, which the gate rejects as an incomplete
  closing VERIFY. Omitting them is the normal case; the pass then runs all ten lenses, unless the
  list is docs-only and the workflow derives the doc↔code scope itself (§6).
- **Never pass a guessed list.** An incomplete one is worse than none, because ten lenses will
  trust it — and the list is itself a claim that nothing else moved, which carries the same burden
  as any other claim: **a command, its literal output, an artifact.** If you cannot produce those
  three you do not have a scope. No git work tree, no commits, or any doubt about the range: write
  nothing, pass nothing, run the baseline.
- **A spec file in the list is not a small change.** Anything under `blueprint/`, `design/` or
  `.claude/rules/` moves what the code is judged against; the doc↔code lenses may not declare
  themselves out of scope on that pass. A contractual spec edit is a `/reslice`, not an iteration
  — see the three tiers in `constitution.md` §Blueprint write-back.
- **Each lens judges its own relevance; you never decide for it.** The scope is a hint that lets a
  lens whose scope did not move say so in seconds. A lens re-affirming a prior verdict must say so
  and name the scope it checked.

Launch `verify-fanout.js` (fallback: the `verify-*` agents, sequential). It runs and reads tests,
checks conformance against the cited docs and design fidelity, proves the data engine and
pipelines for the detected architecture, reads back/front/db/engine logs and code quality, and
compares the unit against the shell contract (`UI-SHELL-*`) and its `verified`/`accepted`
siblings. It does not drive the live UI.

After consolidating the static verdict, persist into `result.json`:

- `expected_ui_values` — the digest's array **verbatim**, shape `{db_key, permission_context,
  api_field_path, expected_visible_value, ui_field, transform?}`. VALIDATE's loader lifts it from
  disk, so it must never live only in chat context.
- `verify_digest` — the rest of the digest verbatim: `findings[]`, `observed_values`,
  `source_refs[]`, `contradicts_prior_claim[]`, `verdict_by_lens[]`, `artifacts[]`. REVIEW and the
  §5.5 gates confirm or refute against it instead of re-deriving it — never as a substitute for
  their own independent walk.

Then push the VERIFY checkpoint.

### VALIDATE — live, human-like (owned runtimes only)

Launch `validate-live.js` (fallback: the `validate-*` agents per runtime, sequential). Drive the
real product like a human: web (Claude-in-Chrome → Chrome DevTools MCP → Playwright fallback),
Android (emulator + adb/logcat), iOS (simulator + idb/simctl), plus whatever the declared
`Mobile framework` in `stack.md` calls for — and nothing when it needs none. Exercise every state
and flow, inspect logs, confirm no errors.

Assert each observed client value **derives from** `expected_ui_values` (value + transform), not
blind equality; record `ui_value` and `platform_values`. Web and mobile must show the same
canonical value. Never PASS without the live runtime. Backend-only units skip VALIDATE. Then push
the VALIDATE checkpoint.

### REVIEW — one contractual verdict

`Agent(pantalla-reviewer)` consolidates VERIFY + VALIDATE evidence into a single contractual
verdict against `acceptance[]`, `applies[]` and the blueprint source text. It cannot move the unit
to `accepted`. Then push the REVIEW checkpoint.

### 5.5 AUTO-GATES — pipelines/data + production readiness

After REVIEW passes, run BOTH deep gates. They are part of every `/next-pantalla`, not optional
extras; manual re-runs before `/accept` remain possible.

1. **`/verify-pipelines-data-ultracode <ID> --fix`** — a unit with no data/pipeline contract
   self-reports `NOT_APPLICABLE`; record it, that is a pass.
2. **`/production-code-review <ID> --fix`**

**How to run them:** `Read` each `SKILL.md` and execute its protocol yourself in this session with
`$ARGUMENTS = "<ID> --fix"`. Do NOT call the `Skill` tool — both are `disable-model-invocation` to
keep you the single writer, not to make the gates unreachable (`constitution.md` §Authority).
Being unable to invoke them as slash commands is never a reason to close a unit without their
checks. **Model:** spawn every subagent these gates use with `model: 'sonnet'`; you stay on the
session model.

**ORDER — the gates go LAST**, after the FINAL VERIFY/VALIDATE, not merely after the first REVIEW.
A gate report is a reading of the evidence at a moment in time; a later phase overwrites those
files and leaves the report citing numbers that no longer exist. The invariant: *the last thing
that touched the evidence must be the thing the gate read.*

**Run BOTH, every time — on the first pass and on every re-run that touched code**, whatever
domain the repair looks like it touched. Routing by domain puts a judgement call on the hot path,
and guessing wrong skips the gate that would have caught the defect.

**"Touched code" is the one condition, and it is decidable.** A pass whose changed files are all
documentation, blueprint, report or evidence does not re-run either gate — there is no new
implementation to judge (§6, *Docs-only re-run*).

**A finding is not automatically a repair.** Each gate classifies what it raises:

- **blocking** → `checks[]` / `failures[]`. It keeps the unit un-`verified` and is repaired; the
  repair is a debugger pass with everything that follows.
- **non-blocking** → `result.json.advisory_findings[]` as `{id, severity, source, detail, refs,
  status:"open"}`. It does NOT trigger a repair pass. It is recorded and carried; `/accept --auto`
  weighs it against the ceiling in `autonomy.md`. A finding recorded as `accepted_as_debt` may not
  also sit in `failures[]` — blocking or waived, never both.

**Cite identifiers that do not drift.** Anchor every claim in both reports to something stable —
check ids (`CHK-<ID>-...`), rule ids (`DATA-004`, `ENG-002`), artifact paths, content hashes, exit
codes. Never to a count: counts age the moment anything is repaired.

Consequences:

- Their required checks merge into `result.json` and must pass; a failing gate check keeps the
  unit un-`verified`.
- **If a gate applied a fix, the evidence it touched is stale** — treat it as a debugger pass
  (§6) **in full, the diff adversary included**: increment `checkpoint.iteration`, re-run VERIFY (with `args.changed_files`), VALIDATE when
  the fix changed runtime behaviour, and REVIEW when it touched implementation or test code rather
  than only a report — `pantalla-reviewer` judged the pre-fix evidence. In practice this fires on
  every gate-applied fix: both gates repair implementation/test code by design. Then re-run BOTH
  gates, per the ORDER rule.
- Push a checkpoint after each gate: `phase-push.sh "GATE_DATA" "<ID>"` and
  `phase-push.sh "GATE_PROD" "<ID>"`.

## 6. Debugger loop (DEVELOP repairs; re-run downstream)

DEVELOP is also the debugger: every phase result feeds you, and on failure you repair in-thread
and re-run the affected phases. **Maximum 3 iterations**, enforced: increment
`checkpoint.iteration` in `features.json` and save it on each repair pass; the STATE GATE rejects `iteration > 3`, so past the
cap the only honest moves are `blocked` — with reason and reproduction — or a human decision.

### What a repair pass IS

A round exists to change PRODUCT, and the product it changes ships complete in that same pass. A
repair pass is, in one pass and in this order:

1. **the product change** — the code or test that fixes the finding;
2. **its propagation** — every blueprint / `shell.md` / `stack.md` fact that change implies, swept
   over the WHOLE surface the repair touched, not the one line a lens named;
3. **its proof** — the phases the change invalidated, re-run.

None of the three is a separate round. Finish all three or the repair is not finished. The rule
and the measurement behind it: `constitution.md` §"A round exists to change PRODUCT".

Two consequences:

- A finding that needs no product change gets **no round**. It is recorded in
  `advisory_findings[]` (§5.5) or folded into the next real repair. Never its own.
- A repaired finding is not closed when the code compiles, but when propagation and proof land in
  the same pass. **If this round's finding is about last round's repair, last round did not
  finish.**

### The class scan — before you write the fix

**On every repair pass, for EVERY finding this pass will repair, launched together before step 1 of
any of them.** A finding is scoped to the location the lens happened to cite, not to every location
sharing its cause — and fixing only the cited one is exactly how "something always turns up next
round" happens, when it is the same something repeatedly (`constitution.md`, "A finding is an
INSTANCE of a class until scanned").

**One call per finding, in parallel, before any repair is written.** A pass repairing N findings
launches N `Agent(repair-class-scan)` calls, each carrying THAT finding as returned (lens,
`acceptance_ref`, file, line, detail), this unit's `plan.md` acceptance map, and this pass's
`changed-files.txt`. Never one call for the whole pass, and never one call fed several findings —
the agent's contract is ONE finding and its return has a single `root_cause`.

**This is a LAUNCH order, never an APPLY order**, the same distinction the repair order below draws
for the ten lenses. Launch all N at once against the same starting state, then apply each scan's
members in the repair order below, **re-running that member's `matches_check` immediately before you
edit it**. A member that an earlier repair in this same pass already resolved fails its own check
and is a no-op, not an error — and two findings that genuinely share a cause simply come back with
matching answers, each one confirmed against real files instead of guessed from the wording of two
lens reports.

Each call returns:

```yaml
class_size: <n>          # 1 means no class — a complete answer, and the common one
root_cause: <the shared CAUSE in one sentence, never the shared symptom>
members:      [{file, line, matches_check}]   # in-scope, each with a re-runnable check
out_of_scope: [{file, matches_check, reason}] # real, but outside this unit's surface
```

- **Every in-scope member is fixed in THIS pass**, as part of step 1. Not a second round — the scan
  is the discovery half of the repair you were already about to write.
- **Out-of-scope members are never touched by this unit's diff.** Emit each as a
  `SCR-FIX-CLASS-<ID>-*` unit in `blueprint/SCREENS.md` (`conventions.md`), the same exit the cross
  gates use, or record it in `## Learned for the blueprint`. Silently widening the active unit is
  what the boundary exists to prevent. The STATE GATE now WARNS when
  `changed-files.txt` holds a code or behaviour file that this unit's `plan.md` never declares
  (propagation targets exempt) — advisory, never blocking, because the *files to touch* column is
  prose written before the code existed. Read it as the question it asks: **is this file part of
  this unit, or part of the next one?**
- **A class claim needs proof like any other**: one sentence of shared CAUSE, and a literal
  re-runnable `matches_check` per member. A resemblance is not a class, and a wrongly grouped member
  is a file you were about to edit for no reason.
- Its remit **includes `blueprint/**`**, not only code — the case that motivated it (a shared
  convention harvested piece by piece) is documentary.
- Not evidence, spends no iteration, blocks nothing. **One call per finding, never one for the whole
  pass** — and never re-run for the same finding, never re-invoked on its own fix. The ten lenses
  still prove every file this pass touches. **The scan changes what the repair sweeps, never what the
  evidence proves.**
- **Nothing upstream groups the findings for you, and that is deliberate.** `verify-synthesizer`
  holds every finding of a pass at once, so it looks like the natural place to ask which of them
  share a cause — but its charter is *"Flag, don't adjudicate"* and *"Only relay what the lenses
  found"*, and declaring two findings one class is adjudicating. It would have to group them by how
  they READ, and a group proposed from wording arrives with no `matches_check` while looking already
  settled — which is precisely the invitation to skip this scan. N scans in parallel answer the same
  question from the other end: shared cause emerges as two grounded answers that agree, not as one
  ungrounded guess. `DEC-ORCH-012`.

### The diff adversary — between the repair and the proof

**On every repair pass, never on the unit's first DEVELOP.** Once the repair is written (steps 1
and 2) and the pre-flight passes, and BEFORE you launch `verify-fanout`, write the repair's diff and
launch `.claude/workflows/diff-adversary.js` with `args.screen_id`:

```bash
{ echo "# iteration: <checkpoint.iteration>"; git diff HEAD~1..HEAD; } \
  > .orchestrator-state/evidence/<ID>/logs/repair-diff.patch
```

**The delta of THIS pass, never the accumulated diff** — the same range `changed-files.txt` uses,
and for the same reason: the adversary judges what this repair did, and an accumulated diff makes it
re-judge work two passes old. The file carries exactly ONE header line, `# iteration:` — not the
`# command:`/`# triage:` lines, which would corrupt a patch. It is rewritten on every repair pass;
the header is what tells a stale one from a fresh one.

Four read-only agents ask four fixed questions about that diff, in parallel:

| Agent | Its one question |
| --- | --- |
| `diff-adversary-regression` | What worked before this diff and does not now, or changed without being declared? |
| `diff-adversary-incomplete` | What did this diff start and not finish — declared but not wired, written but not propagated? |
| `diff-adversary-unreachable` | What did this diff make unreachable, dead or no longer executed — **including a check that used to run**? |
| `diff-adversary-edge` | Which edge case OF THIS DIFF would predictably cost a future iteration? |

**Why the third one is the reason this step exists.** Every VERIFY lens asks whether something IS
THERE. None can ask whether something STOPPED BEING REACHABLE. A repair that makes an audited
denial unreachable compiles, passes the suite and satisfies all ten lenses — and ships. That is the
one defect class the fan-out is structurally blind to, and one question, asked in those words,
catches it.

**Its charter, and it is what keeps this from becoming another round generator:**

- **It is not evidence.** It never enters `phase_runs[]`, `checks[]` or `advisory_findings[]`. It
  puts no verdict on disk and it never blocks a unit. The ten lenses still run and still own the
  verdict.
- **It does not spend an iteration.** This is the same repair pass, not a new one.
- **A finding is folded into THIS pass's product change, before you move to proof.** It is never a
  reason to open a round, and never a reason to re-invoke the adversary to check its own fix — that
  is what the `verify-fanout` immediately after it is for. **Run it at most once per repair pass.**
  Fold first, then finish the pass in this order: **if the fold touched code, re-run the pre-flight**
  (it is new code, and the whole point of the pre-flight is not spending a fan-out to learn it does
  not compile) → **then** compute `changed-files.txt`, so the list the ten lenses trust includes the
  fold → **then** launch `verify-fanout`. Computing the file list before the fold hands the lenses an
  incomplete list, which this skill forbids everywhere else.
- **The bar is on the finding, not on the count.** `nothing_found` is a complete and correct
  answer, and so is a real finding — neither is the target, and no rate is expected of them. What
  a finding must clear is the bar: concrete, falsifiable, caused by THIS diff. Style, naming,
  preference, uninvited test coverage and alternative designs never clear it and are never
  reported. Padding to look useful and suppressing to look disciplined are the same defect: both
  answer a question nobody asked instead of the one that was given.
- **Skip it on a docs-only pass** (below): all four questions are about the shape of code, and that
  diff contains none.

If an adversary returns nothing twice, the workflow says so in `failed_adversaries[]`. That is a
question that went unasked, not a clean answer — proceed to VERIFY, because this step never blocks
a unit, but do not read the pass as adversary-clean.

### Repair order when one VERIFY returns several failures

```text
frontend/build → tests → engine → pipeline → logs → quality → conformance · design · coherence · blueprint-drift
```

Fix what invalidates the rest first: a conformance finding about code that does not compile is a
finding about code that is going to change anyway. The four documentary lenses come last because
they compare code against documents, so their findings are stable only once the code is. **This is
a REPAIR order, never a launch order** — the fan-out still runs all 10 lenses. `advisory_findings[]`
are not in it at all.

They come last **within the same pass**, never in a later one. Before applying a documentary fix
that waited, **re-read the file and location the lens cited**: the code repairs that ran ahead of
it may have made the finding moot or changed what the right documentation now is.

### Re-running

Every re-run in this loop is a REPAIR pass: **pass `args.changed_files`** (§5). Only the first
VERIFY of the unit, and any pass where you cannot determine the changed files, run as a baseline.

- **VERIFY fails** → repair → re-run VERIFY; when it passes, continue to VALIDATE.
- **VALIDATE fails** → repair → re-run VERIFY **and** VALIDATE: a code fix can invalidate the
  static evidence.
- **REVIEW fails** → repair → re-run VERIFY and VALIDATE, **then** REVIEW again. The reviewer
  judges consolidated evidence, so leaving the old artifacts in place would have it re-reading
  files that describe the code before the fix. This branch consumes an iteration like any other;
  past the cap the unit goes `blocked` with the reviewer's exact objection as `blocked_reason`.
- Each repair marks the touched-layer evidence **stale**: rewrite `result.json` from the fresh
  runs, and re-run only the affected phases.
- A repair is a DEVELOP pass: push a `DEVELOP` checkpoint, then one per re-run phase.

If the same failure repeats without progress across the cap, mark `blocked` with a concrete
reason, reproduction and next action.

### Docs-only re-run — DERIVED, never evidence

When every path in `changed-files.txt` is documentation, blueprint, report or evidence — no
implementation and no test file — `verify-fanout.js` scopes ITSELF to the four doc↔code lenses
(`verify-conformance`, `verify-design`, `verify-coherence`, `verify-blueprint-drift`) and does not
launch the other six. You neither ask for it nor can forget it.

It fires only on a repair pass with a fresh scope on disk: never on a baseline, never when you
passed an explicit `scope_to` (yours wins), and never on a list containing one `.py`/`.js`/`.sh`/
`.css`/`.sql`/`.json` outside `.orchestrator-state/` — **one code file makes the whole pass a full
pass.** `blueprint/**.md` IS derived: a spec edit is the most consequential change here, and these
four lenses are exactly the ones that judge code against the spec.

**A docs-only pass is not a debugger round and costs nothing a round costs.** No reset, no
pre-flight, no VALIDATE, no REVIEW, neither §5.5 gate, **no increment to `checkpoint.iteration`
and none to `total_repair_passes`**. The cap of 3 bounds repairs of PRODUCT. The one thing that
does happen is the checkpoint push: the edit is real work.

What you owe in return: the workflow returns `derived_scope:"docs_only"`, `full_set:false` and
`carried_forward_lenses[]`. Record a NON-CLOSING entry that carries **`derived_scope:"docs_only"`
verbatim** and whose `carried_forward[]` gives each of those six a `from_iteration` citing the last
COMPLETE VERIFY pass. The workflow does not fill that number in — it cannot see `phase_runs[]`, and
a guessed citation is exactly what the gate rejects. **The CLOSING VERIFY still runs all 10
natively.**

**At most TWO docs-only passes back to back.** This is the one re-VERIFY edge that spends neither
counter, so nothing else bounds it: a lens asks for a blueprint write, the write is docs-only, the
docs-only pass re-runs the same four lenses, and one of them can ask for the next write. After two
in a row the loop is not converging on its own — the third pass runs FULL (`# triage: full_verify`)
and costs an iteration like any repair, or the unit goes `blocked`. `validate-state.py` counts the
streak from the `derived_scope` you record, which is why recording it is not optional.

**Decide up front whether this is the last pass.** If no further code repair is expected, write
`# triage: full_verify` from the start and pay 10 once; deriving to 4 and then discovering you
must close costs 14. Do not reach for it merely because you are unsure — an intermediate docs-only
pass is the normal case and 4 is its right price.

### Fail-fast triage re-run — optional, never evidence

When you are re-running VERIFY only to find out whether a repair landed, set `args.fail_fast =
true` **and** write `# triage: fail_fast` into the header, for the same reason the file list goes
to disk. The declared lens set is never shrunk, but the SERIALIZED chain stops launching the next
lens as soon as one reports `verdict: fail`; the parallel documentary half is unaffected.
Detection reads the `verdict:` line the agents already declare, so it fires only on an explicit
fail — a missing or ambiguous verdict never stops the chain.

The workflow returns `full_set:false`, `fail_fast_stopped_at` and `fail_fast_skipped[]`.
**`fail_fast_skipped` is NOT `failed_lenses`**: those lenses were never launched, so do not retry
them and do not block the unit for them.

Such a pass may be written into `phase_runs[]` as a NON-CLOSING VERIFY entry **only when its own
verdict is `fail`** — it exists to prove a repair did not work, never to claim one did. Set
`fail_fast:true`, `verdict:"fail"` and `iteration:<current>`, and cite every skipped lens in
`carried_forward[]` as below. `validate-state.py` rejects a `fail_fast:true` entry that is the
closing one or is not `verdict:"fail"`. Never use it on a first or closing pass.

### Scoped triage re-run — optional, never evidence

Pass `args.scope_to = [<lens names>]` — and equally write `# triage: scope_to=<names>` into the
header — to re-run just the lenses whose scope intersects the change.

A scoped pass may be recorded as a NON-CLOSING VERIFY entry as long as it is honest about what it
did not run:

```text
{phase:"VERIFY", workflow:"verify-fanout", mode:"workflow",
 iteration:<this unit's current checkpoint.iteration>,
 lenses:[<the lenses that ACTUALLY ran this pass>],
 carried_forward:[{lens:"<name>", from_iteration:<the iteration of the last COMPLETE
                   VERIFY entry already in phase_runs[]>} ...for every lens not run]}
```

`validate-state.py` checks this mechanically: for every VERIFY entry except the last, `lenses[]` ∪
`carried_forward[*].lens` must equal the full 10-lens set, and every `from_iteration` must match a
genuinely complete earlier entry — full native `lenses[]`, no `carried_forward`, no `fail_fast`.
A stale or invented citation fails the gate.

**The LAST VERIFY entry recorded is the CLOSING one and is exempt from none of it**: the full
10-lens set natively, nothing carried forward. If you cannot honestly fill `carried_forward`, do
not record the pass at all — that is still legal.

## 7. Close

Write BOTH fields in the same `features.json` save — `status:"verified"` **and** `passes:true`.
`passes` mirrors the status, it is not an extra judgement: the gate rejects `verified` with
`passes:false`, and `/accept` requires `passes:true`. Do this only when:

- every required check passed;
- `result.json.verdict == "PASS"` and `failures` is empty;
- required artifacts exist and are non-empty — no 0-byte or placeholder files;
- data checks are real or explicitly not applicable;
- every required `data_engine` assertion carries the observed literal value at each layer
  (`db_value`/`api_value`/`ui_value`, plus `platform_values` when multi-client) and they are
  equal, proving canonical store → API/read model → client;
- `result.json` includes a `source_manifest` — path + sha256 of the unit's implementation files —
  so stale evidence is detectable after any later fix;
- `phase_runs[]` proves the full cycle with complete lens sets (RESEARCH, EXPLORE, DEVELOP,
  VERIFY, VALIDATE when the unit owns a runtime, REVIEW);
- both §5.5 gate checks are in `checks[]` by id with `passed:true` —
  `CHK-<ID>-PRODUCTION-CODE-REVIEW` (always) and `CHK-<ID>-PIPELINES-DATA-ULTRACODE` (or, with no
  data engine, present as `required:false, passed:true, notes:"not applicable"`). Their absence
  means a gate never ran, and `/accept` looks for them by id;
- `python3 .orchestrator/scripts/validate-state.py` passes.

**Harvest — do not lose what this screen learned.** Before closing, write back everything
blueprint-relevant this unit produced. **Start from `plan.md`'s `## Learned for the blueprint`**,
then add whatever VERIFY/VALIDATE surfaced and whatever `verify-blueprint-drift` reported as
*unnoticed*. It happens here, and not earlier, because only now is the code it describes proven.
Routing: anything SHARED — a reusable component, a route pattern, an API convention, a
shell/navigation piece — into `blueprint/logic/shell.md`; any other discovery into its
`logic/*.md` or `stack.md`, per the write-back discipline. Then run `lint-blueprint.py`. The next
screen's RESEARCH and `verify-coherence` read the contract, not your memory.

Then update the feature entry — `status:"verified"`, `passes:true`, and clear its `checkpoint`,
the build is no longer in flight. **Leave `total_repair_passes` untouched**: it is a LIFETIME
counter, written only by the 4 REOPEN routes, and it must survive every close. Append `VERIFIED`,
run `python3 .orchestrator/scripts/validate-state.py --emit-status` (refreshes `status.json` and
`evidence/index.json` for external readers) and `bash .orchestrator/scripts/validate-structure.sh`,
and stop with:

```text
Evidence: .orchestrator-state/evidence/<ID>/result.json
Auto-gates already run (Sonnet): pipelines/data + production review — see evidence/<ID>/reports/
Recommended next: /review-pantalla <ID> if the UI deserves an extra live-parity pass, then /accept <ID>.
When an /accept completes a journey (JOUR-*), /verify-app runs automatically on it.
```

Never start the next unit automatically. The one sanctioned exception is `/build-loop`, an outer
loop that re-invokes this procedure with an explicit ID per iteration and still never accepts.
