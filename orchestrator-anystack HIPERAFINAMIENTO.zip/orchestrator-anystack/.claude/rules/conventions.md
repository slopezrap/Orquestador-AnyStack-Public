# Orchestrator conventions

## ID prefixes

- Business rules: `BR-*`
- Screens/units/foundations: `SCR-*`
  - `SCR-FOUNDATION-*` — groundwork a screen needs before it can exist; emitted by `/arch-review` from an architecture blocker.
  - `SCR-FIX-CLASS-*` — repair unit emitted when `repair-class-scan` finds the root cause of a finding recurring OUTSIDE the active unit's declared surface. Carries `remediates: [<the unit whose finding triggered the scan>]`. Same rules as the two below: born `todo`, earns the full pipeline, never alters the status of what it repairs. It exists so that closing a class inside the active unit never becomes a licence to edit outside it.
  - `SCR-FIX-VERIFY-APP-*` / `SCR-FIX-AUDIT-*` — repair units emitted by the two cross gates when they find a concrete defect. They carry `remediates: [<unit ids that drifted>]` alongside the usual `after[]`/`applies[]`. A repair unit is an ordinary unit in every other respect: it is born `todo`, earns the full pipeline and the full evidence standard, and never alters the status of what it repairs.
- Domain: `DOM-*`
- Application: `APP-*`
- Core: `CORE-*`
- Journeys: `JOUR-*`
- Permissions: `PERM-*`
- State: `ST-*`
- Errors: `ERR-*`
- Integrations: `INT-*`
- UI/UX: `UI-*`
- Shared shell / cross-screen contract: `UI-SHELL-*` (part of the `UI-*` family; lives in `blueprint/logic/shell.md` — shell/layout, navigation map, component inventory, route convention, shared internal API)
- Data: `DATA-*`
- Use cases: `UC-*`
- Engines: `ENG-*` (the application's engines as contracted modules — `blueprint/logic/engine.md`; polymorphic by `kind`: `rules_engine`, `compute_engine`, `agent_graph`)
- Pipelines: `PIPE-*` (what feeds the engines and the canonical store with REAL data — `blueprint/logic/pipeline.md`)
- Decisions: `DEC-*` (product decisions taken AFTER the blueprint was written — `blueprint/DECISIONS.md`, append-only, carries the *why*). `decided_by` is a person or `auto:<rule>`; an `auto:` entry must also carry `rejected_alternative` and `trip_wire`.
- Autonomy rules: `AUTO-*` (pre-answered product defaults in `.claude/rules/autonomy.md` — governance, not a blueprint layer; never cited from `applies[]`/`after[]`)

## Status lifecycle

```text
todo -> ready -> building -> verified -> accepted
                 |                |
                 +-> blocked      +-> building   (reopened by a failing/repairing review gate)

any non-accepted generated unit -> deprecated   (during /reslice, when removed or replaced)
```

The `deprecated` row is not decoration: it was missing here while `constitution.md` documented it, so this copy of the diagram was already a strictly smaller state machine than the real one — a reader who opened `conventions.md` looking for "Status lifecycle" learned five states where there are six. That is what a duplicated diagram does; the authority stays in `constitution.md` §Minimal lifecycle, and this one exists only to sit beside the ID conventions.

Only `/accept <ID>` moves `verified` to `accepted`, and acceptance walks the `after[]` order: a dependency must be `accepted` before its dependents can be. Note the deliberate asymmetry with building — a unit becomes `ready` once its dependencies are merely `verified`, so a batch run can build ahead of the human without ever promoting anything past them.

## Runtime state

- `.orchestrator-state/features.json` is the key runtime file.
- `.orchestrator-state/spec.md` is generated consolidated context.
- `.orchestrator-state/progress.md` is append-only except explicit reset.
- Evidence for a unit lives at `.orchestrator-state/evidence/<SCR-ID>/result.json`.
- `.orchestrator/` is definition, not live state.

Read contract for external surfaces (dashboards, CI, monitor screens): `.orchestrator-state/status.json` (`orchestrator.status.v1` — counts, building unit + checkpoint, verified awaiting accept, next ready, `promotable_todo`, blocked, one light row per screen) and `.orchestrator-state/evidence/index.json` (`orchestrator.evidence-index.v1` — verdict, phases run and artifact list per PASS unit, without opening each result.json). Both are derived projections written atomically by `validate-state.py --emit-status` after a successful gate run (via `/status`, `/next-pantalla` close and `/reslice`); they are never hand-edited, never a source of truth, and consumers should tolerate their absence and check `schema_version`.

`status.json.promotable_todo` lists `todo` units whose every dependency is already built — promotable now, not yet promoted. Promotion is lazy by design, so a non-empty list is normal while work is in flight; it matters when it is non-empty AND `next_ready` is null, because that is the state a batch runner reads as "nothing left to do" when in fact nothing was promoted. The gate warns (never fails) in exactly that case.

`.orchestrator-state/batch.json` (`orchestrator.batch.v1`, schema at `.orchestrator/schemas/batch.schema.json`, worked example at `.orchestrator/examples/batch.example.json`) is different in kind from those two: it is not a projection of the plan but `/build-loop`'s OWN durable state — the cap it was given, the units it has built, the ones that blocked, why it stopped, and under `--autonomous` its budget, telemetry and per-round log. `/build-loop` writes it directly; `--emit-status` never touches it. Its purpose is that `features.json` records what each UNIT reached and nothing recorded what the BATCH had done, so a compacted loop could not tell how far it had got. Absent when no batch has ever run.

## Traceability

Every generated feature should preserve enough source context for agents: ID, slug, title, kind, platforms, order, dependencies, source refs, `applies[]`, acceptance criteria, verification plan and route/deep link when applicable.

Agents must not treat an ID-only reference as sufficient. If source description is missing or ambiguous, `/init-build` asks CLARIFY; `/next-pantalla` thinks first and asks a precise question when genuinely stuck, and blocks rather than guesses.

## Data engine convention

For any feature that cites `DATA-*` or displays/mutates product data, `.orchestrator-state/features.json` should include `data_engine`. The orchestrator is **AnyStack**: `canonical_store.kind`/`source_of_truth` is whatever the blueprint declares as the system of record — `database`, `document_db`, `event_store` (event sourcing; product state is a projection/read model rebuilt from events), `state_store`/`checkpointer` (stateful/LangGraph graph state), `ledger`, `external_system` (`INT-*`), `file_store`, ... — but it must never be a client/frontend layer. The validator enforces the invariants, not a specific technology.

```json
{
  "engine_refs": ["DATA-001", "APP-001", "UC-001", "DOM-001", "PERM-001"],
  "canonical_store": {
    "kind": "database | event_store | state_store | ledger | external_system | file_store",
    "source_of_truth": "the declared system of record (never a client)",
    "resources": ["<table | collection | stream | read-model | checkpoint>"]
  },
  "pipeline": {
    "writes_to_canonical_store": true,
    "read_path": ["<canonical store>", "service/api/read-model", "frontend/mobile/client"],
    "generation": {
      "required": true,
      "method": "migration|seed|backfill|job|api_write|user_action|event_replay|state_transition",
      "no_frontend_fixtures": true
    }
  },
  "single_value_contract": [
    {
      "field": "<business-field>",
      "db_source": "<store.field | event/projection | state key>",
      "api_field": "<response.path | read-model field>",
      "ui_field": "<selector-or-widget>",
      "invariant": "same value for the same user/tenant/permission context"
    }
  ]
}
```

Use `writes_to_canonical_store` (legacy alias `writes_to_database`) and a `read_path` that flows source -> transport/read-model -> client. Source mapping accepts `db_source`/`source`/`store_source`; client mapping accepts `ui_field`/`client_field`/`visible_field`.

Evidence must include `data_engine_assertions[]` in `result.json` that carry the **observed literal value at each layer** so equality is falsifiable, not self-declared:

```json
{
  "id": "DE-<ID>-001",
  "engine_refs": ["DATA-001", "APP-001", "UC-001"],
  "canonical_store": "the declared system of record",
  "db_value": "<observed canonical value>",
  "api_value": "<observed transport/read-model value>",
  "ui_value": "<observed client value>",
  "platform_values": { "web": "<value>", "android": "<value>", "ios": "<value>" },
  "db_evidence": "<path>", "api_evidence": "<path>", "ui_evidence": "<path>",
  "same_value": true
}
```

The validator recomputes equality from `db_value`/`api_value`/`ui_value` (aliases `source_value`/`transport_value`/`client_value` accepted) plus any `platform_values`; `same_value:true` is rejected unless every observed literal is present and equal. This proves:

```text
engine_ref -> canonical persisted value -> API/service/read-model value -> client visible value
```

If data is not applicable, use `data_engine.not_applicable_reason` (only when the unit cites no `DATA-*` and declares no `verify.data_checks[]`) and keep `verify.data_checks[]` empty or not required.


## Verification surface

Choose verification by the selected feature's `kind`, `platforms` and `verify` contract.

- `web` UI: real browser verification with Chrome/DevTools tooling, UI states, console/network, backend logs and data checks.
- `android` or `ios` mobile UI: real emulator/simulator/device verification with the OS tooling (adb/logcat, idb/simctl) plus whatever the declared `Mobile framework` in `.claude/rules/stack.md` provides — Dart/Flutter tooling for a Flutter project, the equivalent for a native or cross-platform one, none where none applies; device logs, screenshots and route-flow checks.
- backend/API/service: real endpoint/service call, response contract, durable side effect and clean logs.
- migration/data: migrate to head, inspect schema/data, prove constraints/indexes/idempotence when applicable.
- worker/queue/pipeline: run the worker or job with real/provided input and observe durable output and logs.
- integration/provider: probe the adapter boundary or document a concrete not-applicable/degraded reason.
- core/domain/usecase: run real calculations/use cases and boundary/error tests.
- permission/state/error: prove allowed/denied gates, legal/illegal transitions and structured error behavior.

A journey reference alone does not create a UI surface. Do not force browser/mobile MCP for a backend-only journey dependency.

## Evidence names

- web: `success.png`, `error.png`, `console.txt`, `network.txt`, `data-check.txt`, `trace.json`, `lighthouse.json`.
- mobile: `android-success.png`, `ios-success.png`, `logcat.txt`, `ios-logs.txt`, `mobile-runtime.txt` (or the framework's own name, e.g. `flutter-runtime.txt`), `data-check.txt`, `flow-recording.mp4`.
- backend/data: `test-output.txt`, `migration.txt`, `db-query.txt`, `api-response.json`, `server-log.txt`, `worker-log.txt`.
- engine/pipeline (live): `logs/pipeline-run.txt`, `logs/backfill.txt`, `db/pipeline-output-check.txt`, `traces/engine-decision.json`, `db/engine-output-check.txt`, `reports/engine-eval.md` (agent_graph golden-set eval).
- cross-architecture gate: `.orchestrator-state/evidence/APP-INTEGRATION/reports/audit-motores.md`.
- t=0 architecture gate: `.orchestrator-state/evidence/APP-INTEGRATION/reports/arch-review.md` (machine record: `features.json.meta.architecture_review`, sealed to the report via `report_sha256`; validated by the gate whenever present, required at birth by `validate-state.py --init-gate`).
- t=0 discovery gate: `.orchestrator-state/evidence/APP-INTEGRATION/reports/discovery.md` (machine record: `features.json.meta.discovery` — checklist version, one disposition per item, counts summing to `items_total`, sealed via `report_sha256`; validated whenever present, required at birth by `validate-state.py --init-gate`).
- plan: `plan.md` — EXPLORE's own deliverable, written before any code exists (acceptance map, vertical order, the unit's declared consumer) and closed at the end of DEVELOP with a `## Delivery` line per criterion. Cited from `result.json.phase_runs[EXPLORE].plan`; `validate-state.py` requires it on a PASS and checks it is a real, non-empty file (warning, not failure, on an already-`accepted` unit — reopening one is forbidden, so there would be no legal way to produce it).
- review reports: `reports/review-pantalla.md`, `reports/pipelines-data-ultracode.md`, `reports/production-code-review.md`.
- cross-screen gate: `.orchestrator-state/evidence/APP-INTEGRATION/reports/verify-app.md` (+ its screenshots/recordings under the same APP-INTEGRATION dir).
- review logs/data: `logs/pipelines-data-backend.txt`, `db/pipelines-data-check.txt`, `traces/pipelines-data-trace.json`.

## Result evidence

`result.json` must connect checks to acceptance criteria and artifacts. A `PASS` requires every required check passed, failures are empty, artifacts exist, visible/API/DB data match when data checks are declared, and logs show no new relevant runtime errors.

A `BLOCKED` result must include missing input/setup, exact reproduction, attempted checks and the next required action.

`orchestrator-flow` writes the consolidated `result.json`; lens-agents only save their own evidence artifacts and return findings (no parallel writes to `result.json`).

Review skills may add required checks to `result.json`. If any added required check fails on a unit still `building`, keep `passes:false` and let the conductor repair it. If it fails on a unit already `verified`, do NOT write `verified` + `passes:false` — that state is rejected by the gate; reopen the unit to `building` (see the reopen path in `constitution.md`) and hand it back to `/next-pantalla <ID>`. Review skills must not move a screen to `accepted`.

## Manual review skills

- `/review-pantalla <ID|name> [--fix|--report-only]`: checks live UI/design/control parity for one screen and writes `reports/review-pantalla.md`.
- `/verify-pipelines-data-ultracode <ID|name> [--fix|--report-only]`: checks pipelines, workers, migrations, API/DB consistency and screen-visible data using Claude Code Ultracode/dynamic workflows when available; writes `reports/pipelines-data-ultracode.md`.
- `/production-code-review <ID|path|all> [--fix|--report-only]`: checks production readiness, comments, DRY/YAGNI/KISS, placeholders, errors and tests; writes `reports/production-code-review.md`.
- `/verify-app [JOUR-ID|all]`: cross-screen gate — drives every journey whose screens are all `accepted`/`verified` end-to-end in the real runtime (navigation seams per `UI-SHELL-*`, same canonical value on every screen that shows it, shell coherence); writes `.orchestrator-state/evidence/APP-INTEGRATION/reports/verify-app.md` and emits a `SCR-FIX-VERIFY-APP-*` unit per concrete defect. Cross-screen by design (active-unit discipline does not scope it), but it never changes an EXISTING unit's status.
- `/fix "<prompt>" [--report-only]`: prompt-driven maintenance — maps a free-form bug/improvement request to its owning unit(s), repairs the code and re-proves the evidence (full VERIFY/VALIDATE/REVIEW lens sets, refreshed `source_manifest`); writes `reports/fix-<slug>.md` and the check `CHK-<ID>-FIX-<slug>`. Reopens `verified` units via the reopen path; repairs `accepted` units in place (status unchanged); routes product changes through blueprint write-back + `/reslice`. Never accepts.

`/verify-pipelines-data-ultracode` and `/production-code-review` run AUTOMATICALLY inside `/next-pantalla` after REVIEW (with `--fix`, sweeps on Sonnet); `/verify-app` launches automatically from `/accept` when it completes a journey. All remain re-runnable manually. They must respect active-unit discipline (except `/verify-app`, which is cross-screen by design) and must not move `accepted` units automatically.

## Case sensitivity

Treat paths, file names, agent names, MCP server names and tool names as case-sensitive. Use exact names such as `.orchestrator-state`, `.orchestrator`, `CLAUDE.md`, `SKILL.md`, `features.json`, `result.json` and the declared agent names.
