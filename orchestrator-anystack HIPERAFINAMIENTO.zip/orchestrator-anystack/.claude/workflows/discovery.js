export const meta = {
  name: 'discovery',
  description: 'DISCOVERY gate at time zero (inside /init-build, after the preflight lint and BEFORE COMPILE). Fan out 6 discovery-* lens-agents in parallel over the universal intake checklist (.orchestrator/templates/discovery-checklist.md) — product, data, architecture, stack, infra, ux — each returning one disposition per checklist item (answered/propose_fill/ask/n-a). A read-only synthesis reducer collapses them into ONE digest (per-item table, missing_ids completeness proof, deduped question round, write_plan) for orchestrator-flow, which asks the human ONE batched round and writes every fill/answer into blueprint/**, stack.md and DECISIONS.md. discovery-* owns the UNASKED, research-* owns the ABSENCE, arch-* owns the ERROR. An underspecified or empty blueprint is the NORMAL input here — this gate exists to interrogate it, so unlike arch-review it never refuses to run over silence.',
  phases: [
    { title: 'Lenses', detail: 'discovery-* agents in parallel (product/data/architecture/stack/infra/ux), one disposition per checklist item' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (items, missing_ids, question round, write_plan)' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`discovery: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: args is only an optional hint; correctness comes from the checklist and
// blueprint/ on disk. This runs at TIME ZERO before COMPILE: features.json does not exist yet.
const hint = ARGS.hint ? String(ARGS.hint) : null
const root = ARGS.root ? String(ARGS.root) : '.'
const CHECKLIST = '.orchestrator/templates/discovery-checklist.md'

const LENSES = [
  'discovery-product', 'discovery-data', 'discovery-architecture',
  'discovery-stack', 'discovery-infra', 'discovery-ux',
]

phase('Lenses')
// One definition, used by the first pass AND the retry below: a retry that rebuilt the
// prompt could quietly ask a different question than the pass it is repeating.
const runLens = a => agent(
  `DISCOVERY lens ${a} at TIME ZERO (inside /init-build, before COMPILE — no features.json exists yet). Repo root: ${root}. Read YOUR section of ${CHECKLIST} and walk it per your spec: for EVERY item in your section return exactly one disposition — answered (cite file+ID or ORIGINAL/DEC quote; never re-ask what the human already wrote), propose_fill (exact text + target from the checklist routing), ask (one precise question, 2-4 options, ALWAYS a recommended option, target file), or n/a (concrete reason; [if applies] items still get a row). An empty or underspecified blueprint is the NORMAL input — silence on a genuine product decision is ask, never a finding and never a guess. You REPORT: you do not write, you do not decide, and your output never enters phase_runs[] or any result.json.${hint ? `\n\nConductor hint (context only, disk wins): ${hint}` : ''}`,
  { label: a, phase: 'Lenses', agentType: a }
).then(r => ({ lens: a, result: r }))

const results = await parallel(LENSES.map(a => () => runLens(a)))
const lenses = results.filter(r => r && r.result)

// RETRY-ONCE, like every other fan-out (see research-fanout.js for the full rationale): a lens
// that returned nothing gets ONE re-launch with the identical prompt before this workflow
// reports it missing. constitution.md requires this in EVERY fan-out workflow; discovery.js was
// one of the two (with arch-review.js) that never implemented it — the retry lived in prose only.
const missing = LENSES.filter(a => !lenses.some(l => l.lens === a))
const retried = missing.length
  ? (await parallel(missing.map(a => () => runLens(a)))).filter(r => r && r.result)
  : []
lenses.push(...retried)
const retried_lenses = retried.map(r => r.lens)
// Still nothing after its second chance: now it is a real absence, and it must surface in
// unmerged[] rather than vanish. The conductor blocks on these — it does not retry them again.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['checklist_version', 'items', 'coverage', 'missing_ids', 'questions', 'overflow_questions', 'write_plan', 'covered_by_orchestrator', 'flags', 'source_refs', 'failed_lenses', 'unmerged'],
  properties: {
    checklist_version: { type: 'number' },
    items: { type: 'array', items: { type: 'object', additionalProperties: true } },
    coverage: { type: 'object', additionalProperties: true },
    missing_ids: { type: 'array', items: { type: 'string' } },
    questions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    overflow_questions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    write_plan: { type: 'array', items: { type: 'object', additionalProperties: true } },
    covered_by_orchestrator: { type: 'array', items: { type: 'string' } },
    flags: { type: 'array', items: { type: 'object', additionalProperties: true } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    failed_lenses: { type: 'array', items: { type: 'string' } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the DISCOVERY gate at time zero. Consolidate the per-lens dispositions below into ONE digest per your spec. Read ${CHECKLIST} yourself, extract every Q-* item ID, and prove completeness: any ID with no row from any lens goes into missing_ids[] — the forgotten question is exactly what this gate exists to prevent. Keep literals verbatim, dedupe overlapping questions into single human decisions carrying all their item_ids, group and cap the question round (~16, overflow with defaults preserved in overflow_questions[]), and assemble write_plan[] ordered by target file. You WRITE NOTHING and DECIDE NOTHING — orchestrator-flow asks the human and writes.\n\nLenses that returned NO result (copy verbatim into failed_lenses[] and list each in unmerged[] with reason "no result returned"): ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'discovery-synthesizer' }
)

// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`discovery: the synthesis reducer returned no digest for the discovery gate. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest`: runs the ONE batched CLARIFY round over questions[],
// executes write_plan[] (blueprint/**, stack.md, DECISIONS.md), then writes the report and
// meta.discovery. This workflow reports; it changes no state and never enters phase_runs[].
return { digest, lenses, failed_lenses, retried_lenses }
