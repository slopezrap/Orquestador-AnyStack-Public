export const meta = {
  name: 'validate-journeys',
  description: 'Cross-screen live gate (/verify-app). Disk-first: a read-only loader resolves which journeys (JOUR-*) have ALL their UI screens accepted/verified, then fan out one validate-journey lens per journey (real runtime, seams between screens: navigation, cross-screen value consistency, shell coherence) plus validate-logs once. Returns findings to orchestrator-flow; never changes any status.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves complete journeys + their screens/routes/platforms from disk' },
    { title: 'Drive', detail: 'one validate-journey lens per journey + validate-logs, in parallel' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`validate-journeys: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first: args is only an optional hint ({journey_id, root, include_verified}); truth comes from disk.
const hint = ARGS.journey_id ? String(ARGS.journey_id) : null
const root = ARGS.root ? String(ARGS.root) : '.'
// The human gate is the default. A journey runs only when ALL its UI screens are `accepted`;
// `--include-verified` (passed as include_verified:true) widens it to also accept `verified`
// screens — and the report must then mark that journey `provisional`. Without this the gate
// silently ran journeys past the human gate, the exact thing /verify-app is supposed to protect.
const includeVerified = !!ARGS.include_verified

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'journeys'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    journeys: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'screens'],
        properties: {
          id: { type: 'string' },
          title: { type: 'string' },
          screens: { type: 'array', items: { type: 'object', additionalProperties: true } },
          platforms: { type: 'array', items: { type: 'string' } },
        },
      },
    },
    shell_refs: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (screens[] is the runtime plan) and blueprint/logic/journey.md (JOUR-* definitions; a journey's related_screens/steps name its SCR-* screens in order). Read blueprint/logic/shell.md for the navigation map (UI-SHELL-002) and route convention refs.\n` +
  `2. A journey is runnable only when ALL its UI screens are in status ${includeVerified ? 'accepted OR verified (include_verified is ON)' : 'accepted (the human gate — verified is NOT enough)'}. ${hint ? `Select only the journey whose id === "${hint}", and if any of its screens is not ${includeVerified ? 'accepted/verified' : 'accepted'} set ok=false naming them.` : `Select every JOUR-* that meets this bar.`} A journey with any screen still ${includeVerified ? 'todo/ready/building/blocked' : 'todo/ready/building/blocked/verified'} is NOT runnable — exclude it and list it in error as "skipped: <id> (<blocking screens + their status>)".\n` +
  `3. For each selected journey return {id, title, platforms (union of its screens' platforms), provisional (true iff ANY screen is verified-not-accepted), screens: ordered [{id, slug, title, route, platforms, status}]}.\n` +
  `4. If nothing is runnable, set ok=false and error explaining exactly which screens block which journeys.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-journeys', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD: driving zero journeys silently would report a green app that was never crossed.
if (!ctx || !ctx.ok || !Array.isArray(ctx.journeys) || ctx.journeys.length === 0) {
  throw new Error(`validate-journeys: no runnable journey — ${ctx && ctx.error ? ctx.error : 'no JOUR-* has all its screens accepted/verified yet'}. Accept the missing screens (or pass args.journey_id) and re-run.`)
}

phase('Drive')
// Lens names in the SAME order as the runs below, so a lens that returns nothing is reported BY
// NAME (which journey, or validate-logs) like in every other fan-out workflow — not as a count.
const LENSES = [...ctx.journeys.map(j => `validate-journey:${j.id}`), 'validate-logs']

// ---------------------------------------------------------------------------------------------
// ISOLATION — serialized for the same reason validate-live.js serializes VALIDATE (see that file
// for the full rationale). Every journey here drives a REAL runtime — the shared shell, the same
// accepted screens, the same backend and the same canonical store — exactly like a validate-*
// lens does; two journeys driven concurrently are two live clients writing through that store at
// once, the identical collision the VALIDATE isolation rule exists to prevent. Mixing runLogs
// into that same parallel() call compounded it: it would then read logs while a driver was still
// writing them. So the whole Drive phase runs ONE lens at a time — journeys first, in the
// loader's order, validate-logs LAST so it reads finished logs, not half-written ones.
// ---------------------------------------------------------------------------------------------
const journeyIds = ctx.journeys.map(j => j.id)
const ORDERED = [...journeyIds, 'validate-logs']

// One definition per lens kind, shared by the first pass and the retry below: a retry that
// rebuilt the prompt could quietly ask a different question than the pass it is repeating.
const runJourney = async j => {
  try {
    const r = await agent(
      `CROSS-SCREEN VALIDATE for journey ${j.id} (${j.title || ''}). Repo root: ${root}. Drive the journey end-to-end in the real runtime per your spec; save your artifacts under .orchestrator-state/evidence/APP-INTEGRATION/.\n\nYou have SOLE ownership of the running app and the test store for the duration of this call — nothing else is driving them CONCURRENTLY. Do NOT reset the store; scope yourself to identifiers you generate and conclude nothing from a global count.\n\nJourney (ordered screens, routes, platforms):\n${JSON.stringify(j)}\n\nShell contract refs: ${JSON.stringify(ctx.shell_refs || [])}`,
      { label: `validate-journey:${j.id}`, phase: 'Drive', agentType: 'validate-journey' }
    )
    return { lens: 'validate-journey', journey: j.id, result: r }
  } catch (e) {
    return { lens: 'validate-journey', journey: j.id, result: null, error: String(e && e.message ? e.message : e) }
  }
}

const runLogs = async () => {
  try {
    const r = await agent(
      `VALIDATE (live) lens validate-logs for the cross-screen journey run (APP-INTEGRATION). Repo root: ${root}. The journeys above already ran, one at a time; inspect the now-finished frontend/backend/db runtime logs for new errors; save artifacts under .orchestrator-state/evidence/APP-INTEGRATION/. Journeys: ${JSON.stringify(journeyIds)}`,
      { label: 'validate-logs', phase: 'Drive', agentType: 'validate-logs' }
    )
    return { lens: 'validate-logs', result: r }
  } catch (e) {
    return { lens: 'validate-logs', result: null, error: String(e && e.message ? e.message : e) }
  }
}

const runLens = a => a === 'validate-logs' ? runLogs() : runJourney(ctx.journeys.find(j => j.id === a))

const runs = []
for (const a of ORDERED) {
  runs.push(await runLens(a))
}

// orchestrator-flow consolidates into reports/verify-app.md; statuses are NEVER changed here.
// Carry each journey's provisional flag + its verified-not-accepted screens so the conductor can
// label a journey `provisional (includes screens not yet accepted: <IDs>)` instead of guessing.
const ok = runs.filter(r => r && r.result)

// RETRY-ONCE inside the workflow, like the other fan-outs (see research-fanout.js for the full
// rationale). This gate launches UNATTENDED from /accept when an acceptance completes a journey,
// so a transient miss here is the case with the fewest humans watching — and a journey lens
// driving a real browser is among the flakiest things this orchestrator runs. SERIALIZED, like
// the first pass and for the same reason: these lenses drive one app, one set of ports and one
// canonical store, and retrying them concurrently would produce failures that belong to the
// neighbour — the exact signal-destroying outcome the serialization exists to prevent.
const missing = ORDERED.filter(a => !ok.some(l => (a === 'validate-logs' ? l.lens === 'validate-logs' : l.journey === a)))
const retriedJourneys = missing.filter(a => a !== 'validate-logs')
const retried_lenses = []
for (const a of retriedJourneys) {
  const r = await runJourney(ctx.journeys.find(j => j.id === a))
  if (r && r.result) { ok.push(r); retried_lenses.push(`validate-journey:${a}`) }
}
// Logs LAST, and re-run whenever a journey was retried — its first-pass artifact was captured
// before the retried journey acted, so keeping it would let result.json claim "logs clean" about
// a state that no longer exists. Same invariant validate-live holds, same reason.
const logsMissing = missing.includes('validate-logs')
if (retriedJourneys.length || logsMissing) {
  const r = await runLogs()
  if (r && r.result) {
    const stale = ok.findIndex(l => l.lens === 'validate-logs')
    if (stale >= 0) ok.splice(stale, 1)
    ok.push(r)
    retried_lenses.push('validate-logs')
  }
}

const failed_lenses = LENSES.filter(lens => lens === 'validate-logs'
  ? !ok.some(r => r.lens === 'validate-logs')
  : !ok.some(r => r.journey && `validate-journey:${r.journey}` === lens))
const journeys = ctx.journeys.map(j => ({
  id: j.id,
  provisional: !!j.provisional,
  unaccepted_screens: (j.screens || []).filter(s => s.status !== 'accepted').map(s => s.id),
}))
return { journeys, include_verified: includeVerified, lenses: ok, failed_lenses, retried_lenses }
