export const meta = {
  name: 'audit-architecture',
  description: 'AUDIT phase (cross-screen, cross-engine) for the WHOLE product, not one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns every verified/accepted unit plus the engine/pipeline/data contract refs (args is only an optional hint). Then fan out 5 specialized lens-agents in parallel (engine inventory, engine contract, pipeline topology, data reality, scale), and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow, which writes the report. Reports and recommends; never emits a lifecycle verdict and never changes any unit status.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the verified/accepted units + engine/pipeline/data refs from disk' },
    { title: 'Lenses', detail: 'audit-* agents in parallel (engine-inventory/engine-contract/pipeline-topology/data-reality/scale)' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (findings_by_target, cross_lens_contradictions, clarify_questions)' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`audit-architecture: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH root/focus; correctness comes from .orchestrator-state on disk.
// This workflow is deliberately NOT scoped to the active unit: the whole built product is the subject.
const hint = (ARGS.focus || ARGS.engine_id) ? String(ARGS.focus || ARGS.engine_id) : null
const root = ARGS.root ? String(ARGS.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'units', 'engine_refs', 'pipeline_refs', 'data_refs'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    architecture: { type: 'string' },
    canonical_store: { type: 'object', additionalProperties: true },
    units: { type: 'array', items: { type: 'object', additionalProperties: true } },
    engine_refs: { type: 'array', items: { type: 'string' } },
    pipeline_refs: { type: 'array', items: { type: 'string' } },
    data_refs: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the audit subject: EVERY screen whose status === "verified" or "accepted"${hint ? `, then keep only those related to the focus "${hint}" (matching id, slug, or a cited ENG-*/PIPE-*/DATA-* ref); if the focus matches nothing, keep the full set and say so in error` : ''}. This is a whole-product pass — do NOT reduce it to the single "building" unit. If at least one unit matches set ok=true; otherwise set ok=false, units=[] and error="no verified/accepted unit on disk".\n` +
  `3. For each selected unit return {id, slug, title, kind, platforms, status, route, applies, data_engine, architecture} verbatim from features.json.\n` +
  `4. Read blueprint/logic/engine.md, blueprint/logic/pipeline.md and blueprint/logic/data.md and return the declared contract IDs as engine_refs[] (ENG-*), pipeline_refs[] (PIPE-*) and data_refs[] (DATA-*), plus the declared architecture and the canonical_store block ({kind, source_of_truth, resources}) from features.json/data.md. Return the IDs the documents declare, not only the ones the units happen to cite — an engine/pipeline nobody consumes is itself a finding.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-product', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently auditing an empty product (a green report over zero units
// is worse than no report). Same discipline as validate-live/validate-journeys.
if (!ctx || !ctx.ok || !Array.isArray(ctx.units) || ctx.units.length === 0) {
  throw new Error(`audit-architecture: nothing to audit — ${ctx && ctx.error ? ctx.error : 'no unit is verified/accepted yet'}. Reach verified on at least one unit and re-run; this workflow does not degrade to an empty product.`)
}

// 5 whole-product lenses. They read ACROSS units on purpose: duplicated/absent engines, broken
// engine contracts, orphan pipeline topology, fake or non-canonical data, and scale profile —
// problems that are invisible inside a single screen and only appear when the screens are put side by side.
const LENSES = [
  'audit-engine-inventory', 'audit-engine-contract', 'audit-pipeline-topology',
  'audit-data-reality', 'audit-scale',
]

const productJson = JSON.stringify({
  architecture: ctx.architecture || 'unknown',
  canonical_store: ctx.canonical_store || {},
  engine_refs: ctx.engine_refs || [],
  pipeline_refs: ctx.pipeline_refs || [],
  data_refs: ctx.data_refs || [],
})

phase('Lenses')
// One definition, shared by the first pass and the retry: a retry that rebuilt the prompt
// could quietly ask a different question than the pass it is repeating.
const runLens = a => agent(
  `AUDIT lens ${a} over the WHOLE product (cross-screen, cross-engine) — this is NOT scoped to one unit. Repo root: ${root}. Audit the built units below together against blueprint/logic/engine.md, blueprint/logic/pipeline.md and blueprint/logic/data.md per your spec. You REPORT: you do not repair, you do not judge a unit's lifecycle, you do not touch state.\n\nBuilt units (verified/accepted):\n${JSON.stringify(ctx.units, null, 1)}\n\nProduct contract: ${productJson}`,
  { label: a, phase: 'Lenses', agentType: a }
).then(r => ({ lens: a, result: r }))

const results = await parallel(LENSES.map(a => () => runLens(a)))
const lenses = results.filter(r => r && r.result)

// RETRY-ONCE inside the workflow, like the four unit fan-outs (see research-fanout.js for the
// full rationale). This one was left out of that change and should not have been: it runs
// UNATTENDED by construction — /accept launches it automatically when an acceptance completes
// a journey — so a transient miss here is the case with the fewest humans watching, not the most.
const missing = LENSES.filter(a => !lenses.some(l => l.lens === a))
const retried = missing.length
  ? (await parallel(missing.map(a => () => runLens(a)))).filter(r => r && r.result)
  : []
lenses.push(...retried)
const retried_lenses = retried.map(r => r.lens)
// A lens that returned nothing TWICE must surface in failed_lenses[]/unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

// The schema and `audit-synthesizer.md`'s "## This phase's digest" are ONE contract with two
// halves, and they must be edited together: the agent file tells the model what to produce, this
// object is what actually ENFORCES it. They had drifted into naming different fields, and with
// `additionalProperties: false` that is not a cosmetic mismatch — a synthesizer honoring its own
// agent file would fail validation here, taking down the Synthesize phase of every /audit-motores.
// `failed_lenses` is deliberately NOT part of the digest: the workflow computes it deterministically
// above and returns it as a sibling (see the return below), so asking the model to restate it would
// duplicate a value already known with certainty — and re-open the same mismatch from the other side.
const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['scope', 'verdict_by_lens', 'findings_by_target', 'cross_lens_contradictions', 'clarify_questions', 'source_refs', 'unmerged'],
  properties: {
    scope: { type: 'object', additionalProperties: true },
    verdict_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings_by_target: { type: 'array', items: { type: 'object', additionalProperties: true } },
    cross_lens_contradictions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    clarify_questions: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the AUDIT phase of the whole product. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you emit NO lifecycle verdict — this phase REPORTS; orchestrator-flow writes the report and decides what to do with it.\nRules: scope = {units: [ids audited], engines, pipelines, stores} actually covered — copy from the loader context, never widen it. verdict_by_lens: one row per lens {lens, verdict} — a mechanical roll-up, advisory only. findings_by_target: group EVERY finding by the module/engine/pipeline it affects, NOT by acceptance criterion — audit findings are cross-screen, so the target is what makes them legible. One row per target as {target, target_kind: module|engine|pipeline, screens_touched[], blueprint_debt[{severity, detail, file, suggested_id, proposed_text, resolution: auto_fill|clarify, doc_refs, evidence, lens}], architecture_debt[{severity, detail, paths, doc_refs, evidence, lens}]}, both buckets sorted blocker→nit and deduped by (ref, detail). Every item lands in exactly ONE bucket: blueprint_debt is truth that must be written back to blueprint/**, architecture_debt is debt that lives in the code. A finding without a concrete file/ID/observed fact behind it is dropped, not softened. The problems that need at least two units/engines/pipelines to be visible — the same engine implemented twice, one canonical value diverging per screen, a pipeline no unit triggers, a store written from two paths — are the reason this phase exists: they belong to the target they affect, with every screen listed in screens_touched[], never scattered one copy per screen. cross_lens_contradictions: FLAG only, where two lenses disagree about the same thing, as {ids, detail, files, lenses} — you report the disagreement, you never resolve it. clarify_questions: the deduped union of the genuine product decisions the lenses surfaced, as plain strings — you decide nothing and you never propose a status change. source_refs[]: the blueprint rule IDs + files cited across the findings, as {file, ids} — a navigable index so orchestrator-flow can re-open the source. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. List each lens named below in unmerged[] with reason "no result returned" — a degraded audit must be visible in the report, never silently smaller.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}\n\nAudited units: ${JSON.stringify(ctx.units.map(u => u.id))}\nProduct contract: ${productJson}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'audit-synthesizer' }
)


// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`audit-architecture: the synthesis reducer returned no digest for the whole-product audit. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest` and writes the audit report. Like validate-journeys, this
// workflow is advisory across the whole product: it changes no unit's status, emits no lifecycle
// verdict, and validate-state.py remains the only gate. `lenses` kept for traceability.
return { units: ctx.units.map(u => u.id), digest, lenses, failed_lenses, retried_lenses }
