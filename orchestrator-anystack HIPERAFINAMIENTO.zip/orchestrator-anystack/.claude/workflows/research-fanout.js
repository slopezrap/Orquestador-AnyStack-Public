export const meta = {
  name: 'research-fanout',
  description: 'Phase 0 RESEARCH for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out one specialized lens-agent per blueprint file (17: 14 logic/*.md + PRODUCT + SCREENS + design) in parallel, and a read-only synthesis reducer collapses them into ONE digest (coverage, deduped gaps, flagged cross-file contradictions, CLARIFY questions) for orchestrator-flow. The conductor runs CLARIFY and writes the blueprint; the synthesizer adjudicates nothing and writes nothing.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk' },
    { title: 'Lenses', detail: 'one research-* agent per blueprint file, in parallel' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (coverage, gaps, contradictions flagged, clarify_questions)' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`research-fanout: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (ARGS.screen_id || ARGS.id) ? String(ARGS.screen_id || ARGS.id) : null
const root = ARGS.root ? String(ARGS.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    design_ref: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title, design_ref (its declared design reference, else design/screens/<slug>.html) and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, source} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (17 lenses researching a screen that
// literally does not exist return a full-but-empty set the STATE GATE cannot tell from a real one).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`research-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// The hint is honoured, not merely consulted. Without this, a loader that resolves a DIFFERENT
// unit than the one asked for returns ok:true and the whole fan-out runs looking perfectly
// healthy — on the wrong screen. That failure is silent by construction: every lens reports on
// the unit it was handed, so the evidence is internally consistent and simply about something
// else. Cheap to close, and the alternative is spending full phases before anyone notices.
if (hint && sid !== hint) {
  throw new Error(`research-fanout: asked for "${hint}" but the loader resolved "${sid}". Refusing to run the phase on a unit that was not requested — re-check args.screen_id and the status of both units.`)
}

// One lens-agent per blueprint file (the agent body holds the focus + return contract).
const LENSES = [
  'research-domain', 'research-application', 'research-core', 'research-journey',
  'research-permission', 'research-state', 'research-error', 'research-integration',
  'research-ui', 'research-shell', 'research-data', 'research-usecases',
  'research-engine', 'research-pipeline',
  'research-product', 'research-screens', 'research-design',
]

phase('Lenses')
// One definition, used by the first pass AND the retry below: a retry that rebuilt the
// prompt could quietly ask a different question than the pass it is repeating.
const runLens = a => agent(
  `RESEARCH lens for screen ${sid} (${ctx.title || ctx.slug || ''}). Repo root: ${root}. Read your blueprint file and assess whether it fully and unambiguously specifies THIS screen on your concern; return per your spec.\n\n` +
  `SCOPE FIRST, THEN DEPTH. The unit's applies[] is in the feature excerpt below. Start by checking whether this screen cites anything your layer owns. If it cites NOTHING of yours and nothing in your file bears on it, return covered:"n/a" with that as the concrete reason and STOP — do not re-derive your whole layer to reach the same conclusion. If it cites even one of your IDs, or your layer constrains it indirectly, do the full work as usual.\n` +
  `You own the ABSENCE, so read this correctly: "the screen cites nothing of mine" is a scope statement and is fine. "The blueprint does not specify X" is a FINDING and still requires you to have actually looked. Never use the shortcut to skip finding a real gap — it exists to stop you paying full price to say "not mine".\n\n` +
  `Feature: ${JSON.stringify(ctx.feature_excerpt)}\ndesign_ref: ${ctx.design_ref || `design/screens/${ctx.slug || sid}.html`}`,
  { label: a, phase: 'Lenses', agentType: a }
).then(r => ({ lens: a, result: r }))

const results = await parallel(LENSES.map(a => () => runLens(a)))
const lenses = results.filter(r => r && r.result)

// RETRY-ONCE, here rather than in the conductor's head.
//
// "A lens that returns nothing is not a lens that ran... retry, then block" was stated in
// constitution.md and in next-pantalla §Cross-cutting, and implemented nowhere: every
// workflow computed failed_lenses[] once and handed it back, trusting the conductor to
// re-launch. Prose is not a control — the same rule this repo applies to `tools:` frontmatter
// applies here. A transient failure therefore blocked a unit outright, and on an unattended
// run nobody was there to notice it was transient.
//
// It runs ONCE and only once, and the workflow says so in `retried_lenses[]`, because the
// failure mode of fixing this in both places is paying for every dead lens twice.
const missing = LENSES.filter(a => !lenses.some(l => l.lens === a))
const retried = missing.length
  ? (await parallel(missing.map(a => () => runLens(a)))).filter(r => r && r.result)
  : []
lenses.push(...retried)
const retried_lenses = retried.map(r => r.lens)
// Still nothing after its second chance: now it is a real absence, and it must surface in
// unmerged[] rather than vanish. The conductor blocks on these — it does not retry them again.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  // contradicts_prior_claim is REQUIRED, not optional-when-empty: an absent field reads as
  // "not checked" and an empty one reads as "checked, nothing found". Only the second is true,
  // and the conductor cannot tell them apart after the fact.
  required: ['screen_id', 'coverage', 'coverage_by_lens', 'gaps', 'cross_file_contradictions', 'auto_fill', 'clarify_questions', 'source_refs', 'contradicts_prior_claim', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    coverage: { type: 'string', enum: ['complete', 'partial', 'missing'] },
    coverage_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    gaps: { type: 'array', items: { type: 'object', additionalProperties: true } },
    cross_file_contradictions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    auto_fill: { type: 'array', items: { type: 'object', additionalProperties: true } },
    clarify_questions: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    contradicts_prior_claim: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the RESEARCH phase of screen ${sid}. Consolidate the per-lens (per-blueprint-file) results below into ONE digest. You WRITE NOTHING and you ADJUDICATE NOTHING — orchestrator-flow runs CLARIFY with the human and writes the blueprint.\nRules: coverage = worst-of across lenses (missing < partial < complete; ignore n/a lenses). coverage_by_lens: one row per lens {lens, file, covered}. gaps: union of all lens gaps, each {problem, location, resolution: auto_fill|clarify, proposed_fill, source_lenses}; proposed_fill copied VERBATIM (never invent product intent). cross_file_contradictions: FLAG only (two files disagree, or a screen cites a missing ID) as {ids, detail, lenses} — do not resolve them. auto_fill: deduped union (proposed_fill verbatim). clarify_questions: deduped union (for one CLARIFY round). Any missing/unparseable lens → unmerged[]. Build source_refs[] = the blueprint files+IDs relevant to this screen, and keep each gap's file+refs, so orchestrator-flow can re-open the source while it builds.\ncontradicts_prior_claim[]: ALWAYS emit it, empty when there is nothing. One entry per lens finding that contradicts a recorded DEC-* decision, a blueprint assertion or an earlier verdict — {lens, finding_quote, finding_evidence, contradicted_claim_quote, contradicted_claim_source} — with BOTH quotes literal/verbatim (a paraphrased disagreement is a lost disagreement). Also enter here any lens asserting a NEGATIVE ("does not exist / is not declared / is not supported") WITHOUT a command, its literal output and an artifact path: the evidence standard makes an unproven negative unwritable, and this phase's output goes straight into blueprint/**. Flag, never adjudicate.\n\nLenses that returned NO result (list each in unmerged[] with reason "no result returned"): ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'research-synthesizer' }
)

// The digest is the whole point of the phase: returning `digest: undefined` would let the conductor
// close RESEARCH on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`research-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${LENSES.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not write the blueprint from an empty RESEARCH.`)
}

// orchestrator-flow consumes `digest`: applies auto_fill, runs CLARIFY once, resolves contradictions, writes the blueprint.
return { screen_id: sid, digest, lenses, failed_lenses, retried_lenses }
