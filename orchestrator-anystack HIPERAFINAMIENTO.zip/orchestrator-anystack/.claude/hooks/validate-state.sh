#!/usr/bin/env bash
# PostToolUse(Write|Edit|Bash) guardrail.
# When a JSON file under .orchestrator-state/ is written, verify it still parses.
# In addition, when the lifecycle file features.json is written — the ONLY place a
# unit's status flips to verified/accepted — run the full semantic STATE GATE so a
# skipped workflow / incomplete phase_runs / missing evidence is caught the moment
# it is recorded, not only when a skill happens to re-run the validator.
# Bash coverage: a shell command that touches the LIFECYCLE file (features.json)
# bypasses file_path, so any Bash command mentioning .orchestrator-state AND
# features.json triggers the same full gate — flipping a status through Bash cannot
# dodge the check. Other .orchestrator-state Bash writes (lens evidence artifacts)
# are sanctioned and skipped here to avoid re-running the O(N) gate on every
# artifact write; the gate still validates everything at phase close.
# PostToolUse cannot block a tool that already ran, so this is a strong early signal
# (exit 2 surfaces the error back to Claude), not a substitute for the gate.
set -uo pipefail

hook_vars="$(python3 -c '
import json, sys
try:
    payload = json.load(sys.stdin)
except Exception:
    print("-"); print("no"); sys.exit(0)
tool_input = payload.get("tool_input") or {}
print(tool_input.get("file_path", "") or "-")
command = tool_input.get("command", "") or ""
print("yes" if (".orchestrator-state" in command and "features.json" in command) else "no")')"
file_path="$(printf '%s\n' "$hook_vars" | sed -n 1p)"
bash_touches_state="$(printf '%s\n' "$hook_vars" | sed -n 2p)"

run_gate() {
  local trigger="$1"
  local proj="${CLAUDE_PROJECT_DIR:-$PWD}"
  if ! out="$(cd "$proj" && python3 .orchestrator/scripts/validate-state.py 2>&1)"; then
    printf 'State gate failed after %s\n%s\n' "$trigger" "$out" >&2
    exit 2
  fi
}

case "$file_path" in
  *.orchestrator-state/features.json)
    if ! err="$(python3 -m json.tool "$file_path" 2>&1 1>/dev/null)"; then
      printf 'Invalid JSON written to %s\n%s\n' "$file_path" "$err" >&2
      exit 2
    fi
    # Run the full state gate from the repo root so cwd-relative paths resolve.
    proj="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$file_path")/.." && pwd)}"
    if ! out="$(cd "$proj" && python3 .orchestrator/scripts/validate-state.py 2>&1)"; then
      printf 'State gate failed after writing %s\n%s\n' "$file_path" "$out" >&2
      exit 2
    fi
    ;;
  *.orchestrator-state/*.json)
    if ! err="$(python3 -m json.tool "$file_path" 2>&1 1>/dev/null)"; then
      printf 'Invalid JSON written to %s\n%s\n' "$file_path" "$err" >&2
      exit 2
    fi
    ;;
  *)
    if [ "${bash_touches_state:-no}" = "yes" ]; then
      run_gate "a Bash command touching .orchestrator-state/features.json"
    fi
    ;;
esac
exit 0
