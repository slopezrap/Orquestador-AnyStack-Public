#!/usr/bin/env bash
# PreToolUse(Bash) guardrail.
# Denies destructive recursive deletions before the Bash tool runs. Hooks are
# session-wide, so this also guards every subagent/lens Bash call.
#
# BLOCKED: any recursive rm (`rm -r`, `rm -rf`, `rm --recursive`) however it is
# reached — by path (`/bin/rm`), behind a wrapper and its flags (`sudo -u root rm`)
# or inside an embedded shell (`bash -c "rm -rf ..."`) — plus the three usual
# equivalents: `find ... -delete` / `find ... -exec rm`, `git clean` with force
# and -d/-x, and `shutil.rmtree` in an inline script.
#
# DELIBERATELY ALLOWED, so the orchestrator's own flow never has a reason to turn
# this hook off (a guardrail that blocks the normal path gets disabled):
#   - non-recursive removals: `rm file`, `rm -f file`, `rm *.log`;
#   - any deletion whose targets ALL live in a temp tree (/tmp, /var/tmp,
#     /var/folders/..., or a $TMP*/$TEMP* variable): the smoke test and the lenses
#     clean up their own scratch dirs there;
#   - `bash .orchestrator/scripts/reset-state.sh --force`: its `rm -rf
#     .orchestrator-state` runs INSIDE the script, where no PreToolUse hook can
#     see it. That reset stays guarded by the script itself, by design.
#
# Only ACTUAL option tokens (args beginning with "-") are inspected, so a path
# that merely contains letters — a verify-*/validate-*/explore-*/*-verifier
# filename — does NOT trigger a false positive.
set -uo pipefail

python3 -c '
import json, os, re, shlex, sys

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(0)

cmd = (payload.get("tool_input") or {}).get("command", "") or ""
if not re.search(r"\brm\b|/rm\b|-delete\b|\bgit\b.*\bclean\b|shutil\.rmtree|os\.removedirs", cmd):
    sys.exit(0)

SPLIT = r"&&|\|\||[;|\n]"
QUOTES = chr(34) + chr(39)  # this hook body is single-quoted for bash
# Wrappers that merely run another command: the real command hides behind them.
PREFIX = {"sudo", "doas", "command", "exec", "nohup", "time", "env", "xargs", "then", "do"}
SHELLS = {"bash", "sh", "zsh", "dash", "ksh"}
TEMP_ROOTS = ("/tmp/", "/private/tmp/", "/var/tmp/", "/var/folders/", "/private/var/folders/")
TEMP_VAR = re.compile(r"^\$\{?[A-Za-z0-9_]*(TMP|TEMP)[A-Za-z0-9_]*\}?(/|$)")

def is_temp(target):
    """Target inside a temp tree, literally or through a $TMP*/$TEMP* variable.

    NORMALIZE BEFORE COMPARING. A prefix match on the raw token let `..` walk straight back
    out of the exemption: `rm -rf /tmp/../etc` starts with "/tmp/" and was allowed, and so was
    `/tmp/../Users/<you>/Desktop` — the parent of the repo this hook exists to protect. The
    exemption is meant to say "this deletion lands in scratch space", which is a claim about
    where the path RESOLVES, not about how it is spelled. os.path.normpath collapses `..` and
    duplicate slashes textually (no filesystem access, so it stays correct for paths that do
    not exist yet), and the re-check afterwards is what makes the collapse count.

    A path holding a shell variable other than $TMP*/$TEMP* is NOT temp: its value is unknown
    here, so the safe reading is "not proven to be scratch" and the deletion goes to the human.
    """
    t = target.strip(QUOTES)
    if TEMP_VAR.match(t):
        # The variable itself is scratch, but anything after it must not climb out either:
        # "$TMPDIR/../../etc" is the same escape wearing a variable.
        # Normalize the remainder as RELATIVE to the variable, never anchored at "/": the
        # value of the variable is unknown, so `..` is measured against it. Anchoring first
        # hides the escape, because normpath("/../../etc") is just "/etc" — `..` at the root is
        # a no-op in POSIX, and $TMPDIR is not the root.
        rest = t.split("/", 1)[1] if "/" in t else ""
        return not rest or not os.path.normpath(rest).startswith("..")
    if "$" in t or "`" in t:
        return False
    norm = os.path.normpath(t)
    if not norm.endswith("/"):
        norm += "/"
    return any(norm.startswith(root) and len(norm) > len(root) for root in TEMP_ROOTS)

def confined_to_temp(targets):
    """A deletion whose every target is scratch space is cleanup, not data loss."""
    return bool(targets) and all(is_temp(t) for t in targets)

def commands(seg):
    """Every command position of a segment as (name, args): the head, plus what
    hides behind wrappers and their flags — `sudo -u root rm` reaches rm because
    `root` sits right after an option token."""
    try:
        toks = shlex.split(seg)
    except Exception:
        toks = seg.split()
    found = []
    for idx, tok in enumerate(toks):
        wrapped = all(
            (("=" in prev and not prev.startswith("-"))
             or os.path.basename(prev) in PREFIX
             or prev.startswith("-")
             or (pos > 0 and toks[pos - 1].startswith("-")))
            for pos, prev in enumerate(toks[:idx])
        )
        if wrapped:
            found.append((os.path.basename(tok), toks[idx + 1:]))
    return found

def is_destructive(seg):
    if re.search(r"shutil\.rmtree|os\.removedirs", seg):
        # Inline script deleting a tree: allowed only when it names a temp target.
        quoted = re.findall("[" + QUOTES + "]([^" + QUOTES + "]*)[" + QUOTES + "]", seg)
        if not any(is_temp(q) for q in quoted):
            return True
    return any(runs_delete(name, args) for name, args in commands(seg))

def runs_delete(name, args):
    if name in SHELLS and "-c" in args:
        idx = args.index("-c")
        inner = args[idx + 1] if idx + 1 < len(args) else ""
        return any(is_destructive(part) for part in re.split(SPLIT, inner))

    opts = [t for t in args if t.startswith("-") and t != "--"]
    operands = [t for t in args if not t.startswith("-")]

    if name == "rm":
        recursive = any(
            o == "--recursive" or (not o.startswith("--") and re.search(r"[rR]", o[1:]))
            for o in opts
        )
        return recursive and not confined_to_temp(operands)

    if name == "find":
        deletes = "-delete" in args or (
            "-exec" in args and any(os.path.basename(a) == "rm" for a in args)
        )
        roots = []
        for tok in args:
            if tok.startswith("-"):
                break
            roots.append(tok)
        return deletes and not confined_to_temp(roots)

    if name == "git" and "clean" in args:
        letters = "".join(o.lstrip("-") for o in opts if not o.startswith("--"))
        longs = {o for o in opts if o.startswith("--")}
        if "n" in letters or "--dry-run" in longs:
            return False
        forced = "f" in letters or "--force" in longs
        wide = any(c in letters for c in "dxX") or "--directory" in longs
        return forced and wide

    return False

if any(is_destructive(seg) for seg in re.split(SPLIT, cmd)):
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": (
                "Recursive delete blocked by the orchestrator hook (rm -r/-rf, find -delete, "
                "git clean -fd/-fdx, shutil.rmtree). Still allowed, with no workaround needed: "
                "deleting named files (rm / rm -f), and any recursive delete whose targets are "
                "all under a temp tree (/tmp, /var/folders, $TMP...). Delete the specific paths "
                "you need instead of a whole tree; resetting orchestrator state is the job of "
                ".orchestrator/scripts/reset-state.sh, not of an ad-hoc rm."
            ),
        }
    }))
'
exit 0
